﻿/* ============================================================
   ALWATEEN - 001_CleanBaseline.sql
   Type: Fresh Database Only
   Purpose: Build clean baseline schema for empty development/new database.
   Important:
   - Do NOT run on existing client databases.
   - Do NOT run on databases containing operational data.
   - This script does not create the database.
   - Select/create the target database first, then run this script.
   - Allowed pre-existing table: dbo.SchemaMigrations only, and only if it has the approved structure.
   ============================================================ */

SET XACT_ABORT ON;
SET NOCOUNT ON;

BEGIN TRY
    BEGIN TRANSACTION;

    /* ============================================================
       SAFETY CHECK
       This baseline must run only on an empty database.
       It allows dbo.SchemaMigrations only because a migration runner may create it first.
       ============================================================ */

    IF EXISTS
    (
        SELECT 1
        FROM sys.tables
        WHERE is_ms_shipped = 0
          AND NOT (name = 'SchemaMigrations' AND schema_id = SCHEMA_ID('dbo'))
    )
    BEGIN
        THROW 51000, 'Clean baseline aborted: target database is not empty except dbo.SchemaMigrations.', 1;
    END;

    /* ============================================================
       1. SchemaMigrations
       ============================================================ */

    IF OBJECT_ID('dbo.SchemaMigrations', 'U') IS NULL
    BEGIN
        CREATE TABLE dbo.SchemaMigrations
        (
            Id INT IDENTITY(1,1) NOT NULL,
            ScriptName NVARCHAR(255) NOT NULL,
            ScriptHash NVARCHAR(128) NOT NULL,
            ExecutedAt DATETIME2(7) NOT NULL,
            DurationMs INT NULL,
            Status NVARCHAR(20) NOT NULL,
            ErrorMessage NVARCHAR(MAX) NULL,

            CONSTRAINT PK_SchemaMigrations
                PRIMARY KEY CLUSTERED (Id),

            CONSTRAINT UQ_SchemaMigrations_ScriptName
                UNIQUE (ScriptName),

            CONSTRAINT CK_SchemaMigrations_Status
                CHECK (Status IN ('Success', 'Failed'))
        );
    END;
    ELSE
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.SchemaMigrations') AND name = 'ScriptHash')
           OR NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.SchemaMigrations') AND name = 'DurationMs')
           OR NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.SchemaMigrations') AND name = 'Status')
           OR NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id = OBJECT_ID('dbo.SchemaMigrations') AND name = 'ErrorMessage')
        BEGIN
            THROW 51002, 'Clean baseline aborted: existing dbo.SchemaMigrations does not match the approved structure.', 1;
        END;
    END;

    /* ============================================================
       2. Accounts
       ============================================================ */

    CREATE TABLE dbo.Accounts
    (
        Id INT IDENTITY(1,1) NOT NULL,
        AccountNumber NVARCHAR(50) NOT NULL,
        AccountName NVARCHAR(200) NOT NULL,
        ParentAccountId INT NULL,
        AccountType NVARCHAR(50) NOT NULL,
        Level INT NOT NULL,
        CanPost BIT NOT NULL
            CONSTRAINT DF_Accounts_CanPost DEFAULT (1),
        IsActive BIT NOT NULL
            CONSTRAINT DF_Accounts_IsActive DEFAULT (1),
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_Accounts_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,

        CONSTRAINT PK_Accounts
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT UQ_Accounts_AccountNumber
            UNIQUE (AccountNumber),

        CONSTRAINT CK_Accounts_Level
            CHECK (Level >= 1),

        CONSTRAINT CK_Accounts_AccountType
            CHECK (AccountType IN ('Asset', 'Liability', 'Equity', 'Revenue', 'Expense'))
    );

    /* ============================================================
       3. FiscalYears
       ============================================================ */

    CREATE TABLE dbo.FiscalYears
    (
        Id INT IDENTITY(1,1) NOT NULL,
        YearName NVARCHAR(100) NOT NULL,
        StartDate DATE NOT NULL,
        EndDate DATE NOT NULL,
        IsClosed BIT NOT NULL
            CONSTRAINT DF_FiscalYears_IsClosed DEFAULT (0),
        ClosedAt DATETIME2(7) NULL,
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_FiscalYears_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,

        CONSTRAINT PK_FiscalYears
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT UQ_FiscalYears_YearName
            UNIQUE (YearName),

        CONSTRAINT CK_FiscalYears_DateRange
            CHECK (StartDate <= EndDate)
    );

    CREATE INDEX IX_FiscalYears_DateRange
        ON dbo.FiscalYears (StartDate, EndDate);

    /* ============================================================
       4. AccountingPeriods
       ============================================================ */

    CREATE TABLE dbo.AccountingPeriods
    (
        Id INT IDENTITY(1,1) NOT NULL,
        FiscalYearId INT NOT NULL,
        PeriodName NVARCHAR(100) NOT NULL,
        StartDate DATE NOT NULL,
        EndDate DATE NOT NULL,
        IsClosed BIT NOT NULL
            CONSTRAINT DF_AccountingPeriods_IsClosed DEFAULT (0),
        ClosedAt DATETIME2(7) NULL,
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_AccountingPeriods_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,

        CONSTRAINT PK_AccountingPeriods
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT CK_AccountingPeriods_DateRange
            CHECK (StartDate <= EndDate)
    );

    CREATE INDEX IX_AccountingPeriods_FiscalYearId
        ON dbo.AccountingPeriods (FiscalYearId);

    CREATE INDEX IX_AccountingPeriods_DateRange
        ON dbo.AccountingPeriods (StartDate, EndDate);

    /* ============================================================
       5. Warehouses
       ============================================================ */

    CREATE TABLE dbo.Warehouses
    (
        Id INT IDENTITY(1,1) NOT NULL,
        WarehouseCode NVARCHAR(50) NOT NULL,
        WarehouseName NVARCHAR(150) NOT NULL,
        Address NVARCHAR(500) NULL,
        Notes NVARCHAR(1000) NULL,
        IsMainWarehouse BIT NOT NULL
            CONSTRAINT DF_Warehouses_IsMainWarehouse DEFAULT (0),
        IsActive BIT NOT NULL
            CONSTRAINT DF_Warehouses_IsActive DEFAULT (1),
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_Warehouses_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,

        CONSTRAINT PK_Warehouses
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT UQ_Warehouses_Code
            UNIQUE (WarehouseCode),

        CONSTRAINT UQ_Warehouses_Name
            UNIQUE (WarehouseName)
    );

    /* ============================================================
       6. Units
       ============================================================ */

    CREATE TABLE dbo.Units
    (
        Id INT IDENTITY(1,1) NOT NULL,
        UnitCode NVARCHAR(50) NOT NULL,
        UnitName NVARCHAR(150) NOT NULL,
        Notes NVARCHAR(500) NULL,
        IsActive BIT NOT NULL
            CONSTRAINT DF_Units_IsActive DEFAULT (1),
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_Units_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,

        CONSTRAINT PK_Units
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT UQ_Units_UnitCode
            UNIQUE (UnitCode),

        CONSTRAINT UQ_Units_UnitName
            UNIQUE (UnitName)
    );

    /* ============================================================
       7. Categories
       ============================================================ */

    CREATE TABLE dbo.Categories
    (
        Id INT IDENTITY(1,1) NOT NULL,
        CategoryCode NVARCHAR(50) NOT NULL,
        CategoryName NVARCHAR(150) NOT NULL,
        Notes NVARCHAR(1000) NULL,
        IsActive BIT NOT NULL
            CONSTRAINT DF_Categories_IsActive DEFAULT (1),
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_Categories_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,

        CONSTRAINT PK_Categories
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT UQ_Categories_Code
            UNIQUE (CategoryCode),

        CONSTRAINT UQ_Categories_Name
            UNIQUE (CategoryName)
    );

    /* ============================================================
       8. ItemAttributes
       ============================================================ */

    CREATE TABLE dbo.ItemAttributes
    (
        Id INT IDENTITY(1,1) NOT NULL,
        AttributeCode NVARCHAR(50) NOT NULL,
        AttributeName NVARCHAR(150) NOT NULL,
        Notes NVARCHAR(1000) NULL,
        IsActive BIT NOT NULL
            CONSTRAINT DF_ItemAttributes_IsActive DEFAULT (1),
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_ItemAttributes_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,

        CONSTRAINT PK_ItemAttributes
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT UQ_ItemAttributes_Code
            UNIQUE (AttributeCode),

        CONSTRAINT UQ_ItemAttributes_Name
            UNIQUE (AttributeName)
    );

    /* ============================================================
       9. Employees
       ============================================================ */

    CREATE TABLE dbo.Employees
    (
        Id INT IDENTITY(1,1) NOT NULL,
        EmployeeCode NVARCHAR(50) NOT NULL,
        FullName NVARCHAR(200) NOT NULL,
        PhoneNumber NVARCHAR(50) NULL,
        Address NVARCHAR(300) NULL,
        JobTitle NVARCHAR(100) NULL,
        Salary DECIMAL(18,3) NOT NULL
            CONSTRAINT DF_Employees_Salary DEFAULT (0),
        HireDate DATETIME2(7) NOT NULL,
        IsActive BIT NOT NULL
            CONSTRAINT DF_Employees_IsActive DEFAULT (1),
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_Employees_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,

        CONSTRAINT PK_Employees
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT UQ_Employees_EmployeeCode
            UNIQUE (EmployeeCode),

        CONSTRAINT CK_Employees_Salary
            CHECK (Salary >= 0)
    );

    /* ============================================================
       10. Items
       ============================================================ */

    CREATE TABLE dbo.Items
    (
        Id INT IDENTITY(1,1) NOT NULL,
        ItemCode NVARCHAR(50) NULL,
        ItemName NVARCHAR(200) NOT NULL,
        UnitId INT NULL,
        CategoryId INT NULL,
        DefaultWarehouseId INT NULL,
        SellPrice DECIMAL(18,3) NOT NULL
            CONSTRAINT DF_Items_SellPrice DEFAULT (0),
        BuyPrice DECIMAL(18,3) NOT NULL
            CONSTRAINT DF_Items_BuyPrice DEFAULT (0),
        Notes NVARCHAR(500) NULL,
        IsActive BIT NOT NULL
            CONSTRAINT DF_Items_IsActive DEFAULT (1),
        IsArchived BIT NOT NULL
            CONSTRAINT DF_Items_IsArchived DEFAULT (0),
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_Items_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,

        CONSTRAINT PK_Items
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT UQ_Items_ItemName
            UNIQUE (ItemName),

        CONSTRAINT CK_Items_SellPrice
            CHECK (SellPrice >= 0),

        CONSTRAINT CK_Items_BuyPrice
            CHECK (BuyPrice >= 0)
    );

    CREATE UNIQUE INDEX UQ_Items_ItemCode
        ON dbo.Items (ItemCode)
        WHERE ItemCode IS NOT NULL;

    CREATE INDEX IX_Items_UnitId
        ON dbo.Items (UnitId);

    CREATE INDEX IX_Items_CategoryId
        ON dbo.Items (CategoryId);

    CREATE INDEX IX_Items_DefaultWarehouseId
        ON dbo.Items (DefaultWarehouseId);

    /* ============================================================
       11. ItemBarcodes
       ============================================================ */

    CREATE TABLE dbo.ItemBarcodes
    (
        Id INT IDENTITY(1,1) NOT NULL,
        ItemId INT NOT NULL,
        Barcode NVARCHAR(100) NOT NULL,
        IsPrimary BIT NOT NULL
            CONSTRAINT DF_ItemBarcodes_IsPrimary DEFAULT (0),
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_ItemBarcodes_CreatedAt DEFAULT (SYSDATETIME()),

        CONSTRAINT PK_ItemBarcodes
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT UQ_ItemBarcodes_Barcode
            UNIQUE (Barcode)
    );

    CREATE INDEX IX_ItemBarcodes_ItemId
        ON dbo.ItemBarcodes (ItemId);

    /* ============================================================
       12. ItemWarehouseCosts
       ============================================================ */

    CREATE TABLE dbo.ItemWarehouseCosts
    (
        Id INT IDENTITY(1,1) NOT NULL,
        ItemId INT NOT NULL,
        WarehouseId INT NOT NULL,
        AverageCost DECIMAL(18,3) NOT NULL
            CONSTRAINT DF_ItemWarehouseCosts_AverageCost DEFAULT (0),
        LastPurchaseCost DECIMAL(18,3) NOT NULL
            CONSTRAINT DF_ItemWarehouseCosts_LastPurchaseCost DEFAULT (0),
        LastUpdatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_ItemWarehouseCosts_LastUpdatedAt DEFAULT (SYSDATETIME()),

        CONSTRAINT PK_ItemWarehouseCosts
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT UQ_ItemWarehouseCosts_Item_Warehouse
            UNIQUE (ItemId, WarehouseId),

        CONSTRAINT CK_ItemWarehouseCosts_AverageCost
            CHECK (AverageCost >= 0),

        CONSTRAINT CK_ItemWarehouseCosts_LastPurchaseCost
            CHECK (LastPurchaseCost >= 0)
    );

    CREATE INDEX IX_ItemWarehouseCosts_WarehouseId
        ON dbo.ItemWarehouseCosts (WarehouseId);

    /* ============================================================
       13. Customers
       ============================================================ */

    CREATE TABLE dbo.Customers
    (
        Id INT IDENTITY(1,1) NOT NULL,
        CustomerCode NVARCHAR(50) NOT NULL,
        CustomerName NVARCHAR(200) NOT NULL,
        PhoneNumber NVARCHAR(50) NULL,
        Address NVARCHAR(300) NULL,
        AccountId INT NULL,
        Balance DECIMAL(18,3) NOT NULL
            CONSTRAINT DF_Customers_Balance DEFAULT (0),
        IsActive BIT NOT NULL
            CONSTRAINT DF_Customers_IsActive DEFAULT (1),
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_Customers_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,

        CONSTRAINT PK_Customers
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT UQ_Customers_CustomerCode
            UNIQUE (CustomerCode)
    );

    CREATE INDEX IX_Customers_AccountId
        ON dbo.Customers (AccountId);

    /* ============================================================
       14. Suppliers
       ============================================================ */

    CREATE TABLE dbo.Suppliers
    (
        Id INT IDENTITY(1,1) NOT NULL,
        SupplierCode NVARCHAR(50) NOT NULL,
        SupplierName NVARCHAR(200) NOT NULL,
        PhoneNumber NVARCHAR(50) NULL,
        Address NVARCHAR(300) NULL,
        AccountId INT NULL,
        Balance DECIMAL(18,3) NOT NULL
            CONSTRAINT DF_Suppliers_Balance DEFAULT (0),
        IsActive BIT NOT NULL
            CONSTRAINT DF_Suppliers_IsActive DEFAULT (1),
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_Suppliers_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,

        CONSTRAINT PK_Suppliers
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT UQ_Suppliers_SupplierCode
            UNIQUE (SupplierCode)
    );

    CREATE INDEX IX_Suppliers_AccountId
        ON dbo.Suppliers (AccountId);

    /* ============================================================
       15. OpeningBalanceBatches
       ============================================================ */

    CREATE TABLE dbo.OpeningBalanceBatches
    (
        Id INT IDENTITY(1,1) NOT NULL,
        BatchName NVARCHAR(200) NOT NULL,
        OpeningDate DATE NOT NULL,
        IsPosted BIT NOT NULL
            CONSTRAINT DF_OpeningBalanceBatches_IsPosted DEFAULT (0),
        PostedAt DATETIME2(7) NULL,
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_OpeningBalanceBatches_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,

        CONSTRAINT PK_OpeningBalanceBatches
            PRIMARY KEY CLUSTERED (Id)
    );

    /* ============================================================
       16. OpeningBalanceItems
       ============================================================ */

    CREATE TABLE dbo.OpeningBalanceItems
    (
        Id INT IDENTITY(1,1) NOT NULL,
        OpeningBalanceBatchId INT NOT NULL,
        ItemId INT NOT NULL,
        WarehouseId INT NOT NULL,
        Qty DECIMAL(18,3) NOT NULL,
        UnitCost DECIMAL(18,3) NOT NULL,
        TotalCost DECIMAL(18,3) NOT NULL,

        CONSTRAINT PK_OpeningBalanceItems
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT CK_OpeningBalanceItems_Qty
            CHECK (Qty > 0),

        CONSTRAINT CK_OpeningBalanceItems_UnitCost
            CHECK (UnitCost >= 0),

        CONSTRAINT CK_OpeningBalanceItems_TotalCost
            CHECK (TotalCost >= 0)
    );

    CREATE INDEX IX_OpeningBalanceItems_BatchId
        ON dbo.OpeningBalanceItems (OpeningBalanceBatchId);

    CREATE INDEX IX_OpeningBalanceItems_ItemId_WarehouseId
        ON dbo.OpeningBalanceItems (ItemId, WarehouseId);

    /* ============================================================
       17. PurchaseInvoices
       ============================================================ */

    CREATE TABLE dbo.PurchaseInvoices
    (
        Id INT IDENTITY(1,1) NOT NULL,
        InvoiceDate DATETIME2(7) NOT NULL,
        SupplierId INT NULL,
        PaymentType NVARCHAR(20) NOT NULL,
        CashAccountId INT NULL,
        Total DECIMAL(18,3) NOT NULL
            CONSTRAINT DF_PurchaseInvoices_Total DEFAULT (0),
        IsCancelled BIT NOT NULL
            CONSTRAINT DF_PurchaseInvoices_IsCancelled DEFAULT (0),
        CancelledAt DATETIME2(7) NULL,
        CancelReason NVARCHAR(500) NULL,
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_PurchaseInvoices_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,

        CONSTRAINT PK_PurchaseInvoices
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT CK_PurchaseInvoices_PaymentType
            CHECK (PaymentType IN ('Cash', 'Credit')),

        CONSTRAINT CK_PurchaseInvoices_Total
            CHECK (Total >= 0),

        CONSTRAINT CK_PurchaseInvoices_PaymentRules
            CHECK
            (
                (PaymentType = 'Cash' AND CashAccountId IS NOT NULL)
                OR
                (PaymentType = 'Credit' AND SupplierId IS NOT NULL AND CashAccountId IS NULL)
            )
    );

    CREATE INDEX IX_PurchaseInvoices_InvoiceDate
        ON dbo.PurchaseInvoices (InvoiceDate);

    CREATE INDEX IX_PurchaseInvoices_SupplierId
        ON dbo.PurchaseInvoices (SupplierId);

    CREATE INDEX IX_PurchaseInvoices_CashAccountId
        ON dbo.PurchaseInvoices (CashAccountId);

    /* ============================================================
       18. PurchaseItems
       ============================================================ */

    CREATE TABLE dbo.PurchaseItems
    (
        Id INT IDENTITY(1,1) NOT NULL,
        PurchaseInvoiceId INT NOT NULL,
        ItemId INT NOT NULL,
        WarehouseId INT NOT NULL,
        Qty DECIMAL(18,3) NOT NULL,
        BuyPrice DECIMAL(18,3) NOT NULL,
        SubTotal DECIMAL(18,3) NOT NULL,

        CONSTRAINT PK_PurchaseItems
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT CK_PurchaseItems_Qty
            CHECK (Qty > 0),

        CONSTRAINT CK_PurchaseItems_BuyPrice
            CHECK (BuyPrice >= 0),

        CONSTRAINT CK_PurchaseItems_SubTotal
            CHECK (SubTotal >= 0)
    );

    CREATE INDEX IX_PurchaseItems_InvoiceId
        ON dbo.PurchaseItems (PurchaseInvoiceId);

    CREATE INDEX IX_PurchaseItems_ItemId
        ON dbo.PurchaseItems (ItemId);

    CREATE INDEX IX_PurchaseItems_ItemId_WarehouseId
        ON dbo.PurchaseItems (ItemId, WarehouseId);

    CREATE INDEX IX_PurchaseItems_WarehouseId
        ON dbo.PurchaseItems (WarehouseId);

    /* ============================================================
       19. SalesInvoices
       ============================================================ */

    CREATE TABLE dbo.SalesInvoices
    (
        Id INT IDENTITY(1,1) NOT NULL,
        InvoiceDate DATETIME2(7) NOT NULL,
        CustomerId INT NULL,
        PaymentType NVARCHAR(20) NOT NULL,
        CashAccountId INT NULL,
        Total DECIMAL(18,3) NOT NULL
            CONSTRAINT DF_SalesInvoices_Total DEFAULT (0),
        IsCancelled BIT NOT NULL
            CONSTRAINT DF_SalesInvoices_IsCancelled DEFAULT (0),
        CancelledAt DATETIME2(7) NULL,
        CancelReason NVARCHAR(500) NULL,
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_SalesInvoices_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,

        CONSTRAINT PK_SalesInvoices
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT CK_SalesInvoices_PaymentType
            CHECK (PaymentType IN ('Cash', 'Credit')),

        CONSTRAINT CK_SalesInvoices_Total
            CHECK (Total >= 0),

        CONSTRAINT CK_SalesInvoices_PaymentRules
            CHECK
            (
                (PaymentType = 'Cash' AND CashAccountId IS NOT NULL)
                OR
                (PaymentType = 'Credit' AND CustomerId IS NOT NULL AND CashAccountId IS NULL)
            )
    );

    CREATE INDEX IX_SalesInvoices_InvoiceDate
        ON dbo.SalesInvoices (InvoiceDate);

    CREATE INDEX IX_SalesInvoices_CustomerId
        ON dbo.SalesInvoices (CustomerId);

    CREATE INDEX IX_SalesInvoices_CashAccountId
        ON dbo.SalesInvoices (CashAccountId);

    /* ============================================================
       20. SalesInvoiceDetails
       ============================================================ */

    CREATE TABLE dbo.SalesInvoiceDetails
    (
        Id INT IDENTITY(1,1) NOT NULL,
        SalesInvoiceId INT NOT NULL,
        ItemId INT NOT NULL,
        WarehouseId INT NOT NULL,
        Qty DECIMAL(18,3) NOT NULL,
        SellPrice DECIMAL(18,3) NOT NULL,
        SubTotal DECIMAL(18,3) NOT NULL,
        CostAtSale DECIMAL(18,3) NOT NULL,
        ProfitAtSale DECIMAL(18,3) NOT NULL,

        CONSTRAINT PK_SalesInvoiceDetails
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT CK_SalesInvoiceDetails_Qty
            CHECK (Qty > 0),

        CONSTRAINT CK_SalesInvoiceDetails_SellPrice
            CHECK (SellPrice >= 0),

        CONSTRAINT CK_SalesInvoiceDetails_SubTotal
            CHECK (SubTotal >= 0),

        CONSTRAINT CK_SalesInvoiceDetails_CostAtSale
            CHECK (CostAtSale >= 0)
    );

    CREATE INDEX IX_SalesInvoiceDetails_InvoiceId
        ON dbo.SalesInvoiceDetails (SalesInvoiceId);

    CREATE INDEX IX_SalesInvoiceDetails_ItemId
        ON dbo.SalesInvoiceDetails (ItemId);

    CREATE INDEX IX_SalesInvoiceDetails_ItemId_WarehouseId
        ON dbo.SalesInvoiceDetails (ItemId, WarehouseId);

    CREATE INDEX IX_SalesInvoiceDetails_WarehouseId
        ON dbo.SalesInvoiceDetails (WarehouseId);

    /* ============================================================
       21. StockMovements
       ============================================================ */

    CREATE TABLE dbo.StockMovements
    (
        Id INT IDENTITY(1,1) NOT NULL,
        ItemId INT NOT NULL,
        WarehouseId INT NOT NULL,
        MovementType NVARCHAR(20) NOT NULL,
        Qty DECIMAL(18,3) NOT NULL,
        UnitCost DECIMAL(18,3) NOT NULL,
        ReferenceType NVARCHAR(50) NULL,
        ReferenceId INT NULL,
        MovementDate DATETIME2(7) NOT NULL,
        Notes NVARCHAR(255) NULL,
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_StockMovements_CreatedAt DEFAULT (SYSDATETIME()),

        CONSTRAINT PK_StockMovements
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT CK_StockMovements_MovementType
            CHECK (MovementType IN ('IN', 'OUT')),

        CONSTRAINT CK_StockMovements_Qty
            CHECK (Qty > 0),

        CONSTRAINT CK_StockMovements_UnitCost
            CHECK (UnitCost >= 0)
    );

    CREATE INDEX IX_StockMovements_ItemId
        ON dbo.StockMovements (ItemId);

    CREATE INDEX IX_StockMovements_WarehouseId
        ON dbo.StockMovements (WarehouseId);

    CREATE INDEX IX_StockMovements_ItemId_WarehouseId
        ON dbo.StockMovements (ItemId, WarehouseId);

    CREATE INDEX IX_StockMovements_MovementDate
        ON dbo.StockMovements (MovementDate);

    CREATE INDEX IX_StockMovements_Reference
        ON dbo.StockMovements (ReferenceType, ReferenceId);

    /* ============================================================
       22. Payments
       ============================================================ */

    CREATE TABLE dbo.Payments
    (
        Id INT IDENTITY(1,1) NOT NULL,
        PaymentDate DATETIME2(7) NOT NULL,
        PartyType NVARCHAR(20) NOT NULL,
        PartyId INT NOT NULL,
        PaymentDirection NVARCHAR(20) NOT NULL,
        Amount DECIMAL(18,3) NOT NULL,
        CashAccountId INT NOT NULL,
        Notes NVARCHAR(500) NULL,
        IsCancelled BIT NOT NULL
            CONSTRAINT DF_Payments_IsCancelled DEFAULT (0),
        CancelledAt DATETIME2(7) NULL,
        CancelReason NVARCHAR(500) NULL,
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_Payments_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,

        CONSTRAINT PK_Payments
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT CK_Payments_PartyType
            CHECK (PartyType IN ('Customer', 'Supplier')),

        CONSTRAINT CK_Payments_Direction
            CHECK (PaymentDirection IN ('Receipt', 'Payment')),

        CONSTRAINT CK_Payments_Amount
            CHECK (Amount > 0)
    );

    CREATE INDEX IX_Payments_Date
        ON dbo.Payments (PaymentDate);

    CREATE INDEX IX_Payments_Party
        ON dbo.Payments (PartyType, PartyId);

    CREATE INDEX IX_Payments_CashAccountId
        ON dbo.Payments (CashAccountId);

    /* ============================================================
       23. InvoiceSettlements
       ============================================================ */

    CREATE TABLE dbo.InvoiceSettlements
    (
        Id INT IDENTITY(1,1) NOT NULL,
        PaymentId INT NOT NULL,
        InvoiceType NVARCHAR(20) NOT NULL,
        InvoiceId INT NOT NULL,
        SettledAmount DECIMAL(18,3) NOT NULL,
        IsCancelled BIT NOT NULL
            CONSTRAINT DF_InvoiceSettlements_IsCancelled DEFAULT (0),
        CancelledAt DATETIME2(7) NULL,
        CancelReason NVARCHAR(500) NULL,
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_InvoiceSettlements_CreatedAt DEFAULT (SYSDATETIME()),

        CONSTRAINT PK_InvoiceSettlements
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT CK_InvoiceSettlements_InvoiceType
            CHECK (InvoiceType IN ('Sale', 'Purchase')),

        CONSTRAINT CK_InvoiceSettlements_SettledAmount
            CHECK (SettledAmount > 0)
    );

    CREATE INDEX IX_InvoiceSettlements_PaymentId
        ON dbo.InvoiceSettlements (PaymentId);

    CREATE INDEX IX_InvoiceSettlements_Invoice
        ON dbo.InvoiceSettlements (InvoiceType, InvoiceId);

    /* ============================================================
       24. JournalEntries
       ============================================================ */

    CREATE TABLE dbo.JournalEntries
    (
        Id INT IDENTITY(1,1) NOT NULL,
        EntryDate DATETIME2(7) NOT NULL,
        Description NVARCHAR(500) NULL,
        ReferenceType NVARCHAR(50) NULL,
        ReferenceId INT NULL,
        TotalDebit DECIMAL(18,3) NOT NULL
            CONSTRAINT DF_JournalEntries_TotalDebit DEFAULT (0),
        TotalCredit DECIMAL(18,3) NOT NULL
            CONSTRAINT DF_JournalEntries_TotalCredit DEFAULT (0),
        IsPosted BIT NOT NULL
            CONSTRAINT DF_JournalEntries_IsPosted DEFAULT (1),
        ReversedEntryId INT NULL,
        IsReversal BIT NOT NULL
            CONSTRAINT DF_JournalEntries_IsReversal DEFAULT (0),
        OriginalReferenceType NVARCHAR(50) NULL,
        OriginalReferenceId INT NULL,
        ReversalReason NVARCHAR(500) NULL,
        Status NVARCHAR(20) NOT NULL
            CONSTRAINT DF_JournalEntries_Status DEFAULT ('Posted'),
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_JournalEntries_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,

        CONSTRAINT PK_JournalEntries
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT CK_JournalEntries_TotalDebit
            CHECK (TotalDebit >= 0),

        CONSTRAINT CK_JournalEntries_TotalCredit
            CHECK (TotalCredit >= 0),

        CONSTRAINT CK_JournalEntries_Balanced
            CHECK (TotalDebit = TotalCredit),

        CONSTRAINT CK_JournalEntries_Status
            CHECK (Status IN ('Draft', 'Posted', 'Cancelled', 'Reversed'))
    );

    CREATE INDEX IX_JournalEntries_EntryDate
        ON dbo.JournalEntries (EntryDate);

    CREATE INDEX IX_JournalEntries_Reference
        ON dbo.JournalEntries (ReferenceType, ReferenceId);

    CREATE INDEX IX_JournalEntries_OriginalReference
        ON dbo.JournalEntries (OriginalReferenceType, OriginalReferenceId);

    CREATE INDEX IX_JournalEntries_ReversedEntryId
        ON dbo.JournalEntries (ReversedEntryId);

    /* ============================================================
       25. JournalEntryLines
       ============================================================ */

    CREATE TABLE dbo.JournalEntryLines
    (
        Id INT IDENTITY(1,1) NOT NULL,
        JournalEntryId INT NOT NULL,
        AccountId INT NOT NULL,
        Debit DECIMAL(18,3) NOT NULL
            CONSTRAINT DF_JournalEntryLines_Debit DEFAULT (0),
        Credit DECIMAL(18,3) NOT NULL
            CONSTRAINT DF_JournalEntryLines_Credit DEFAULT (0),
        Description NVARCHAR(500) NULL,

        CONSTRAINT PK_JournalEntryLines
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT CK_JournalEntryLines_Debit
            CHECK (Debit >= 0),

        CONSTRAINT CK_JournalEntryLines_Credit
            CHECK (Credit >= 0),

        CONSTRAINT CK_JournalEntryLines_NotBothDebitAndCredit
            CHECK (NOT (Debit > 0 AND Credit > 0)),

        CONSTRAINT CK_JournalEntryLines_NotZeroLine
            CHECK (Debit > 0 OR Credit > 0)
    );

    CREATE INDEX IX_JournalEntryLines_JournalEntryId
        ON dbo.JournalEntryLines (JournalEntryId);

    CREATE INDEX IX_JournalEntryLines_AccountId
        ON dbo.JournalEntryLines (AccountId);

    /* ============================================================
       FOREIGN KEYS
       ============================================================ */

    ALTER TABLE dbo.Accounts
    ADD CONSTRAINT FK_Accounts_Parent
        FOREIGN KEY (ParentAccountId)
        REFERENCES dbo.Accounts (Id);

    ALTER TABLE dbo.AccountingPeriods
    ADD CONSTRAINT FK_AccountingPeriods_FiscalYears
        FOREIGN KEY (FiscalYearId)
        REFERENCES dbo.FiscalYears (Id);

    ALTER TABLE dbo.Items
    ADD CONSTRAINT FK_Items_Units
        FOREIGN KEY (UnitId)
        REFERENCES dbo.Units (Id);

    ALTER TABLE dbo.Items
    ADD CONSTRAINT FK_Items_Categories
        FOREIGN KEY (CategoryId)
        REFERENCES dbo.Categories (Id);

    ALTER TABLE dbo.Items
    ADD CONSTRAINT FK_Items_DefaultWarehouse
        FOREIGN KEY (DefaultWarehouseId)
        REFERENCES dbo.Warehouses (Id);

    ALTER TABLE dbo.ItemBarcodes
    ADD CONSTRAINT FK_ItemBarcodes_Items
        FOREIGN KEY (ItemId)
        REFERENCES dbo.Items (Id);

    ALTER TABLE dbo.ItemWarehouseCosts
    ADD CONSTRAINT FK_ItemWarehouseCosts_Items
        FOREIGN KEY (ItemId)
        REFERENCES dbo.Items (Id);

    ALTER TABLE dbo.ItemWarehouseCosts
    ADD CONSTRAINT FK_ItemWarehouseCosts_Warehouses
        FOREIGN KEY (WarehouseId)
        REFERENCES dbo.Warehouses (Id);

    ALTER TABLE dbo.Customers
    ADD CONSTRAINT FK_Customers_Account
        FOREIGN KEY (AccountId)
        REFERENCES dbo.Accounts (Id);

    ALTER TABLE dbo.Suppliers
    ADD CONSTRAINT FK_Suppliers_Account
        FOREIGN KEY (AccountId)
        REFERENCES dbo.Accounts (Id);

    ALTER TABLE dbo.OpeningBalanceItems
    ADD CONSTRAINT FK_OpeningBalanceItems_Batch
        FOREIGN KEY (OpeningBalanceBatchId)
        REFERENCES dbo.OpeningBalanceBatches (Id);

    ALTER TABLE dbo.OpeningBalanceItems
    ADD CONSTRAINT FK_OpeningBalanceItems_Items
        FOREIGN KEY (ItemId)
        REFERENCES dbo.Items (Id);

    ALTER TABLE dbo.OpeningBalanceItems
    ADD CONSTRAINT FK_OpeningBalanceItems_Warehouses
        FOREIGN KEY (WarehouseId)
        REFERENCES dbo.Warehouses (Id);

    ALTER TABLE dbo.PurchaseInvoices
    ADD CONSTRAINT FK_PurchaseInvoices_Suppliers
        FOREIGN KEY (SupplierId)
        REFERENCES dbo.Suppliers (Id);

    ALTER TABLE dbo.PurchaseInvoices
    ADD CONSTRAINT FK_PurchaseInvoices_CashAccount
        FOREIGN KEY (CashAccountId)
        REFERENCES dbo.Accounts (Id);

    ALTER TABLE dbo.PurchaseItems
    ADD CONSTRAINT FK_PurchaseItems_Invoice
        FOREIGN KEY (PurchaseInvoiceId)
        REFERENCES dbo.PurchaseInvoices (Id);

    ALTER TABLE dbo.PurchaseItems
    ADD CONSTRAINT FK_PurchaseItems_Items
        FOREIGN KEY (ItemId)
        REFERENCES dbo.Items (Id);

    ALTER TABLE dbo.PurchaseItems
    ADD CONSTRAINT FK_PurchaseItems_Warehouses
        FOREIGN KEY (WarehouseId)
        REFERENCES dbo.Warehouses (Id);

    ALTER TABLE dbo.SalesInvoices
    ADD CONSTRAINT FK_SalesInvoices_Customers
        FOREIGN KEY (CustomerId)
        REFERENCES dbo.Customers (Id);

    ALTER TABLE dbo.SalesInvoices
    ADD CONSTRAINT FK_SalesInvoices_CashAccount
        FOREIGN KEY (CashAccountId)
        REFERENCES dbo.Accounts (Id);

    ALTER TABLE dbo.SalesInvoiceDetails
    ADD CONSTRAINT FK_SalesInvoiceDetails_Invoice
        FOREIGN KEY (SalesInvoiceId)
        REFERENCES dbo.SalesInvoices (Id);

    ALTER TABLE dbo.SalesInvoiceDetails
    ADD CONSTRAINT FK_SalesInvoiceDetails_Items
        FOREIGN KEY (ItemId)
        REFERENCES dbo.Items (Id);

    ALTER TABLE dbo.SalesInvoiceDetails
    ADD CONSTRAINT FK_SalesInvoiceDetails_Warehouses
        FOREIGN KEY (WarehouseId)
        REFERENCES dbo.Warehouses (Id);

    ALTER TABLE dbo.StockMovements
    ADD CONSTRAINT FK_StockMovements_Items
        FOREIGN KEY (ItemId)
        REFERENCES dbo.Items (Id);

    ALTER TABLE dbo.StockMovements
    ADD CONSTRAINT FK_StockMovements_Warehouses
        FOREIGN KEY (WarehouseId)
        REFERENCES dbo.Warehouses (Id);

    ALTER TABLE dbo.Payments
    ADD CONSTRAINT FK_Payments_CashAccount
        FOREIGN KEY (CashAccountId)
        REFERENCES dbo.Accounts (Id);

    ALTER TABLE dbo.InvoiceSettlements
    ADD CONSTRAINT FK_InvoiceSettlements_Payments
        FOREIGN KEY (PaymentId)
        REFERENCES dbo.Payments (Id);

    ALTER TABLE dbo.JournalEntries
    ADD CONSTRAINT FK_JournalEntries_ReversedEntry
        FOREIGN KEY (ReversedEntryId)
        REFERENCES dbo.JournalEntries (Id);

    ALTER TABLE dbo.JournalEntryLines
    ADD CONSTRAINT FK_JournalEntryLines_Entry
        FOREIGN KEY (JournalEntryId)
        REFERENCES dbo.JournalEntries (Id);

    ALTER TABLE dbo.JournalEntryLines
    ADD CONSTRAINT FK_JournalEntryLines_Account
        FOREIGN KEY (AccountId)
        REFERENCES dbo.Accounts (Id);

    /* ============================================================
       FINAL VALIDATION
       ============================================================ */

    IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'SchemaMigrations' AND schema_id = SCHEMA_ID('dbo'))
        THROW 51010, 'Final validation failed: SchemaMigrations table was not created.', 1;

    IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'Items' AND schema_id = SCHEMA_ID('dbo'))
        THROW 51011, 'Final validation failed: Items table was not created.', 1;

    IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'StockMovements' AND schema_id = SCHEMA_ID('dbo'))
        THROW 51012, 'Final validation failed: StockMovements table was not created.', 1;

    IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'JournalEntries' AND schema_id = SCHEMA_ID('dbo'))
        THROW 51013, 'Final validation failed: JournalEntries table was not created.', 1;

    IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'ItemWarehouseCosts' AND schema_id = SCHEMA_ID('dbo'))
        THROW 51014, 'Final validation failed: ItemWarehouseCosts table was not created.', 1;

    IF NOT EXISTS (SELECT 1 FROM sys.tables WHERE name = 'OpeningBalanceItems' AND schema_id = SCHEMA_ID('dbo'))
        THROW 51015, 'Final validation failed: OpeningBalanceItems table was not created.', 1;

    -- Baseline registration is intentionally not inserted here.
    -- MigrationRunnerService will register this script later after runner upgrade.

    COMMIT TRANSACTION;

    PRINT '001_CleanBaseline completed successfully.';

END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;

    DECLARE @ErrorMessage NVARCHAR(2048) = ERROR_MESSAGE();

    THROW 51099, @ErrorMessage, 1;
END CATCH;
