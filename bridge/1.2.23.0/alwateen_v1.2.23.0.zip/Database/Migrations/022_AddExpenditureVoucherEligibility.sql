/*
022_AddExpenditureVoucherEligibility.sql

Extends the immutable general-expense voucher contract with fixed-asset
and controlled other-disbursement kinds. Adds explicit account eligibility
without creating business accounts or changing historical voucher kinds.
*/

SET XACT_ABORT ON;

------------------------------------------------------------
-- GeneralExpenseVouchers: supported kinds
------------------------------------------------------------

IF EXISTS
(
    SELECT 1
    FROM dbo.GeneralExpenseVouchers
    WHERE ExpenseKind NOT IN
    (
        N'BusinessExpense',
        N'OwnerWithdrawal',
        N'FixedAssetPurchase',
        N'OtherDisbursement'
    )
)
BEGIN
    THROW 52201,
        N'Migration 022 aborted: unsupported historical expense voucher kind exists.',
        1;
END;

IF EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE parent_object_id = OBJECT_ID(N'dbo.GeneralExpenseVouchers')
      AND name = N'CK_GeneralExpenseVouchers_ExpenseKind'
)
BEGIN
    ALTER TABLE dbo.GeneralExpenseVouchers
        DROP CONSTRAINT CK_GeneralExpenseVouchers_ExpenseKind;
END;

ALTER TABLE dbo.GeneralExpenseVouchers WITH CHECK
    ADD CONSTRAINT CK_GeneralExpenseVouchers_ExpenseKind
    CHECK
    (
        ExpenseKind IN
        (
            N'BusinessExpense',
            N'OwnerWithdrawal',
            N'FixedAssetPurchase',
            N'OtherDisbursement'
        )
    );

------------------------------------------------------------
-- Explicit account eligibility
------------------------------------------------------------

IF OBJECT_ID(N'dbo.ExpenditureVoucherAccountEligibility', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ExpenditureVoucherAccountEligibility
    (
        Id INT IDENTITY(1,1) NOT NULL,
        AccountId INT NOT NULL,
        EligibilityRole NVARCHAR(40) NOT NULL,
        IsActive BIT NOT NULL
            CONSTRAINT DF_ExpenditureVoucherAccountEligibility_IsActive
            DEFAULT (1),
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_ExpenditureVoucherAccountEligibility_CreatedAt
            DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,

        CONSTRAINT PK_ExpenditureVoucherAccountEligibility
            PRIMARY KEY (Id),

        CONSTRAINT CK_ExpenditureVoucherAccountEligibility_Role
            CHECK
            (
                EligibilityRole IN
                (
                    N'OperatingExpense',
                    N'FixedAssetPurchase',
                    N'OtherDisbursement',
                    N'PaymentAccount'
                )
            )
    );
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE parent_object_id = OBJECT_ID(N'dbo.ExpenditureVoucherAccountEligibility')
      AND name = N'FK_ExpenditureVoucherAccountEligibility_Account'
)
BEGIN
    ALTER TABLE dbo.ExpenditureVoucherAccountEligibility WITH CHECK
        ADD CONSTRAINT FK_ExpenditureVoucherAccountEligibility_Account
        FOREIGN KEY (AccountId)
        REFERENCES dbo.Accounts(Id);
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.ExpenditureVoucherAccountEligibility')
      AND name = N'UQ_ExpenditureVoucherAccountEligibility_AccountRole'
)
BEGIN
    CREATE UNIQUE INDEX UQ_ExpenditureVoucherAccountEligibility_AccountRole
        ON dbo.ExpenditureVoucherAccountEligibility(AccountId, EligibilityRole);
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.ExpenditureVoucherAccountEligibility')
      AND name = N'IX_ExpenditureVoucherAccountEligibility_RoleActive'
)
BEGIN
    CREATE INDEX IX_ExpenditureVoucherAccountEligibility_RoleActive
        ON dbo.ExpenditureVoucherAccountEligibility(EligibilityRole, IsActive, AccountId);
END;

------------------------------------------------------------
-- Initial eligibility for accounts that already exist and
-- satisfy the approved leaf/type contract. No account is created.
------------------------------------------------------------

DECLARE @ApprovedEligibility TABLE
(
    AccountNumber NVARCHAR(50) NOT NULL,
    EligibilityRole NVARCHAR(40) NOT NULL,
    RequiredAccountType NVARCHAR(50) NOT NULL,
    PRIMARY KEY (AccountNumber, EligibilityRole)
);

INSERT INTO @ApprovedEligibility
(
    AccountNumber,
    EligibilityRole,
    RequiredAccountType
)
VALUES
    (N'5610', N'OperatingExpense', N'Expense'),
    (N'5620', N'OperatingExpense', N'Expense'),
    (N'5630', N'OperatingExpense', N'Expense'),
    (N'1410', N'FixedAssetPurchase', N'Asset'),
    (N'1420', N'FixedAssetPurchase', N'Asset'),
    (N'1100', N'PaymentAccount', N'Asset'),
    (N'1200', N'PaymentAccount', N'Asset');

INSERT INTO dbo.ExpenditureVoucherAccountEligibility
(
    AccountId,
    EligibilityRole,
    IsActive
)
SELECT
    account.Id,
    approved.EligibilityRole,
    1
FROM @ApprovedEligibility approved
INNER JOIN dbo.Accounts account
    ON account.AccountNumber = approved.AccountNumber
   AND account.AccountType = approved.RequiredAccountType
   AND account.IsActive = 1
   AND account.CanPost = 1
WHERE NOT EXISTS
(
    SELECT 1
    FROM dbo.Accounts child
    WHERE child.ParentAccountId = account.Id
      AND child.IsActive = 1
)
AND NOT EXISTS
(
    SELECT 1
    FROM dbo.ExpenditureVoucherAccountEligibility existing
    WHERE existing.AccountId = account.Id
      AND existing.EligibilityRole = approved.EligibilityRole
);

------------------------------------------------------------
-- Controlled other-disbursement permission
------------------------------------------------------------

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.Permissions
    WHERE PermissionCode = N'ExpenseVouchers.CreateOtherDisbursement'
)
BEGIN
    INSERT INTO dbo.Permissions
    (
        PermissionCode,
        PermissionName,
        ModuleName
    )
    VALUES
    (
        N'ExpenseVouchers.CreateOtherDisbursement',
        N'Create controlled other disbursement vouchers',
        N'Accounting'
    );
END;

INSERT INTO dbo.RolePermissions
(
    RoleId,
    PermissionId
)
SELECT
    role.Id,
    permission.Id
FROM dbo.Roles role
CROSS JOIN dbo.Permissions permission
WHERE role.RoleCode = N'ADMIN'
  AND permission.PermissionCode = N'ExpenseVouchers.CreateOtherDisbursement'
  AND NOT EXISTS
  (
      SELECT 1
      FROM dbo.RolePermissions existing
      WHERE existing.RoleId = role.Id
        AND existing.PermissionId = permission.Id
  );
