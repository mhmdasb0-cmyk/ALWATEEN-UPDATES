/*
021_AddManualJournalOperations.sql

Adds immutable manual-journal audit/idempotency metadata and four
ADMIN-only operational permissions. No default accounting account is
created or selected by this migration.
*/

SET XACT_ABORT ON;

------------------------------------------------------------
-- JournalEntries: manual journal metadata
------------------------------------------------------------

IF COL_LENGTH(N'dbo.JournalEntries', N'SubmissionKey') IS NULL
BEGIN
    EXEC(N'
        ALTER TABLE dbo.JournalEntries
        ADD SubmissionKey UNIQUEIDENTIFIER NULL;
    ');
END;

IF COL_LENGTH(N'dbo.JournalEntries', N'ManualReference') IS NULL
BEGIN
    EXEC(N'
        ALTER TABLE dbo.JournalEntries
        ADD ManualReference NVARCHAR(100) NULL;
    ');
END;

IF COL_LENGTH(N'dbo.JournalEntries', N'CreatedByUserId') IS NULL
BEGIN
    EXEC(N'
        ALTER TABLE dbo.JournalEntries
        ADD CreatedByUserId INT NULL;
    ');
END;

IF COL_LENGTH(N'dbo.JournalEntries', N'CreatedByUsername') IS NULL
BEGIN
    EXEC(N'
        ALTER TABLE dbo.JournalEntries
        ADD CreatedByUsername NVARCHAR(100) NULL;
    ');
END;

------------------------------------------------------------
-- SubmissionKey uniqueness
------------------------------------------------------------

EXEC(N'
IF EXISTS
(
    SELECT SubmissionKey
    FROM dbo.JournalEntries
    WHERE SubmissionKey IS NOT NULL
    GROUP BY SubmissionKey
    HAVING COUNT(*) > 1
)
BEGIN
    THROW 52101,
        N''Migration 021 aborted: duplicate manual-journal submission keys exist.'',
        1;
END;
');

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.JournalEntries')
      AND name = N'UQ_JournalEntries_SubmissionKey'
)
BEGIN
    EXEC(N'
        CREATE UNIQUE INDEX UQ_JournalEntries_SubmissionKey
        ON dbo.JournalEntries(SubmissionKey)
        WHERE SubmissionKey IS NOT NULL;
    ');
END;

------------------------------------------------------------
-- ManualReference uniqueness for original manual entries
------------------------------------------------------------

EXEC(N'
IF EXISTS
(
    SELECT ManualReference
    FROM dbo.JournalEntries
    WHERE ReferenceType = N''ManualEntry''
      AND IsReversal = 0
      AND ManualReference IS NOT NULL
    GROUP BY ManualReference
    HAVING COUNT(*) > 1
)
BEGIN
    THROW 52102,
        N''Migration 021 aborted: duplicate manual-journal references exist.'',
        1;
END;
');

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.JournalEntries')
      AND name = N'UQ_JournalEntries_ManualReference'
)
BEGIN
    EXEC(N'
        CREATE UNIQUE INDEX UQ_JournalEntries_ManualReference
        ON dbo.JournalEntries(ManualReference)
        WHERE ReferenceType = N''ManualEntry''
          AND IsReversal = 0
          AND ManualReference IS NOT NULL;
    ');
END;

------------------------------------------------------------
-- One reversal per original journal
------------------------------------------------------------

IF EXISTS
(
    SELECT ReversedEntryId
    FROM dbo.JournalEntries
    WHERE IsReversal = 1
      AND ReversedEntryId IS NOT NULL
    GROUP BY ReversedEntryId
    HAVING COUNT(*) > 1
)
BEGIN
    THROW 52103,
        N'Migration 021 aborted: duplicate journal reversals exist.',
        1;
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.JournalEntries')
      AND name = N'UQ_JournalEntries_ReversedEntryId'
)
BEGIN
    CREATE UNIQUE INDEX UQ_JournalEntries_ReversedEntryId
    ON dbo.JournalEntries(ReversedEntryId)
    WHERE IsReversal = 1
      AND ReversedEntryId IS NOT NULL;
END;

------------------------------------------------------------
-- Audit user FK
------------------------------------------------------------

IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE name = N'FK_JournalEntries_CreatedByUser'
      AND parent_object_id = OBJECT_ID(N'dbo.JournalEntries')
)
BEGIN
    EXEC(N'
        ALTER TABLE dbo.JournalEntries
        ADD CONSTRAINT FK_JournalEntries_CreatedByUser
        FOREIGN KEY (CreatedByUserId)
        REFERENCES dbo.Users(Id);
    ');
END;

------------------------------------------------------------
-- Manual journal permissions
------------------------------------------------------------

DECLARE @ManualJournalPermissions TABLE
(
    PermissionCode NVARCHAR(150) NOT NULL PRIMARY KEY,
    PermissionName NVARCHAR(200) NOT NULL
);

INSERT INTO @ManualJournalPermissions
(
    PermissionCode,
    PermissionName
)
VALUES
    (N'ManualJournal.View',    N'View manual journal entries'),
    (N'ManualJournal.Create',  N'Create and post manual journal entries'),
    (N'ManualJournal.Reverse', N'Reverse manual journal entries'),
    (N'ManualJournal.Print',   N'Print manual journal entries');

INSERT INTO dbo.Permissions
(
    PermissionCode,
    PermissionName,
    ModuleName
)
SELECT
    source.PermissionCode,
    source.PermissionName,
    N'Accounting'
FROM @ManualJournalPermissions source
WHERE NOT EXISTS
(
    SELECT 1
    FROM dbo.Permissions existing
    WHERE existing.PermissionCode = source.PermissionCode
);

------------------------------------------------------------
-- ADMIN only
------------------------------------------------------------

INSERT INTO dbo.RolePermissions
(
    RoleId,
    PermissionId
)
SELECT
    role.Id,
    permission.Id
FROM dbo.Roles role
CROSS JOIN dbo.Permissions permission
WHERE role.RoleCode = N'ADMIN'
  AND permission.PermissionCode IN
  (
      N'ManualJournal.View',
      N'ManualJournal.Create',
      N'ManualJournal.Reverse',
      N'ManualJournal.Print'
  )
  AND NOT EXISTS
  (
      SELECT 1
      FROM dbo.RolePermissions existing
      WHERE existing.RoleId = role.Id
        AND existing.PermissionId = permission.Id
  );
