﻿/* =========================================================
   001_AddOpeningBalanceBatchFkAndAccountsParentIndex.sql

   Purpose:
   - Add missing FK:
     OpeningBalanceItems.<Batch Column> -> OpeningBalanceBatches.Id

   - Add supporting index:
     Accounts.ParentAccountId

   Rules:
   - Idempotent
   - No data deletion
   - Safe with different Batch column names
   ========================================================= */

SET NOCOUNT ON;

------------------------------------------------------------
-- 01 - Validate required tables
------------------------------------------------------------

IF OBJECT_ID(N'dbo.OpeningBalanceItems', N'U') IS NULL
BEGIN
    THROW 70101, 'Table dbo.OpeningBalanceItems does not exist.', 1;
END;

IF OBJECT_ID(N'dbo.OpeningBalanceBatches', N'U') IS NULL
BEGIN
    THROW 70102, 'Table dbo.OpeningBalanceBatches does not exist.', 1;
END;

IF OBJECT_ID(N'dbo.Accounts', N'U') IS NULL
BEGIN
    THROW 70103, 'Table dbo.Accounts does not exist.', 1;
END;

------------------------------------------------------------
-- 02 - Detect actual batch column name
------------------------------------------------------------

DECLARE @BatchColumn SYSNAME;

IF COL_LENGTH(N'dbo.OpeningBalanceItems', N'BatchId') IS NOT NULL
BEGIN
    SET @BatchColumn = N'BatchId';
END;
ELSE IF COL_LENGTH(N'dbo.OpeningBalanceItems', N'OpeningBalanceBatchId') IS NOT NULL
BEGIN
    SET @BatchColumn = N'OpeningBalanceBatchId';
END;
ELSE
BEGIN
    THROW 70104, 'No valid batch column found in dbo.OpeningBalanceItems. Expected BatchId or OpeningBalanceBatchId.', 1;
END;

------------------------------------------------------------
-- 03 - Validate parent Id column
------------------------------------------------------------

IF COL_LENGTH(N'dbo.OpeningBalanceBatches', N'Id') IS NULL
BEGIN
    THROW 70105, 'Column dbo.OpeningBalanceBatches.Id does not exist.', 1;
END;

------------------------------------------------------------
-- 04 - Validate Accounts.ParentAccountId column
------------------------------------------------------------

IF COL_LENGTH(N'dbo.Accounts', N'ParentAccountId') IS NULL
BEGIN
    THROW 70106, 'Column dbo.Accounts.ParentAccountId does not exist.', 1;
END;

------------------------------------------------------------
-- 05 - Stop if orphan opening balance items exist
------------------------------------------------------------

DECLARE @OrphanCount INT = 0;

DECLARE @OrphanSql NVARCHAR(MAX) = N'
SELECT
    @OrphanCountOutput = COUNT(1)
FROM dbo.OpeningBalanceItems obi
LEFT JOIN dbo.OpeningBalanceBatches obb
    ON obb.Id = obi.' + QUOTENAME(@BatchColumn) + N'
WHERE
    obi.' + QUOTENAME(@BatchColumn) + N' IS NOT NULL
    AND obb.Id IS NULL;
';

EXEC sp_executesql
    @OrphanSql,
    N'@OrphanCountOutput INT OUTPUT',
    @OrphanCountOutput = @OrphanCount OUTPUT;

IF @OrphanCount > 0
BEGIN
    THROW 70107, 'Cannot add FK_OpeningBalanceItems_Batches because orphan OpeningBalanceItems rows exist.', 1;
END;

------------------------------------------------------------
-- 06 - Add FK if missing
------------------------------------------------------------

IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE name = N'FK_OpeningBalanceItems_Batches'
      AND parent_object_id = OBJECT_ID(N'dbo.OpeningBalanceItems')
)
BEGIN
    DECLARE @FkSql NVARCHAR(MAX) = N'
ALTER TABLE dbo.OpeningBalanceItems WITH CHECK
ADD CONSTRAINT FK_OpeningBalanceItems_Batches
    FOREIGN KEY (' + QUOTENAME(@BatchColumn) + N')
    REFERENCES dbo.OpeningBalanceBatches (Id);

ALTER TABLE dbo.OpeningBalanceItems
CHECK CONSTRAINT FK_OpeningBalanceItems_Batches;
';

    EXEC sp_executesql @FkSql;
END;

------------------------------------------------------------
-- 07 - Add supporting index for Accounts.ParentAccountId
------------------------------------------------------------

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'IX_Accounts_ParentAccountId'
      AND object_id = OBJECT_ID(N'dbo.Accounts')
)
BEGIN
    CREATE INDEX IX_Accounts_ParentAccountId
        ON dbo.Accounts (ParentAccountId);
END;