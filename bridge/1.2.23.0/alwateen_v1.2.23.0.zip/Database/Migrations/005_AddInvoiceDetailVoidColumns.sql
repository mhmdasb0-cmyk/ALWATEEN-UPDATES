﻿PRINT '005_AddInvoiceDetailVoidColumns.sql started';

BEGIN TRY
    BEGIN TRANSACTION;

    /* ============================================================
       PurchaseItems - Void columns
       ============================================================ */

    IF COL_LENGTH('dbo.PurchaseItems', 'IsVoided') IS NULL
    BEGIN
        ALTER TABLE dbo.PurchaseItems
        ADD IsVoided BIT NOT NULL
            CONSTRAINT DF_PurchaseItems_IsVoided DEFAULT (0);
    END;

    IF COL_LENGTH('dbo.PurchaseItems', 'VoidedAt') IS NULL
    BEGIN
        ALTER TABLE dbo.PurchaseItems
        ADD VoidedAt DATETIME2 NULL;
    END;

    IF COL_LENGTH('dbo.PurchaseItems', 'VoidReason') IS NULL
    BEGIN
        ALTER TABLE dbo.PurchaseItems
        ADD VoidReason NVARCHAR(500) NULL;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM sys.check_constraints
        WHERE name = 'CK_PurchaseItems_VoidState'
          AND parent_object_id = OBJECT_ID('dbo.PurchaseItems')
    )
    BEGIN
        EXEC(N'
ALTER TABLE dbo.PurchaseItems
WITH CHECK
ADD CONSTRAINT CK_PurchaseItems_VoidState
CHECK
(
    (
        IsVoided = 0
        AND VoidedAt IS NULL
        AND VoidReason IS NULL
    )
    OR
    (
        IsVoided = 1
        AND VoidedAt IS NOT NULL
        AND NULLIF(LTRIM(RTRIM(ISNULL(VoidReason, N''''))), N'''') IS NOT NULL
    )
);');
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM sys.indexes
        WHERE name = 'IX_PurchaseItems_Invoice_Active'
          AND object_id = OBJECT_ID('dbo.PurchaseItems')
    )
    BEGIN
        EXEC(N'
CREATE INDEX IX_PurchaseItems_Invoice_Active
ON dbo.PurchaseItems (PurchaseInvoiceId)
INCLUDE (ItemId, WarehouseId, Qty, BuyPrice, SubTotal)
WHERE IsVoided = 0;');
    END;


    /* ============================================================
       SalesInvoiceDetails - Void columns
       ============================================================ */

    IF COL_LENGTH('dbo.SalesInvoiceDetails', 'IsVoided') IS NULL
    BEGIN
        ALTER TABLE dbo.SalesInvoiceDetails
        ADD IsVoided BIT NOT NULL
            CONSTRAINT DF_SalesInvoiceDetails_IsVoided DEFAULT (0);
    END;

    IF COL_LENGTH('dbo.SalesInvoiceDetails', 'VoidedAt') IS NULL
    BEGIN
        ALTER TABLE dbo.SalesInvoiceDetails
        ADD VoidedAt DATETIME2 NULL;
    END;

    IF COL_LENGTH('dbo.SalesInvoiceDetails', 'VoidReason') IS NULL
    BEGIN
        ALTER TABLE dbo.SalesInvoiceDetails
        ADD VoidReason NVARCHAR(500) NULL;
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM sys.check_constraints
        WHERE name = 'CK_SalesInvoiceDetails_VoidState'
          AND parent_object_id = OBJECT_ID('dbo.SalesInvoiceDetails')
    )
    BEGIN
        EXEC(N'
ALTER TABLE dbo.SalesInvoiceDetails
WITH CHECK
ADD CONSTRAINT CK_SalesInvoiceDetails_VoidState
CHECK
(
    (
        IsVoided = 0
        AND VoidedAt IS NULL
        AND VoidReason IS NULL
    )
    OR
    (
        IsVoided = 1
        AND VoidedAt IS NOT NULL
        AND NULLIF(LTRIM(RTRIM(ISNULL(VoidReason, N''''))), N'''') IS NOT NULL
    )
);');
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM sys.indexes
        WHERE name = 'IX_SalesInvoiceDetails_Invoice_Active'
          AND object_id = OBJECT_ID('dbo.SalesInvoiceDetails')
    )
    BEGIN
        EXEC(N'
CREATE INDEX IX_SalesInvoiceDetails_Invoice_Active
ON dbo.SalesInvoiceDetails (SalesInvoiceId)
INCLUDE (ItemId, WarehouseId, Qty, SellPrice, CostAtSale, ProfitAtSale, SubTotal)
WHERE IsVoided = 0;');
    END;

    COMMIT TRANSACTION;

    PRINT '005_AddInvoiceDetailVoidColumns.sql completed successfully';
END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;

    PRINT '005_AddInvoiceDetailVoidColumns.sql failed';
    THROW;
END CATCH;