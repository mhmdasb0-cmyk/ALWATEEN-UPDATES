SET XACT_ABORT ON;
SET NOCOUNT ON;

IF OBJECT_ID(N'dbo.SalesInvoices', N'U') IS NULL
   OR OBJECT_ID(N'dbo.SalesInvoiceDetails', N'U') IS NULL
   OR OBJECT_ID(N'dbo.ElectronicServiceDefinitions', N'U') IS NULL
   OR OBJECT_ID(N'dbo.ElectronicServiceWallets', N'U') IS NULL
   OR OBJECT_ID(N'dbo.ElectronicServiceWalletMovements', N'U') IS NULL
BEGIN
    THROW 72401, 'Migration 024 prerequisites are missing.', 1;
END;

------------------------------------------------------------
-- Stable sales submission identity
------------------------------------------------------------

IF COL_LENGTH(N'dbo.SalesInvoices', N'SubmissionKey') IS NULL
    ALTER TABLE dbo.SalesInvoices ADD SubmissionKey UNIQUEIDENTIFIER NULL;

IF COL_LENGTH(N'dbo.SalesInvoices', N'SubmissionHash') IS NULL
    ALTER TABLE dbo.SalesInvoices ADD SubmissionHash VARBINARY(32) NULL;

GO

IF NOT EXISTS
(
    SELECT 1 FROM sys.check_constraints
    WHERE parent_object_id=OBJECT_ID(N'dbo.SalesInvoices')
      AND name=N'CK_SalesInvoices_SubmissionIdentity'
)
BEGIN
    ALTER TABLE dbo.SalesInvoices WITH CHECK
    ADD CONSTRAINT CK_SalesInvoices_SubmissionIdentity CHECK
    (
        (SubmissionKey IS NULL AND SubmissionHash IS NULL)
        OR (SubmissionKey IS NOT NULL AND DATALENGTH(SubmissionHash)=32)
    );
END;

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE object_id=OBJECT_ID(N'dbo.SalesInvoices')
      AND name=N'UX_SalesInvoices_SubmissionKey'
)
BEGIN
    CREATE UNIQUE INDEX UX_SalesInvoices_SubmissionKey
        ON dbo.SalesInvoices(SubmissionKey)
        WHERE SubmissionKey IS NOT NULL;
END;

------------------------------------------------------------
-- Mixed inventory/electronic sales lines
------------------------------------------------------------

IF COL_LENGTH(N'dbo.SalesInvoiceDetails', N'LineKind') IS NULL
BEGIN
    ALTER TABLE dbo.SalesInvoiceDetails
        ADD LineKind NVARCHAR(30) NOT NULL
            CONSTRAINT DF_SalesInvoiceDetails_LineKind DEFAULT(N'Inventory') WITH VALUES;
END;

IF EXISTS
(
    SELECT 1 FROM sys.columns
    WHERE object_id=OBJECT_ID(N'dbo.SalesInvoiceDetails')
      AND name=N'WarehouseId'
      AND is_nullable=0
)
BEGIN
    ALTER TABLE dbo.SalesInvoiceDetails ALTER COLUMN WarehouseId INT NULL;
END;

GO

IF NOT EXISTS
(
    SELECT 1 FROM sys.check_constraints
    WHERE parent_object_id=OBJECT_ID(N'dbo.SalesInvoiceDetails')
      AND name=N'CK_SalesInvoiceDetails_LineKindWarehouse'
)
BEGIN
    ALTER TABLE dbo.SalesInvoiceDetails WITH CHECK
    ADD CONSTRAINT CK_SalesInvoiceDetails_LineKindWarehouse CHECK
    (
        (LineKind=N'Inventory' AND WarehouseId IS NOT NULL)
        OR (LineKind=N'ElectronicService' AND WarehouseId IS NULL)
    );
END;

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE object_id=OBJECT_ID(N'dbo.SalesInvoiceDetails')
      AND name=N'IX_SalesInvoiceDetails_Invoice_LineKind_Active'
)
BEGIN
    CREATE INDEX IX_SalesInvoiceDetails_Invoice_LineKind_Active
        ON dbo.SalesInvoiceDetails(SalesInvoiceId,LineKind,IsVoided,Id);
END;

------------------------------------------------------------
-- Immutable electronic-service sale evidence
------------------------------------------------------------

IF OBJECT_ID(N'dbo.ElectronicServiceSaleSnapshots', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ElectronicServiceSaleSnapshots
    (
        Id BIGINT IDENTITY(1,1) NOT NULL,
        SalesInvoiceId INT NOT NULL,
        SalesInvoiceDetailId INT NOT NULL,
        CategoryId INT NOT NULL,
        CategoryName NVARCHAR(200) NOT NULL,
        ProviderId INT NOT NULL,
        ProviderName NVARCHAR(200) NOT NULL,
        ServiceId INT NOT NULL,
        ServiceDisplayName NVARCHAR(200) NOT NULL,
        WalletId INT NOT NULL,
        WalletName NVARCHAR(150) NOT NULL,
        BarcodeUsed NVARCHAR(100) NOT NULL,
        NominalValue DECIMAL(19,4) NULL,
        ServiceLabel NVARCHAR(150) NULL,
        Quantity DECIMAL(18,3) NOT NULL,
        UnitOperationalCost DECIMAL(19,4) NOT NULL,
        TotalOperationalCost DECIMAL(19,4) NOT NULL,
        UnitSellingPrice DECIMAL(18,3) NOT NULL,
        TotalSellingPrice DECIMAL(18,3) NOT NULL,
        UnitAccountingCost DECIMAL(19,4) NOT NULL,
        TotalAccountingCost DECIMAL(19,4) NOT NULL,
        OperationalMargin DECIMAL(19,4) NOT NULL,
        AccountingProfit DECIMAL(19,4) NOT NULL,
        PriceVersion INT NOT NULL,
        OperationalBalanceBefore DECIMAL(19,4) NOT NULL,
        OperationalBalanceAfter DECIMAL(19,4) NOT NULL,
        BookBalanceBefore DECIMAL(19,4) NOT NULL,
        BookBalanceAfter DECIMAL(19,4) NOT NULL,
        SoldByUserId INT NOT NULL,
        SoldAt DATETIME2(7) NOT NULL CONSTRAINT DF_ElectronicServiceSaleSnapshots_SoldAt DEFAULT(SYSDATETIME()),
        Status NVARCHAR(30) NOT NULL,
        CorrectionState NVARCHAR(40) NOT NULL,
        CONSTRAINT PK_ElectronicServiceSaleSnapshots PRIMARY KEY(Id),
        CONSTRAINT UQ_ElectronicServiceSaleSnapshots_Detail UNIQUE(SalesInvoiceDetailId),
        CONSTRAINT FK_ElectronicServiceSaleSnapshots_Invoice FOREIGN KEY(SalesInvoiceId)
            REFERENCES dbo.SalesInvoices(Id),
        CONSTRAINT FK_ElectronicServiceSaleSnapshots_Detail FOREIGN KEY(SalesInvoiceDetailId)
            REFERENCES dbo.SalesInvoiceDetails(Id),
        CONSTRAINT FK_ElectronicServiceSaleSnapshots_User FOREIGN KEY(SoldByUserId)
            REFERENCES dbo.Users(Id),
        CONSTRAINT CK_ElectronicServiceSaleSnapshots_Quantity CHECK
            (Quantity>0 AND Quantity=FLOOR(Quantity)),
        CONSTRAINT CK_ElectronicServiceSaleSnapshots_Values CHECK
        (
            UnitOperationalCost>0 AND TotalOperationalCost>0
            AND UnitSellingPrice>0 AND TotalSellingPrice>0
            AND UnitAccountingCost>=0 AND TotalAccountingCost>=0
            AND PriceVersion>=1
            AND OperationalBalanceBefore>=OperationalBalanceAfter
            AND BookBalanceBefore>=BookBalanceAfter
            AND OperationalBalanceAfter>=0 AND BookBalanceAfter>=0
        ),
        CONSTRAINT CK_ElectronicServiceSaleSnapshots_State CHECK
        (
            Status=N'Completed'
            AND CorrectionState IN
            (
                N'OriginalCompleted', N'FinancialCorrectionRequired',
                N'ProviderRestored', N'NonRestorable'
            )
        )
    );

    CREATE INDEX IX_ElectronicServiceSaleSnapshots_Invoice
        ON dbo.ElectronicServiceSaleSnapshots(SalesInvoiceId,Id);
    CREATE INDEX IX_ElectronicServiceSaleSnapshots_Report
        ON dbo.ElectronicServiceSaleSnapshots(SoldAt,ProviderId,ServiceId);
END;

------------------------------------------------------------
-- Wallet subledger now supports one sale movement per wallet
------------------------------------------------------------

IF EXISTS
(
    SELECT 1 FROM sys.key_constraints
    WHERE parent_object_id=OBJECT_ID(N'dbo.ElectronicServiceWalletMovements')
      AND name=N'UQ_ElectronicServiceWalletMovements_SubmissionKey'
)
    ALTER TABLE dbo.ElectronicServiceWalletMovements
        DROP CONSTRAINT UQ_ElectronicServiceWalletMovements_SubmissionKey;

IF EXISTS
(
    SELECT 1 FROM sys.key_constraints
    WHERE parent_object_id=OBJECT_ID(N'dbo.ElectronicServiceWalletMovements')
      AND name=N'UQ_ElectronicServiceWalletMovements_Reference'
)
    ALTER TABLE dbo.ElectronicServiceWalletMovements
        DROP CONSTRAINT UQ_ElectronicServiceWalletMovements_Reference;

IF EXISTS
(
    SELECT 1 FROM sys.check_constraints
    WHERE parent_object_id=OBJECT_ID(N'dbo.ElectronicServiceWalletMovements')
      AND name=N'CK_ElectronicServiceWalletMovements_Type'
)
    ALTER TABLE dbo.ElectronicServiceWalletMovements
        DROP CONSTRAINT CK_ElectronicServiceWalletMovements_Type;

IF EXISTS
(
    SELECT 1 FROM sys.check_constraints
    WHERE parent_object_id=OBJECT_ID(N'dbo.ElectronicServiceWalletMovements')
      AND name=N'CK_ElectronicServiceWalletMovements_Balances'
)
    ALTER TABLE dbo.ElectronicServiceWalletMovements
        DROP CONSTRAINT CK_ElectronicServiceWalletMovements_Balances;

ALTER TABLE dbo.ElectronicServiceWalletMovements WITH CHECK
ADD CONSTRAINT CK_ElectronicServiceWalletMovements_Type CHECK
    (MovementType IN(N'TopUp',N'Sale'));

ALTER TABLE dbo.ElectronicServiceWalletMovements WITH CHECK
ADD CONSTRAINT CK_ElectronicServiceWalletMovements_Balances CHECK
(
    OperationalBalanceBefore>=0 AND OperationalBalanceAfter>=0
    AND BookBalanceBefore>=0 AND BookBalanceAfter>=0
    AND OperationalBalanceAfter=OperationalBalanceBefore+OperationalDelta
    AND BookBalanceAfter=BookBalanceBefore+BookDelta
    AND
    (
        (MovementType=N'TopUp' AND OperationalDelta>0 AND BookDelta>0)
        OR
        (MovementType=N'Sale' AND OperationalDelta<0 AND BookDelta<=0)
    )
);

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE object_id=OBJECT_ID(N'dbo.ElectronicServiceWalletMovements')
      AND name=N'UX_ElectronicServiceWalletMovements_SubmissionWallet'
)
    CREATE UNIQUE INDEX UX_ElectronicServiceWalletMovements_SubmissionWallet
        ON dbo.ElectronicServiceWalletMovements(SubmissionKey,WalletId);

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE object_id=OBJECT_ID(N'dbo.ElectronicServiceWalletMovements')
      AND name=N'UX_ElectronicServiceWalletMovements_ReferenceWallet'
)
    CREATE UNIQUE INDEX UX_ElectronicServiceWalletMovements_ReferenceWallet
        ON dbo.ElectronicServiceWalletMovements(ReferenceType,ReferenceId,WalletId);

------------------------------------------------------------
-- Sale permission: structural definition, ADMIN grant only
------------------------------------------------------------

IF NOT EXISTS
(
    SELECT 1 FROM dbo.Permissions
    WHERE PermissionCode=N'ElectronicServices.Sell'
)
BEGIN
    INSERT INTO dbo.Permissions(PermissionCode,PermissionName,ModuleName)
    VALUES(N'ElectronicServices.Sell',N'Sell electronic services',N'ElectronicServices');
END;

INSERT INTO dbo.RolePermissions(RoleId,PermissionId)
SELECT r.Id,p.Id
FROM dbo.Roles r
CROSS JOIN dbo.Permissions p
WHERE r.RoleCode=N'ADMIN'
  AND p.PermissionCode=N'ElectronicServices.Sell'
  AND NOT EXISTS
  (
      SELECT 1 FROM dbo.RolePermissions existing
      WHERE existing.RoleId=r.Id AND existing.PermissionId=p.Id
  );

GO

CREATE OR ALTER TRIGGER dbo.TR_ElectronicServiceSaleSnapshots_AppendOnly
ON dbo.ElectronicServiceSaleSnapshots
AFTER UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    THROW 72420, 'Electronic service sale snapshots are immutable.', 1;
END;
GO

CREATE OR ALTER TRIGGER dbo.TR_SalesInvoiceDetails_ElectronicContract
ON dbo.SalesInvoiceDetails
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS
    (
        SELECT 1
        FROM inserted d
        INNER JOIN dbo.Items i ON i.Id=d.ItemId
        INNER JOIN dbo.SalesInvoices s ON s.Id=d.SalesInvoiceId
        WHERE d.LineKind<>i.ItemKind
           OR (d.LineKind=N'ElectronicService' AND s.PaymentType<>N'Cash')
    )
        THROW 72421, 'Sales line kind or electronic-service cash contract is invalid.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM inserted currentRow
        INNER JOIN deleted oldRow ON oldRow.Id=currentRow.Id
        WHERE oldRow.LineKind=N'ElectronicService'
          AND
          (
              currentRow.SalesInvoiceId<>oldRow.SalesInvoiceId
              OR currentRow.ItemId<>oldRow.ItemId
              OR ISNULL(currentRow.WarehouseId,-1)<>ISNULL(oldRow.WarehouseId,-1)
              OR currentRow.Qty<>oldRow.Qty
              OR currentRow.SellPrice<>oldRow.SellPrice
              OR currentRow.CostAtSale<>oldRow.CostAtSale
              OR currentRow.ProfitAtSale<>oldRow.ProfitAtSale
              OR currentRow.SubTotal<>oldRow.SubTotal
              OR currentRow.LineKind<>oldRow.LineKind
              OR currentRow.IsVoided<>oldRow.IsVoided
          )
    )
        THROW 72422, 'Completed electronic-service sale lines are financially immutable.', 1;
END;
GO

CREATE OR ALTER TRIGGER dbo.TR_SalesInvoiceDetails_BlockElectronicDelete
ON dbo.SalesInvoiceDetails
AFTER DELETE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS(SELECT 1 FROM deleted WHERE LineKind=N'ElectronicService')
        THROW 72423, 'Completed electronic-service sale lines cannot be deleted.', 1;
END;
GO

CREATE OR ALTER TRIGGER dbo.TR_SalesInvoices_ElectronicCashOnly
ON dbo.SalesInvoices
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS
    (
        SELECT 1
        FROM inserted s
        WHERE
        (
            s.PaymentType<>N'Cash' OR s.IsCancelled=1
        )
        AND EXISTS
        (
            SELECT 1 FROM dbo.SalesInvoiceDetails d
            WHERE d.SalesInvoiceId=s.Id
              AND d.LineKind=N'ElectronicService'
              AND ISNULL(d.IsVoided,0)=0
        )
    )
        THROW 72424, 'Invoices containing completed electronic services must remain cash and cannot be cancelled automatically.', 1;
END;
GO
