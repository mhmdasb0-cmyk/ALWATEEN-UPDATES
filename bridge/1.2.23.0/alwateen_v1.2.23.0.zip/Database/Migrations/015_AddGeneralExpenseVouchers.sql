/*
    015_AddGeneralExpenseVouchers.sql

    Adds general expense vouchers for business expenses and owner withdrawals.
    Includes permissions for Expense Vouchers screen.
*/

IF OBJECT_ID(N'dbo.GeneralExpenseVouchers', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.GeneralExpenseVouchers
    (
        Id INT IDENTITY(1,1) NOT NULL,
        VoucherDate DATETIME2(7) NOT NULL,
        ExpenseKind NVARCHAR(30) NOT NULL,
        DebitAccountId INT NOT NULL,
        CashAccountId INT NOT NULL,
        Amount DECIMAL(18,4) NOT NULL,
        Notes NVARCHAR(500) NULL,
        IsCancelled BIT NOT NULL
            CONSTRAINT DF_GeneralExpenseVouchers_IsCancelled DEFAULT (0),
        CancelledAt DATETIME2(7) NULL,
        CancelReason NVARCHAR(500) NULL,
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_GeneralExpenseVouchers_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,

        CONSTRAINT PK_GeneralExpenseVouchers
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT CK_GeneralExpenseVouchers_ExpenseKind
            CHECK (ExpenseKind IN (N'BusinessExpense', N'OwnerWithdrawal')),

        CONSTRAINT CK_GeneralExpenseVouchers_Amount
            CHECK (Amount > 0),

        CONSTRAINT CK_GeneralExpenseVouchers_DifferentAccounts
            CHECK (DebitAccountId <> CashAccountId)
    );
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'IX_GeneralExpenseVouchers_VoucherDate'
      AND object_id = OBJECT_ID(N'dbo.GeneralExpenseVouchers')
)
BEGIN
    CREATE INDEX IX_GeneralExpenseVouchers_VoucherDate
        ON dbo.GeneralExpenseVouchers (VoucherDate);
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'IX_GeneralExpenseVouchers_DebitAccountId'
      AND object_id = OBJECT_ID(N'dbo.GeneralExpenseVouchers')
)
BEGIN
    CREATE INDEX IX_GeneralExpenseVouchers_DebitAccountId
        ON dbo.GeneralExpenseVouchers (DebitAccountId);
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'IX_GeneralExpenseVouchers_CashAccountId'
      AND object_id = OBJECT_ID(N'dbo.GeneralExpenseVouchers')
)
BEGIN
    CREATE INDEX IX_GeneralExpenseVouchers_CashAccountId
        ON dbo.GeneralExpenseVouchers (CashAccountId);
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE name = N'FK_GeneralExpenseVouchers_DebitAccount'
)
BEGIN
    ALTER TABLE dbo.GeneralExpenseVouchers
        ADD CONSTRAINT FK_GeneralExpenseVouchers_DebitAccount
            FOREIGN KEY (DebitAccountId)
            REFERENCES dbo.Accounts (Id);
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE name = N'FK_GeneralExpenseVouchers_CashAccount'
)
BEGIN
    ALTER TABLE dbo.GeneralExpenseVouchers
        ADD CONSTRAINT FK_GeneralExpenseVouchers_CashAccount
            FOREIGN KEY (CashAccountId)
            REFERENCES dbo.Accounts (Id);
END;
GO

DECLARE @PermissionSeed TABLE
(
    PermissionCode NVARCHAR(150) NOT NULL,
    PermissionName NVARCHAR(200) NOT NULL,
    ModuleName NVARCHAR(100) NOT NULL,
    Description NVARCHAR(500) NULL
);

INSERT INTO @PermissionSeed
(
    PermissionCode,
    PermissionName,
    ModuleName,
    Description
)
VALUES
    (N'ExpenseVouchers.View', N'View Expense Vouchers', N'Accounting', N'View expense vouchers'),
    (N'ExpenseVouchers.Create', N'Create Expense Vouchers', N'Accounting', N'Create expense vouchers'),
    (N'ExpenseVouchers.Cancel', N'Cancel Expense Vouchers', N'Accounting', N'Cancel expense vouchers');

INSERT INTO dbo.Permissions
(
    PermissionCode,
    PermissionName,
    ModuleName,
    Description,
    IsActive
)
SELECT
    s.PermissionCode,
    s.PermissionName,
    s.ModuleName,
    s.Description,
    1
FROM @PermissionSeed s
WHERE NOT EXISTS
(
    SELECT 1
    FROM dbo.Permissions p
    WHERE p.PermissionCode = s.PermissionCode
);
GO

INSERT INTO dbo.RolePermissions
(
    RoleId,
    PermissionId
)
SELECT
    r.Id,
    p.Id
FROM dbo.Roles r
CROSS JOIN dbo.Permissions p
WHERE r.RoleCode = N'ADMIN'
  AND p.PermissionCode IN
  (
      N'ExpenseVouchers.View',
      N'ExpenseVouchers.Create',
      N'ExpenseVouchers.Cancel'
  )
  AND NOT EXISTS
  (
      SELECT 1
      FROM dbo.RolePermissions rp
      WHERE rp.RoleId = r.Id
        AND rp.PermissionId = p.Id
  );
GO
