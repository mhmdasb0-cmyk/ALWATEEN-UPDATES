﻿/* =========================================================
   002_EnforceBusinessRequiredColumns.sql

   Purpose:
   - Enforce Items.ItemCode as NOT NULL
   - Enforce StockMovements.ReferenceType as NOT NULL
   - Enforce StockMovements.ReferenceId as NOT NULL

   Handles:
   - DB-005 Items.ItemCode nullable
   - DB-006 StockMovements.ReferenceType / ReferenceId nullable

   Rules:
   - Idempotent
   - No data deletion
   - Stop if unsafe data exists
   - Safely rebuild dependent constraints/indexes
   ========================================================= */

SET NOCOUNT ON;

------------------------------------------------------------
-- 01 - Validate required tables
------------------------------------------------------------

IF OBJECT_ID(N'dbo.Items', N'U') IS NULL
BEGIN
    THROW 70201, 'Table dbo.Items does not exist.', 1;
END;

IF OBJECT_ID(N'dbo.StockMovements', N'U') IS NULL
BEGIN
    THROW 70202, 'Table dbo.StockMovements does not exist.', 1;
END;

------------------------------------------------------------
-- 02 - Validate required columns
------------------------------------------------------------

IF COL_LENGTH(N'dbo.Items', N'ItemCode') IS NULL
BEGIN
    THROW 70203, 'Column dbo.Items.ItemCode does not exist.', 1;
END;

IF COL_LENGTH(N'dbo.StockMovements', N'ReferenceType') IS NULL
BEGIN
    THROW 70204, 'Column dbo.StockMovements.ReferenceType does not exist.', 1;
END;

IF COL_LENGTH(N'dbo.StockMovements', N'ReferenceId') IS NULL
BEGIN
    THROW 70205, 'Column dbo.StockMovements.ReferenceId does not exist.', 1;
END;

------------------------------------------------------------
-- 03 - Stop if invalid Items.ItemCode data exists
------------------------------------------------------------

IF EXISTS
(
    SELECT 1
    FROM dbo.Items
    WHERE ItemCode IS NULL
       OR LTRIM(RTRIM(ItemCode)) = N''
)
BEGIN
    SELECT
        Id,
        ItemCode,
        ItemName
    FROM dbo.Items
    WHERE ItemCode IS NULL
       OR LTRIM(RTRIM(ItemCode)) = N'';

    THROW 70206, 'Cannot enforce Items.ItemCode NOT NULL because empty ItemCode rows exist.', 1;
END;

------------------------------------------------------------
-- 04 - Stop if duplicate ItemCode exists
------------------------------------------------------------

IF EXISTS
(
    SELECT 1
    FROM dbo.Items
    WHERE ItemCode IS NOT NULL
      AND LTRIM(RTRIM(ItemCode)) <> N''
    GROUP BY ItemCode
    HAVING COUNT(*) > 1
)
BEGIN
    SELECT
        ItemCode,
        COUNT(*) AS RowsCount
    FROM dbo.Items
    WHERE ItemCode IS NOT NULL
      AND LTRIM(RTRIM(ItemCode)) <> N''
    GROUP BY ItemCode
    HAVING COUNT(*) > 1;

    THROW 70207, 'Cannot enforce Items.ItemCode because duplicate ItemCode rows exist.', 1;
END;

------------------------------------------------------------
-- 05 - Stop if invalid StockMovements reference data exists
------------------------------------------------------------

IF EXISTS
(
    SELECT 1
    FROM dbo.StockMovements
    WHERE ReferenceType IS NULL
       OR LTRIM(RTRIM(ReferenceType)) = N''
       OR ReferenceId IS NULL
       OR ReferenceId <= 0
)
BEGIN
    SELECT
        Id,
        ItemId,
        WarehouseId,
        MovementType,
        Qty,
        UnitCost,
        ReferenceType,
        ReferenceId,
        MovementDate,
        Notes
    FROM dbo.StockMovements
    WHERE ReferenceType IS NULL
       OR LTRIM(RTRIM(ReferenceType)) = N''
       OR ReferenceId IS NULL
       OR ReferenceId <= 0;

    THROW 70208, 'Cannot enforce StockMovements reference columns because invalid reference rows exist.', 1;
END;

------------------------------------------------------------
-- 06 - Stop if unknown StockMovements.ReferenceType exists
------------------------------------------------------------

IF EXISTS
(
    SELECT 1
    FROM dbo.StockMovements
    WHERE ReferenceType NOT IN
    (
        'Purchase',
        'PurchaseEdit',
        'PurchaseCancel',
        'Sale',
        'SaleEdit',
        'SaleCancel',
        'OpeningBalance',
        'ManualAdjustment'
    )
)
BEGIN
    SELECT
        Id,
        ReferenceType,
        ReferenceId
    FROM dbo.StockMovements
    WHERE ReferenceType NOT IN
    (
        'Purchase',
        'PurchaseEdit',
        'PurchaseCancel',
        'Sale',
        'SaleEdit',
        'SaleCancel',
        'OpeningBalance',
        'ManualAdjustment'
    );

    THROW 70209, 'Cannot enforce StockMovements.ReferenceType because unknown values exist.', 1;
END;

------------------------------------------------------------
-- 07 - Drop UQ_Items_ItemCode temporarily if it exists
------------------------------------------------------------

IF EXISTS
(
    SELECT 1
    FROM sys.key_constraints
    WHERE name = N'UQ_Items_ItemCode'
      AND parent_object_id = OBJECT_ID(N'dbo.Items')
)
BEGIN
    ALTER TABLE dbo.Items
    DROP CONSTRAINT UQ_Items_ItemCode;
END;
ELSE IF EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'UQ_Items_ItemCode'
      AND object_id = OBJECT_ID(N'dbo.Items')
)
BEGIN
    DROP INDEX UQ_Items_ItemCode
    ON dbo.Items;
END;

------------------------------------------------------------
-- 08 - Drop StockMovements reference index temporarily
------------------------------------------------------------

IF EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'IX_StockMovements_Reference'
      AND object_id = OBJECT_ID(N'dbo.StockMovements')
)
BEGIN
    DROP INDEX IX_StockMovements_Reference
    ON dbo.StockMovements;
END;

------------------------------------------------------------
-- 09 - Enforce Items.ItemCode NOT NULL
------------------------------------------------------------

IF EXISTS
(
    SELECT 1
    FROM sys.columns
    WHERE object_id = OBJECT_ID(N'dbo.Items')
      AND name = N'ItemCode'
      AND is_nullable = 1
)
BEGIN
    ALTER TABLE dbo.Items
    ALTER COLUMN ItemCode NVARCHAR(50) NOT NULL;
END;

------------------------------------------------------------
-- 10 - Recreate UQ_Items_ItemCode if missing
------------------------------------------------------------

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'UQ_Items_ItemCode'
      AND object_id = OBJECT_ID(N'dbo.Items')
)
BEGIN
    ALTER TABLE dbo.Items
    ADD CONSTRAINT UQ_Items_ItemCode
        UNIQUE (ItemCode);
END;

------------------------------------------------------------
-- 11 - Enforce StockMovements.ReferenceType NOT NULL
------------------------------------------------------------

IF EXISTS
(
    SELECT 1
    FROM sys.columns
    WHERE object_id = OBJECT_ID(N'dbo.StockMovements')
      AND name = N'ReferenceType'
      AND is_nullable = 1
)
BEGIN
    ALTER TABLE dbo.StockMovements
    ALTER COLUMN ReferenceType NVARCHAR(50) NOT NULL;
END;

------------------------------------------------------------
-- 12 - Enforce StockMovements.ReferenceId NOT NULL
------------------------------------------------------------

IF EXISTS
(
    SELECT 1
    FROM sys.columns
    WHERE object_id = OBJECT_ID(N'dbo.StockMovements')
      AND name = N'ReferenceId'
      AND is_nullable = 1
)
BEGIN
    ALTER TABLE dbo.StockMovements
    ALTER COLUMN ReferenceId INT NOT NULL;
END;

------------------------------------------------------------
-- 13 - Recreate StockMovements reference index if missing
------------------------------------------------------------

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'IX_StockMovements_Reference'
      AND object_id = OBJECT_ID(N'dbo.StockMovements')
)
BEGIN
    CREATE INDEX IX_StockMovements_Reference
        ON dbo.StockMovements (ReferenceType, ReferenceId);
END;

------------------------------------------------------------
-- 14 - Add ReferenceType CHECK constraint if missing
------------------------------------------------------------

IF NOT EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE name = N'CK_StockMovements_ReferenceType'
      AND parent_object_id = OBJECT_ID(N'dbo.StockMovements')
)
BEGIN
    ALTER TABLE dbo.StockMovements WITH CHECK
    ADD CONSTRAINT CK_StockMovements_ReferenceType
    CHECK
    (
        ReferenceType IN
        (
            'Purchase',
            'PurchaseEdit',
            'PurchaseCancel',
            'Sale',
            'SaleEdit',
            'SaleCancel',
            'OpeningBalance',
            'ManualAdjustment'
        )
    );

    ALTER TABLE dbo.StockMovements
    CHECK CONSTRAINT CK_StockMovements_ReferenceType;
END;