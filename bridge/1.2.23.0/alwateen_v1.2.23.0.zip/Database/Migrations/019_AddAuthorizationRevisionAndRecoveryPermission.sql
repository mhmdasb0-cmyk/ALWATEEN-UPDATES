/*
    019_AddAuthorizationRevisionAndRecoveryPermission.sql

    - Adds a database-backed global authorization revision.
    - Revision triggers execute in the same transaction as every security change.
    - Adds the independent System.Backup.Restore permission to ADMIN only.
*/

IF OBJECT_ID(N'dbo.SecurityAuthorizationState', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.SecurityAuthorizationState
    (
        Id TINYINT NOT NULL,
        Revision BIGINT NOT NULL,
        UpdatedAt DATETIME2 NOT NULL
            CONSTRAINT DF_SecurityAuthorizationState_UpdatedAt
            DEFAULT (SYSUTCDATETIME()),

        CONSTRAINT PK_SecurityAuthorizationState
            PRIMARY KEY (Id),

        CONSTRAINT CK_SecurityAuthorizationState_SingleRow
            CHECK (Id = 1),

        CONSTRAINT CK_SecurityAuthorizationState_Revision
            CHECK (Revision > 0)
    );
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.SecurityAuthorizationState
    WHERE Id = 1
)
BEGIN
    INSERT INTO dbo.SecurityAuthorizationState
    (
        Id,
        Revision,
        UpdatedAt
    )
    VALUES
    (
        1,
        1,
        SYSUTCDATETIME()
    );
END;
GO

CREATE OR ALTER TRIGGER dbo.TR_Users_AuthorizationRevision
ON dbo.Users
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF UPDATE(IsActive)
       AND EXISTS
       (
           SELECT 1
           FROM inserted i
           INNER JOIN deleted d
               ON d.Id = i.Id
           WHERE i.IsActive <> d.IsActive
       )
    BEGIN
        UPDATE dbo.SecurityAuthorizationState
        SET Revision = Revision + 1,
            UpdatedAt = SYSUTCDATETIME()
        WHERE Id = 1;
    END;
END;
GO

CREATE OR ALTER TRIGGER dbo.TR_Roles_AuthorizationRevision
ON dbo.Roles
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF UPDATE(IsActive)
       AND EXISTS
       (
           SELECT 1
           FROM inserted i
           INNER JOIN deleted d
               ON d.Id = i.Id
           WHERE i.IsActive <> d.IsActive
       )
    BEGIN
        UPDATE dbo.SecurityAuthorizationState
        SET Revision = Revision + 1,
            UpdatedAt = SYSUTCDATETIME()
        WHERE Id = 1;
    END;
END;
GO

CREATE OR ALTER TRIGGER dbo.TR_Permissions_AuthorizationRevision
ON dbo.Permissions
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF UPDATE(IsActive)
       AND EXISTS
       (
           SELECT 1
           FROM inserted i
           INNER JOIN deleted d
               ON d.Id = i.Id
           WHERE i.IsActive <> d.IsActive
       )
    BEGIN
        UPDATE dbo.SecurityAuthorizationState
        SET Revision = Revision + 1,
            UpdatedAt = SYSUTCDATETIME()
        WHERE Id = 1;
    END;
END;
GO

CREATE OR ALTER TRIGGER dbo.TR_UserRoles_AuthorizationRevision
ON dbo.UserRoles
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM inserted)
       OR EXISTS (SELECT 1 FROM deleted)
    BEGIN
        UPDATE dbo.SecurityAuthorizationState
        SET Revision = Revision + 1,
            UpdatedAt = SYSUTCDATETIME()
        WHERE Id = 1;
    END;
END;
GO

CREATE OR ALTER TRIGGER dbo.TR_RolePermissions_AuthorizationRevision
ON dbo.RolePermissions
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM inserted)
       OR EXISTS (SELECT 1 FROM deleted)
    BEGIN
        UPDATE dbo.SecurityAuthorizationState
        SET Revision = Revision + 1,
            UpdatedAt = SYSUTCDATETIME()
        WHERE Id = 1;
    END;
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM dbo.Permissions
    WHERE PermissionCode = N'System.Backup.Restore'
)
BEGIN
    INSERT INTO dbo.Permissions
    (
        PermissionCode,
        PermissionName,
        ModuleName,
        Description,
        IsActive
    )
    VALUES
    (
        N'System.Backup.Restore',
        N'Restore Database Backups',
        N'System',
        N'Run the external staged database recovery workflow',
        1
    );
END;
GO

INSERT INTO dbo.RolePermissions
(
    RoleId,
    PermissionId
)
SELECT
    r.Id,
    p.Id
FROM dbo.Roles r
INNER JOIN dbo.Permissions p
    ON p.PermissionCode = N'System.Backup.Restore'
WHERE r.RoleCode = N'ADMIN'
  AND NOT EXISTS
  (
      SELECT 1
      FROM dbo.RolePermissions rp
      WHERE rp.RoleId = r.Id
        AND rp.PermissionId = p.Id
  );
GO
