﻿/* =========================================================
   003_NormalizeCostPrecision.sql

   Purpose:
   - Normalize cost precision to decimal(18,4)
   - Fix controlled sale detail vs stock movement cost mismatch

   Handles:
   - DB-003 Cost precision scale too low
   - DB-008 Sale COGS / Stock cost rounding mismatch

   Target columns:
   - ItemWarehouseCosts.AverageCost
   - ItemWarehouseCosts.LastPurchaseCost
   - SalesInvoiceDetails.CostAtSale
   - StockMovements.UnitCost

   Rules:
   - Idempotent
   - No data deletion
   - Drops and recreates dependent CHECK / DEFAULT constraints safely
   ========================================================= */

SET NOCOUNT ON;

------------------------------------------------------------
-- 01 - Validate required tables
------------------------------------------------------------

IF OBJECT_ID(N'dbo.ItemWarehouseCosts', N'U') IS NULL
BEGIN
    THROW 70301, 'Table dbo.ItemWarehouseCosts does not exist.', 1;
END;

IF OBJECT_ID(N'dbo.SalesInvoiceDetails', N'U') IS NULL
BEGIN
    THROW 70302, 'Table dbo.SalesInvoiceDetails does not exist.', 1;
END;

IF OBJECT_ID(N'dbo.StockMovements', N'U') IS NULL
BEGIN
    THROW 70303, 'Table dbo.StockMovements does not exist.', 1;
END;

IF OBJECT_ID(N'dbo.SalesInvoices', N'U') IS NULL
BEGIN
    THROW 70304, 'Table dbo.SalesInvoices does not exist.', 1;
END;

------------------------------------------------------------
-- 02 - Validate required columns
------------------------------------------------------------

IF COL_LENGTH(N'dbo.ItemWarehouseCosts', N'AverageCost') IS NULL
BEGIN
    THROW 70305, 'Column dbo.ItemWarehouseCosts.AverageCost does not exist.', 1;
END;

IF COL_LENGTH(N'dbo.ItemWarehouseCosts', N'LastPurchaseCost') IS NULL
BEGIN
    THROW 70306, 'Column dbo.ItemWarehouseCosts.LastPurchaseCost does not exist.', 1;
END;

IF COL_LENGTH(N'dbo.SalesInvoiceDetails', N'CostAtSale') IS NULL
BEGIN
    THROW 70307, 'Column dbo.SalesInvoiceDetails.CostAtSale does not exist.', 1;
END;

IF COL_LENGTH(N'dbo.StockMovements', N'UnitCost') IS NULL
BEGIN
    THROW 70308, 'Column dbo.StockMovements.UnitCost does not exist.', 1;
END;

------------------------------------------------------------
-- 03 - Stop if invalid negative cost data exists
------------------------------------------------------------

IF EXISTS
(
    SELECT 1
    FROM dbo.ItemWarehouseCosts
    WHERE AverageCost < 0
       OR LastPurchaseCost < 0
)
BEGIN
    THROW 70309, 'Cannot normalize ItemWarehouseCosts precision because negative costs exist.', 1;
END;

IF EXISTS
(
    SELECT 1
    FROM dbo.SalesInvoiceDetails
    WHERE CostAtSale < 0
)
BEGIN
    THROW 70310, 'Cannot normalize SalesInvoiceDetails precision because negative CostAtSale values exist.', 1;
END;

IF EXISTS
(
    SELECT 1
    FROM dbo.StockMovements
    WHERE UnitCost < 0
)
BEGIN
    THROW 70311, 'Cannot normalize StockMovements precision because negative UnitCost values exist.', 1;
END;

------------------------------------------------------------
-- 04 - Drop dependent CHECK constraints
------------------------------------------------------------

IF EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE name = N'CK_ItemWarehouseCosts_AverageCost'
      AND parent_object_id = OBJECT_ID(N'dbo.ItemWarehouseCosts')
)
BEGIN
    ALTER TABLE dbo.ItemWarehouseCosts
    DROP CONSTRAINT CK_ItemWarehouseCosts_AverageCost;
END;

IF EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE name = N'CK_ItemWarehouseCosts_LastPurchaseCost'
      AND parent_object_id = OBJECT_ID(N'dbo.ItemWarehouseCosts')
)
BEGIN
    ALTER TABLE dbo.ItemWarehouseCosts
    DROP CONSTRAINT CK_ItemWarehouseCosts_LastPurchaseCost;
END;

IF EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE name = N'CK_SalesInvoiceDetails_CostAtSale'
      AND parent_object_id = OBJECT_ID(N'dbo.SalesInvoiceDetails')
)
BEGIN
    ALTER TABLE dbo.SalesInvoiceDetails
    DROP CONSTRAINT CK_SalesInvoiceDetails_CostAtSale;
END;

IF EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE name = N'CK_StockMovements_UnitCost'
      AND parent_object_id = OBJECT_ID(N'dbo.StockMovements')
)
BEGIN
    ALTER TABLE dbo.StockMovements
    DROP CONSTRAINT CK_StockMovements_UnitCost;
END;

------------------------------------------------------------
-- 05 - Drop dependent DEFAULT constraints
------------------------------------------------------------

IF EXISTS
(
    SELECT 1
    FROM sys.default_constraints
    WHERE name = N'DF_ItemWarehouseCosts_AverageCost'
      AND parent_object_id = OBJECT_ID(N'dbo.ItemWarehouseCosts')
)
BEGIN
    ALTER TABLE dbo.ItemWarehouseCosts
    DROP CONSTRAINT DF_ItemWarehouseCosts_AverageCost;
END;

IF EXISTS
(
    SELECT 1
    FROM sys.default_constraints
    WHERE name = N'DF_ItemWarehouseCosts_LastPurchaseCost'
      AND parent_object_id = OBJECT_ID(N'dbo.ItemWarehouseCosts')
)
BEGIN
    ALTER TABLE dbo.ItemWarehouseCosts
    DROP CONSTRAINT DF_ItemWarehouseCosts_LastPurchaseCost;
END;

------------------------------------------------------------
-- 06 - Alter target columns to decimal(18,4)
------------------------------------------------------------

IF EXISTS
(
    SELECT 1
    FROM sys.columns
    WHERE object_id = OBJECT_ID(N'dbo.ItemWarehouseCosts')
      AND name = N'AverageCost'
      AND scale < 4
)
BEGIN
    ALTER TABLE dbo.ItemWarehouseCosts
    ALTER COLUMN AverageCost DECIMAL(18,4) NOT NULL;
END;

IF EXISTS
(
    SELECT 1
    FROM sys.columns
    WHERE object_id = OBJECT_ID(N'dbo.ItemWarehouseCosts')
      AND name = N'LastPurchaseCost'
      AND scale < 4
)
BEGIN
    ALTER TABLE dbo.ItemWarehouseCosts
    ALTER COLUMN LastPurchaseCost DECIMAL(18,4) NOT NULL;
END;

IF EXISTS
(
    SELECT 1
    FROM sys.columns
    WHERE object_id = OBJECT_ID(N'dbo.SalesInvoiceDetails')
      AND name = N'CostAtSale'
      AND scale < 4
)
BEGIN
    ALTER TABLE dbo.SalesInvoiceDetails
    ALTER COLUMN CostAtSale DECIMAL(18,4) NOT NULL;
END;

IF EXISTS
(
    SELECT 1
    FROM sys.columns
    WHERE object_id = OBJECT_ID(N'dbo.StockMovements')
      AND name = N'UnitCost'
      AND scale < 4
)
BEGIN
    ALTER TABLE dbo.StockMovements
    ALTER COLUMN UnitCost DECIMAL(18,4) NOT NULL;
END;

------------------------------------------------------------
-- 07 - Recreate DEFAULT constraints
------------------------------------------------------------

IF NOT EXISTS
(
    SELECT 1
    FROM sys.default_constraints
    WHERE name = N'DF_ItemWarehouseCosts_AverageCost'
      AND parent_object_id = OBJECT_ID(N'dbo.ItemWarehouseCosts')
)
BEGIN
    ALTER TABLE dbo.ItemWarehouseCosts
    ADD CONSTRAINT DF_ItemWarehouseCosts_AverageCost
        DEFAULT (0) FOR AverageCost;
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.default_constraints
    WHERE name = N'DF_ItemWarehouseCosts_LastPurchaseCost'
      AND parent_object_id = OBJECT_ID(N'dbo.ItemWarehouseCosts')
)
BEGIN
    ALTER TABLE dbo.ItemWarehouseCosts
    ADD CONSTRAINT DF_ItemWarehouseCosts_LastPurchaseCost
        DEFAULT (0) FOR LastPurchaseCost;
END;

------------------------------------------------------------
-- 08 - Recreate CHECK constraints
------------------------------------------------------------

IF NOT EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE name = N'CK_ItemWarehouseCosts_AverageCost'
      AND parent_object_id = OBJECT_ID(N'dbo.ItemWarehouseCosts')
)
BEGIN
    ALTER TABLE dbo.ItemWarehouseCosts WITH CHECK
    ADD CONSTRAINT CK_ItemWarehouseCosts_AverageCost
    CHECK (AverageCost >= 0);

    ALTER TABLE dbo.ItemWarehouseCosts
    CHECK CONSTRAINT CK_ItemWarehouseCosts_AverageCost;
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE name = N'CK_ItemWarehouseCosts_LastPurchaseCost'
      AND parent_object_id = OBJECT_ID(N'dbo.ItemWarehouseCosts')
)
BEGIN
    ALTER TABLE dbo.ItemWarehouseCosts WITH CHECK
    ADD CONSTRAINT CK_ItemWarehouseCosts_LastPurchaseCost
    CHECK (LastPurchaseCost >= 0);

    ALTER TABLE dbo.ItemWarehouseCosts
    CHECK CONSTRAINT CK_ItemWarehouseCosts_LastPurchaseCost;
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE name = N'CK_SalesInvoiceDetails_CostAtSale'
      AND parent_object_id = OBJECT_ID(N'dbo.SalesInvoiceDetails')
)
BEGIN
    ALTER TABLE dbo.SalesInvoiceDetails WITH CHECK
    ADD CONSTRAINT CK_SalesInvoiceDetails_CostAtSale
    CHECK (CostAtSale >= 0);

    ALTER TABLE dbo.SalesInvoiceDetails
    CHECK CONSTRAINT CK_SalesInvoiceDetails_CostAtSale;
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE name = N'CK_StockMovements_UnitCost'
      AND parent_object_id = OBJECT_ID(N'dbo.StockMovements')
)
BEGIN
    ALTER TABLE dbo.StockMovements WITH CHECK
    ADD CONSTRAINT CK_StockMovements_UnitCost
    CHECK (UnitCost >= 0);

    ALTER TABLE dbo.StockMovements
    CHECK CONSTRAINT CK_StockMovements_UnitCost;
END;

------------------------------------------------------------
-- 09 - Controlled data alignment:
--      Sales detail CostAtSale must match related sale OUT movement UnitCost
--      Only for unambiguous active sale rows
------------------------------------------------------------

;WITH CandidateMatches AS
(
    SELECT
        sm.Id AS StockMovementId,
        d.Id AS SalesDetailId,
        d.SalesInvoiceId,
        d.CostAtSale,
        sm.UnitCost,
        COUNT(*) OVER (PARTITION BY sm.Id) AS MatchCount
    FROM dbo.StockMovements sm
    INNER JOIN dbo.SalesInvoiceDetails d
        ON d.SalesInvoiceId = sm.ReferenceId
       AND d.ItemId = sm.ItemId
       AND d.WarehouseId = sm.WarehouseId
       AND d.Qty = sm.Qty
    INNER JOIN dbo.SalesInvoices s
        ON s.Id = d.SalesInvoiceId
    WHERE
        s.IsCancelled = 0
        AND sm.MovementType = 'OUT'
        AND sm.ReferenceType IN ('Sale', 'SaleEdit')
        AND ABS(d.CostAtSale - sm.UnitCost) > 0.0001
)
UPDATE sm
SET UnitCost = cm.CostAtSale
FROM dbo.StockMovements sm
INNER JOIN CandidateMatches cm
    ON cm.StockMovementId = sm.Id
WHERE
    cm.MatchCount = 1;

------------------------------------------------------------
-- 10 - Stop if ambiguous mismatches still exist
------------------------------------------------------------

IF EXISTS
(
    SELECT 1
    FROM
    (
        SELECT
            sm.Id AS StockMovementId,
            COUNT(*) AS MatchCount
        FROM dbo.StockMovements sm
        INNER JOIN dbo.SalesInvoiceDetails d
            ON d.SalesInvoiceId = sm.ReferenceId
           AND d.ItemId = sm.ItemId
           AND d.WarehouseId = sm.WarehouseId
           AND d.Qty = sm.Qty
        INNER JOIN dbo.SalesInvoices s
            ON s.Id = d.SalesInvoiceId
        WHERE
            s.IsCancelled = 0
            AND sm.MovementType = 'OUT'
            AND sm.ReferenceType IN ('Sale', 'SaleEdit')
            AND ABS(d.CostAtSale - sm.UnitCost) > 0.0001
        GROUP BY
            sm.Id
    ) x
    WHERE x.MatchCount <> 1
)
BEGIN
    THROW 70312, 'Ambiguous sale stock cost mismatches still exist after precision normalization.', 1;
END;