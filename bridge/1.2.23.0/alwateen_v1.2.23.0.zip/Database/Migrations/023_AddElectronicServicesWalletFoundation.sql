/*
023_AddElectronicServicesWalletFoundation.sql

Creates the manual, shared electronic-services wallet foundation. The migration
contains no wallet, category, provider, service, barcode, price, balance,
top-up, posting-account mapping, or sample business data.
*/

SET XACT_ABORT ON;

------------------------------------------------------------
-- Backward-compatible catalog discriminator
------------------------------------------------------------

IF COL_LENGTH(N'dbo.Items', N'ItemKind') IS NULL
BEGIN
    ALTER TABLE dbo.Items
        ADD ItemKind NVARCHAR(30) NOT NULL
            CONSTRAINT DF_Items_ItemKind DEFAULT (N'Inventory') WITH VALUES;
END;

GO

IF NOT EXISTS
(
    SELECT 1 FROM sys.check_constraints
    WHERE parent_object_id=OBJECT_ID(N'dbo.Items')
      AND name=N'CK_Items_ItemKind'
)
BEGIN
    ALTER TABLE dbo.Items WITH CHECK
        ADD CONSTRAINT CK_Items_ItemKind
        CHECK (ItemKind IN (N'Inventory', N'ElectronicService'));
END;

IF NOT EXISTS
(
    SELECT 1 FROM sys.check_constraints
    WHERE parent_object_id=OBJECT_ID(N'dbo.Items')
      AND name=N'CK_Items_ElectronicServiceInventoryIsolation'
)
BEGIN
    ALTER TABLE dbo.Items WITH CHECK
        ADD CONSTRAINT CK_Items_ElectronicServiceInventoryIsolation
        CHECK
        (
            ItemKind=N'Inventory'
            OR
            (
                DefaultWarehouseId IS NULL
                AND BuyPrice=0
            )
        );
END;

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE object_id=OBJECT_ID(N'dbo.Items')
      AND name=N'IX_Items_ItemKind_Active'
)
BEGIN
    CREATE INDEX IX_Items_ItemKind_Active
        ON dbo.Items(ItemKind, IsActive, IsArchived, Id);
END;

------------------------------------------------------------
-- Category / provider / shared wallet setup
------------------------------------------------------------

IF OBJECT_ID(N'dbo.ElectronicServiceCategories', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ElectronicServiceCategories
    (
        Id INT IDENTITY(1,1) NOT NULL,
        Code NVARCHAR(50) NOT NULL,
        NameAr NVARCHAR(150) NOT NULL CONSTRAINT DF_ElectronicServiceCategories_NameAr DEFAULT(N''),
        NameEn NVARCHAR(150) NOT NULL CONSTRAINT DF_ElectronicServiceCategories_NameEn DEFAULT(N''),
        IsActive BIT NOT NULL CONSTRAINT DF_ElectronicServiceCategories_IsActive DEFAULT(1),
        CreatedAt DATETIME2(7) NOT NULL CONSTRAINT DF_ElectronicServiceCategories_CreatedAt DEFAULT(SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,
        RowVersion ROWVERSION NOT NULL,
        CONSTRAINT PK_ElectronicServiceCategories PRIMARY KEY(Id),
        CONSTRAINT UQ_ElectronicServiceCategories_Code UNIQUE(Code),
        CONSTRAINT CK_ElectronicServiceCategories_Code CHECK(LEN(LTRIM(RTRIM(Code)))>0),
        CONSTRAINT CK_ElectronicServiceCategories_Name CHECK
        (
            LEN(LTRIM(RTRIM(NameAr)))>0 OR LEN(LTRIM(RTRIM(NameEn)))>0
        )
    );
END;

IF OBJECT_ID(N'dbo.ElectronicServiceProviders', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ElectronicServiceProviders
    (
        Id INT IDENTITY(1,1) NOT NULL,
        CategoryId INT NOT NULL,
        ProviderCode NVARCHAR(50) NOT NULL,
        NameAr NVARCHAR(150) NOT NULL CONSTRAINT DF_ElectronicServiceProviders_NameAr DEFAULT(N''),
        NameEn NVARCHAR(150) NOT NULL CONSTRAINT DF_ElectronicServiceProviders_NameEn DEFAULT(N''),
        IsActive BIT NOT NULL CONSTRAINT DF_ElectronicServiceProviders_IsActive DEFAULT(1),
        CreatedAt DATETIME2(7) NOT NULL CONSTRAINT DF_ElectronicServiceProviders_CreatedAt DEFAULT(SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,
        RowVersion ROWVERSION NOT NULL,
        CONSTRAINT PK_ElectronicServiceProviders PRIMARY KEY(Id),
        CONSTRAINT UQ_ElectronicServiceProviders_Code UNIQUE(ProviderCode),
        CONSTRAINT UQ_ElectronicServiceProviders_IdCategory UNIQUE(Id, CategoryId),
        CONSTRAINT FK_ElectronicServiceProviders_Category FOREIGN KEY(CategoryId)
            REFERENCES dbo.ElectronicServiceCategories(Id),
        CONSTRAINT CK_ElectronicServiceProviders_Code CHECK(LEN(LTRIM(RTRIM(ProviderCode)))>0),
        CONSTRAINT CK_ElectronicServiceProviders_Name CHECK
        (
            LEN(LTRIM(RTRIM(NameAr)))>0 OR LEN(LTRIM(RTRIM(NameEn)))>0
        )
    );

    CREATE INDEX IX_ElectronicServiceProviders_CategoryActive
        ON dbo.ElectronicServiceProviders(CategoryId, IsActive, Id);
END;

IF OBJECT_ID(N'dbo.ElectronicServiceWallets', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ElectronicServiceWallets
    (
        Id INT IDENTITY(1,1) NOT NULL,
        WalletName NVARCHAR(150) NOT NULL,
        AccountingPolicy NVARCHAR(40) NOT NULL,
        AssetAccountId INT NOT NULL,
        AvailableOperationalBalance DECIMAL(19,4) NOT NULL
            CONSTRAINT DF_ElectronicServiceWallets_OperationalBalance DEFAULT(0),
        BookBalance DECIMAL(19,4) NOT NULL
            CONSTRAINT DF_ElectronicServiceWallets_BookBalance DEFAULT(0),
        IsActive BIT NOT NULL CONSTRAINT DF_ElectronicServiceWallets_IsActive DEFAULT(1),
        CreatedAt DATETIME2(7) NOT NULL CONSTRAINT DF_ElectronicServiceWallets_CreatedAt DEFAULT(SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,
        RowVersion ROWVERSION NOT NULL,
        CONSTRAINT PK_ElectronicServiceWallets PRIMARY KEY(Id),
        CONSTRAINT UQ_ElectronicServiceWallets_Name UNIQUE(WalletName),
        CONSTRAINT FK_ElectronicServiceWallets_AssetAccount FOREIGN KEY(AssetAccountId)
            REFERENCES dbo.Accounts(Id),
        CONSTRAINT CK_ElectronicServiceWallets_Policy CHECK
            (AccountingPolicy=N'NetAcquisitionCost'),
        CONSTRAINT CK_ElectronicServiceWallets_Balances CHECK
            (AvailableOperationalBalance>=0 AND BookBalance>=0),
        CONSTRAINT CK_ElectronicServiceWallets_Name CHECK
            (LEN(LTRIM(RTRIM(WalletName)))>0)
    );

    CREATE UNIQUE INDEX UQ_ElectronicServiceWallets_OneActiveSharedWallet
        ON dbo.ElectronicServiceWallets(IsActive)
        WHERE IsActive=1;
END;

------------------------------------------------------------
-- Sellable electronic service definition and price history
------------------------------------------------------------

IF OBJECT_ID(N'dbo.ElectronicServiceDefinitions', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ElectronicServiceDefinitions
    (
        Id INT IDENTITY(1,1) NOT NULL,
        CategoryId INT NOT NULL,
        ProviderId INT NOT NULL,
        WalletId INT NOT NULL,
        CatalogItemId INT NOT NULL,
        NominalValue DECIMAL(19,4) NULL,
        ServiceLabel NVARCHAR(150) NULL,
        CurrentOperationalWalletCost DECIMAL(19,4) NOT NULL,
        CurrentSellingPrice DECIMAL(18,3) NOT NULL,
        SuggestedName NVARCHAR(200) NOT NULL,
        DisplayName NVARCHAR(200) NOT NULL,
        IsActive BIT NOT NULL CONSTRAINT DF_ElectronicServiceDefinitions_IsActive DEFAULT(1),
        PriceVersion INT NOT NULL CONSTRAINT DF_ElectronicServiceDefinitions_PriceVersion DEFAULT(1),
        CreatedAt DATETIME2(7) NOT NULL CONSTRAINT DF_ElectronicServiceDefinitions_CreatedAt DEFAULT(SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,
        RowVersion ROWVERSION NOT NULL,
        CONSTRAINT PK_ElectronicServiceDefinitions PRIMARY KEY(Id),
        CONSTRAINT UQ_ElectronicServiceDefinitions_CatalogItem UNIQUE(CatalogItemId),
        CONSTRAINT FK_ElectronicServiceDefinitions_Category FOREIGN KEY(CategoryId)
            REFERENCES dbo.ElectronicServiceCategories(Id),
        CONSTRAINT FK_ElectronicServiceDefinitions_ProviderCategory
            FOREIGN KEY(ProviderId, CategoryId)
            REFERENCES dbo.ElectronicServiceProviders(Id, CategoryId),
        CONSTRAINT FK_ElectronicServiceDefinitions_Wallet FOREIGN KEY(WalletId)
            REFERENCES dbo.ElectronicServiceWallets(Id),
        CONSTRAINT FK_ElectronicServiceDefinitions_CatalogItem FOREIGN KEY(CatalogItemId)
            REFERENCES dbo.Items(Id),
        CONSTRAINT CK_ElectronicServiceDefinitions_Value CHECK
        (
            (NominalValue IS NOT NULL AND NominalValue>0)
            OR LEN(LTRIM(RTRIM(ISNULL(ServiceLabel,N''))))>0
        ),
        CONSTRAINT CK_ElectronicServiceDefinitions_Cost CHECK(CurrentOperationalWalletCost>0),
        CONSTRAINT CK_ElectronicServiceDefinitions_Price CHECK(CurrentSellingPrice>0),
        CONSTRAINT CK_ElectronicServiceDefinitions_Version CHECK(PriceVersion>=1),
        CONSTRAINT CK_ElectronicServiceDefinitions_Names CHECK
        (
            LEN(LTRIM(RTRIM(SuggestedName)))>0
            AND LEN(LTRIM(RTRIM(DisplayName)))>0
        )
    );

    CREATE INDEX IX_ElectronicServiceDefinitions_Lookup
        ON dbo.ElectronicServiceDefinitions(CategoryId, ProviderId, WalletId, IsActive, Id);
END;

IF OBJECT_ID(N'dbo.ElectronicServicePriceHistory', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ElectronicServicePriceHistory
    (
        Id BIGINT IDENTITY(1,1) NOT NULL,
        ServiceId INT NOT NULL,
        OldOperationalCost DECIMAL(19,4) NULL,
        NewOperationalCost DECIMAL(19,4) NOT NULL,
        OldSellingPrice DECIMAL(18,3) NULL,
        NewSellingPrice DECIMAL(18,3) NOT NULL,
        ChangedAt DATETIME2(7) NOT NULL CONSTRAINT DF_ElectronicServicePriceHistory_ChangedAt DEFAULT(SYSDATETIME()),
        ChangedByUserId INT NULL,
        Reason NVARCHAR(300) NOT NULL,
        Version INT NOT NULL,
        CONSTRAINT PK_ElectronicServicePriceHistory PRIMARY KEY(Id),
        CONSTRAINT FK_ElectronicServicePriceHistory_Service FOREIGN KEY(ServiceId)
            REFERENCES dbo.ElectronicServiceDefinitions(Id),
        CONSTRAINT FK_ElectronicServicePriceHistory_User FOREIGN KEY(ChangedByUserId)
            REFERENCES dbo.Users(Id),
        CONSTRAINT UQ_ElectronicServicePriceHistory_ServiceVersion UNIQUE(ServiceId,Version),
        CONSTRAINT CK_ElectronicServicePriceHistory_Values CHECK
        (
            NewOperationalCost>0 AND NewSellingPrice>0 AND Version>=1
            AND LEN(LTRIM(RTRIM(Reason)))>0
        )
    );

    CREATE INDEX IX_ElectronicServicePriceHistory_ServiceDate
        ON dbo.ElectronicServicePriceHistory(ServiceId, ChangedAt DESC, Id DESC);
END;

------------------------------------------------------------
-- Atomic top-ups and wallet movement subledger
------------------------------------------------------------

IF OBJECT_ID(N'dbo.ElectronicServiceTopUps', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ElectronicServiceTopUps
    (
        Id BIGINT IDENTITY(1,1) NOT NULL,
        WalletId INT NOT NULL,
        TopUpDate DATE NOT NULL,
        AmountPaid DECIMAL(18,3) NOT NULL,
        OperationalValueAdded DECIMAL(19,4) NOT NULL,
        BookValueAdded DECIMAL(18,3) NOT NULL,
        FundingAccountId INT NOT NULL,
        SupplierId INT NULL,
        Reference NVARCHAR(150) NULL,
        Notes NVARCHAR(500) NULL,
        SubmissionKey UNIQUEIDENTIFIER NOT NULL,
        Status NVARCHAR(20) NOT NULL,
        JournalEntryId INT NULL,
        CreatedByUserId INT NOT NULL,
        CreatedAt DATETIME2(7) NOT NULL CONSTRAINT DF_ElectronicServiceTopUps_CreatedAt DEFAULT(SYSDATETIME()),
        CONSTRAINT PK_ElectronicServiceTopUps PRIMARY KEY(Id),
        CONSTRAINT UQ_ElectronicServiceTopUps_SubmissionKey UNIQUE(SubmissionKey),
        CONSTRAINT UQ_ElectronicServiceTopUps_JournalEntry UNIQUE(JournalEntryId),
        CONSTRAINT FK_ElectronicServiceTopUps_Wallet FOREIGN KEY(WalletId)
            REFERENCES dbo.ElectronicServiceWallets(Id),
        CONSTRAINT FK_ElectronicServiceTopUps_FundingAccount FOREIGN KEY(FundingAccountId)
            REFERENCES dbo.Accounts(Id),
        CONSTRAINT FK_ElectronicServiceTopUps_Supplier FOREIGN KEY(SupplierId)
            REFERENCES dbo.Suppliers(Id),
        CONSTRAINT FK_ElectronicServiceTopUps_JournalEntry FOREIGN KEY(JournalEntryId)
            REFERENCES dbo.JournalEntries(Id),
        CONSTRAINT FK_ElectronicServiceTopUps_User FOREIGN KEY(CreatedByUserId)
            REFERENCES dbo.Users(Id),
        CONSTRAINT CK_ElectronicServiceTopUps_Amounts CHECK
        (
            AmountPaid>0 AND OperationalValueAdded>=AmountPaid
            AND BookValueAdded=AmountPaid
        ),
        CONSTRAINT CK_ElectronicServiceTopUps_Status CHECK(Status=N'Completed')
    );

    CREATE INDEX IX_ElectronicServiceTopUps_WalletDate
        ON dbo.ElectronicServiceTopUps(WalletId, TopUpDate DESC, Id DESC);
END;

IF OBJECT_ID(N'dbo.ElectronicServiceWalletMovements', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ElectronicServiceWalletMovements
    (
        Id BIGINT IDENTITY(1,1) NOT NULL,
        WalletId INT NOT NULL,
        MovementType NVARCHAR(30) NOT NULL,
        OperationalDelta DECIMAL(19,4) NOT NULL,
        BookDelta DECIMAL(19,4) NOT NULL,
        OperationalBalanceBefore DECIMAL(19,4) NOT NULL,
        OperationalBalanceAfter DECIMAL(19,4) NOT NULL,
        BookBalanceBefore DECIMAL(19,4) NOT NULL,
        BookBalanceAfter DECIMAL(19,4) NOT NULL,
        ReferenceType NVARCHAR(50) NOT NULL,
        ReferenceId BIGINT NOT NULL,
        SubmissionKey UNIQUEIDENTIFIER NOT NULL,
        CreatedByUserId INT NOT NULL,
        CreatedAt DATETIME2(7) NOT NULL CONSTRAINT DF_ElectronicServiceWalletMovements_CreatedAt DEFAULT(SYSDATETIME()),
        CONSTRAINT PK_ElectronicServiceWalletMovements PRIMARY KEY(Id),
        CONSTRAINT UQ_ElectronicServiceWalletMovements_SubmissionKey UNIQUE(SubmissionKey),
        CONSTRAINT UQ_ElectronicServiceWalletMovements_Reference UNIQUE(ReferenceType,ReferenceId),
        CONSTRAINT FK_ElectronicServiceWalletMovements_Wallet FOREIGN KEY(WalletId)
            REFERENCES dbo.ElectronicServiceWallets(Id),
        CONSTRAINT FK_ElectronicServiceWalletMovements_User FOREIGN KEY(CreatedByUserId)
            REFERENCES dbo.Users(Id),
        CONSTRAINT CK_ElectronicServiceWalletMovements_Type CHECK(MovementType=N'TopUp'),
        CONSTRAINT CK_ElectronicServiceWalletMovements_Balances CHECK
        (
            OperationalDelta>0 AND BookDelta>0
            AND OperationalBalanceBefore>=0 AND OperationalBalanceAfter>=0
            AND BookBalanceBefore>=0 AND BookBalanceAfter>=0
            AND OperationalBalanceAfter=OperationalBalanceBefore+OperationalDelta
            AND BookBalanceAfter=BookBalanceBefore+BookDelta
        )
    );

    CREATE INDEX IX_ElectronicServiceWalletMovements_WalletDate
        ON dbo.ElectronicServiceWalletMovements(WalletId, CreatedAt DESC, Id DESC);
END;

------------------------------------------------------------
-- Structural permissions only; no ordinary-role grants
------------------------------------------------------------

DECLARE @ElectronicServicePermissions TABLE
(
    PermissionCode NVARCHAR(150) NOT NULL PRIMARY KEY,
    PermissionName NVARCHAR(200) NOT NULL
);

INSERT INTO @ElectronicServicePermissions(PermissionCode, PermissionName)
VALUES
    (N'ElectronicServices.View', N'View electronic services'),
    (N'ElectronicServices.ManageCategories', N'Manage electronic service categories'),
    (N'ElectronicServices.ManageProviders', N'Manage electronic service providers'),
    (N'ElectronicServices.ManageWallets', N'Manage electronic service wallets'),
    (N'ElectronicServices.ManageServices', N'Manage electronic service definitions'),
    (N'ElectronicServices.ManagePrices', N'Manage electronic service prices'),
    (N'ElectronicServices.TopUp', N'Top up electronic service wallet'),
    (N'ElectronicServices.Reports', N'View electronic service reports');

INSERT INTO dbo.Permissions(PermissionCode, PermissionName, ModuleName)
SELECT source.PermissionCode, source.PermissionName, N'ElectronicServices'
FROM @ElectronicServicePermissions source
WHERE NOT EXISTS
(
    SELECT 1 FROM dbo.Permissions existing
    WHERE existing.PermissionCode=source.PermissionCode
);

INSERT INTO dbo.RolePermissions(RoleId, PermissionId)
SELECT role.Id, permission.Id
FROM dbo.Roles role
CROSS JOIN dbo.Permissions permission
INNER JOIN @ElectronicServicePermissions approved
    ON approved.PermissionCode=permission.PermissionCode
WHERE role.RoleCode=N'ADMIN'
  AND NOT EXISTS
  (
      SELECT 1 FROM dbo.RolePermissions existing
      WHERE existing.RoleId=role.Id AND existing.PermissionId=permission.Id
  );

GO

------------------------------------------------------------
-- Append-only financial history
------------------------------------------------------------

CREATE OR ALTER TRIGGER dbo.TR_ElectronicServicePriceHistory_AppendOnly
ON dbo.ElectronicServicePriceHistory
AFTER UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    THROW 52301, N'Electronic service price history is append-only.', 1;
END;

GO

CREATE OR ALTER TRIGGER dbo.TR_ElectronicServiceWalletMovements_AppendOnly
ON dbo.ElectronicServiceWalletMovements
AFTER UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    THROW 52302, N'Electronic service wallet movements are append-only.', 1;
END;

GO

CREATE OR ALTER TRIGGER dbo.TR_ElectronicServiceTopUps_Immutable
ON dbo.ElectronicServiceTopUps
AFTER UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS
    (
        SELECT 1
        FROM deleted oldRow
        LEFT JOIN inserted newRow ON newRow.Id=oldRow.Id
        WHERE newRow.Id IS NULL
           OR oldRow.JournalEntryId IS NOT NULL
           OR newRow.JournalEntryId IS NULL
           OR newRow.WalletId<>oldRow.WalletId
           OR newRow.TopUpDate<>oldRow.TopUpDate
           OR newRow.AmountPaid<>oldRow.AmountPaid
           OR newRow.OperationalValueAdded<>oldRow.OperationalValueAdded
           OR newRow.BookValueAdded<>oldRow.BookValueAdded
           OR newRow.FundingAccountId<>oldRow.FundingAccountId
           OR ISNULL(newRow.SupplierId,-1)<>ISNULL(oldRow.SupplierId,-1)
           OR ISNULL(newRow.Reference,N'')<>ISNULL(oldRow.Reference,N'')
           OR ISNULL(newRow.Notes,N'')<>ISNULL(oldRow.Notes,N'')
           OR newRow.SubmissionKey<>oldRow.SubmissionKey
           OR newRow.Status<>oldRow.Status
           OR newRow.CreatedByUserId<>oldRow.CreatedByUserId
           OR newRow.CreatedAt<>oldRow.CreatedAt
    )
        THROW 52303, N'Completed electronic service top-ups are immutable.', 1;
END;

GO

------------------------------------------------------------
-- Explicit inventory isolation guards
------------------------------------------------------------

CREATE OR ALTER TRIGGER dbo.TR_PurchaseItems_BlockElectronicServices
ON dbo.PurchaseItems
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS
    (
        SELECT 1 FROM inserted row
        INNER JOIN dbo.Items item ON item.Id=row.ItemId
        WHERE item.ItemKind=N'ElectronicService'
    )
        THROW 52311, N'Electronic services cannot enter purchase invoices.', 1;
END;

GO

CREATE OR ALTER TRIGGER dbo.TR_OpeningBalanceItems_BlockElectronicServices
ON dbo.OpeningBalanceItems
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS
    (
        SELECT 1 FROM inserted row
        INNER JOIN dbo.Items item ON item.Id=row.ItemId
        WHERE item.ItemKind=N'ElectronicService'
    )
        THROW 52312, N'Electronic services cannot enter inventory opening balances.', 1;
END;

GO

CREATE OR ALTER TRIGGER dbo.TR_StockOperationItems_BlockElectronicServices
ON dbo.StockOperationItems
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS
    (
        SELECT 1 FROM inserted row
        INNER JOIN dbo.Items item ON item.Id=row.ItemId
        WHERE item.ItemKind=N'ElectronicService'
    )
        THROW 52313, N'Electronic services cannot enter warehouse operations.', 1;
END;

GO

CREATE OR ALTER TRIGGER dbo.TR_StockMovements_BlockElectronicServices
ON dbo.StockMovements
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS
    (
        SELECT 1 FROM inserted row
        INNER JOIN dbo.Items item ON item.Id=row.ItemId
        WHERE item.ItemKind=N'ElectronicService'
    )
        THROW 52314, N'Electronic services cannot create stock movements.', 1;
END;

GO

CREATE OR ALTER TRIGGER dbo.TR_ItemWarehouseCosts_BlockElectronicServices
ON dbo.ItemWarehouseCosts
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS
    (
        SELECT 1 FROM inserted row
        INNER JOIN dbo.Items item ON item.Id=row.ItemId
        WHERE item.ItemKind=N'ElectronicService'
    )
        THROW 52315, N'Electronic services cannot create warehouse cost rows.', 1;
END;

GO
