﻿/* 
    M3 / STEP 2
    Add item image path and item-supplier relation.
    Rules:
    - No data deletion
    - No DROP
    - Idempotent / safe to run once through migration runner
*/

IF COL_LENGTH('dbo.Items', 'ImagePath') IS NULL
BEGIN
    ALTER TABLE dbo.Items
    ADD ImagePath NVARCHAR(500) NULL;
END;

IF OBJECT_ID('dbo.ItemSuppliers', 'U') IS NULL
BEGIN
    CREATE TABLE dbo.ItemSuppliers
    (
        Id INT IDENTITY(1,1) NOT NULL,
        ItemId INT NOT NULL,
        SupplierId INT NOT NULL,
        IsDefault BIT NOT NULL
            CONSTRAINT DF_ItemSuppliers_IsDefault DEFAULT (0),
        CreatedAt DATETIME2 NOT NULL
            CONSTRAINT DF_ItemSuppliers_CreatedAt DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2 NULL,

        CONSTRAINT PK_ItemSuppliers
            PRIMARY KEY (Id),

        CONSTRAINT FK_ItemSuppliers_Items
            FOREIGN KEY (ItemId)
            REFERENCES dbo.Items(Id),

        CONSTRAINT FK_ItemSuppliers_Suppliers
            FOREIGN KEY (SupplierId)
            REFERENCES dbo.Suppliers(Id),

        CONSTRAINT UQ_ItemSuppliers_Item_Supplier
            UNIQUE (ItemId, SupplierId)
    );
END;

IF OBJECT_ID('dbo.ItemSuppliers', 'U') IS NOT NULL
BEGIN
    IF COL_LENGTH('dbo.ItemSuppliers', 'ItemId') IS NULL
    BEGIN
        ALTER TABLE dbo.ItemSuppliers
        ADD ItemId INT NOT NULL;
    END;

    IF COL_LENGTH('dbo.ItemSuppliers', 'SupplierId') IS NULL
    BEGIN
        ALTER TABLE dbo.ItemSuppliers
        ADD SupplierId INT NOT NULL;
    END;

    IF COL_LENGTH('dbo.ItemSuppliers', 'IsDefault') IS NULL
    BEGIN
        ALTER TABLE dbo.ItemSuppliers
        ADD IsDefault BIT NOT NULL
            CONSTRAINT DF_ItemSuppliers_IsDefault DEFAULT (0);
    END;

    IF COL_LENGTH('dbo.ItemSuppliers', 'CreatedAt') IS NULL
    BEGIN
        ALTER TABLE dbo.ItemSuppliers
        ADD CreatedAt DATETIME2 NOT NULL
            CONSTRAINT DF_ItemSuppliers_CreatedAt DEFAULT (SYSDATETIME());
    END;

    IF COL_LENGTH('dbo.ItemSuppliers', 'UpdatedAt') IS NULL
    BEGIN
        ALTER TABLE dbo.ItemSuppliers
        ADD UpdatedAt DATETIME2 NULL;
    END;
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE name = N'FK_ItemSuppliers_Items'
)
AND OBJECT_ID('dbo.ItemSuppliers', 'U') IS NOT NULL
BEGIN
    ALTER TABLE dbo.ItemSuppliers
    ADD CONSTRAINT FK_ItemSuppliers_Items
        FOREIGN KEY (ItemId)
        REFERENCES dbo.Items(Id);
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE name = N'FK_ItemSuppliers_Suppliers'
)
AND OBJECT_ID('dbo.ItemSuppliers', 'U') IS NOT NULL
BEGIN
    ALTER TABLE dbo.ItemSuppliers
    ADD CONSTRAINT FK_ItemSuppliers_Suppliers
        FOREIGN KEY (SupplierId)
        REFERENCES dbo.Suppliers(Id);
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'UQ_ItemSuppliers_Item_Supplier'
      AND object_id = OBJECT_ID(N'dbo.ItemSuppliers')
)
AND OBJECT_ID('dbo.ItemSuppliers', 'U') IS NOT NULL
BEGIN
    CREATE UNIQUE INDEX UQ_ItemSuppliers_Item_Supplier
    ON dbo.ItemSuppliers(ItemId, SupplierId);
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'IX_ItemSuppliers_ItemId'
      AND object_id = OBJECT_ID(N'dbo.ItemSuppliers')
)
AND OBJECT_ID('dbo.ItemSuppliers', 'U') IS NOT NULL
BEGIN
    CREATE INDEX IX_ItemSuppliers_ItemId
    ON dbo.ItemSuppliers(ItemId);
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'IX_ItemSuppliers_SupplierId'
      AND object_id = OBJECT_ID(N'dbo.ItemSuppliers')
)
AND OBJECT_ID('dbo.ItemSuppliers', 'U') IS NOT NULL
BEGIN
    CREATE INDEX IX_ItemSuppliers_SupplierId
    ON dbo.ItemSuppliers(SupplierId);
END;

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'UQ_ItemSuppliers_DefaultSupplierPerItem'
      AND object_id = OBJECT_ID(N'dbo.ItemSuppliers')
)
AND OBJECT_ID('dbo.ItemSuppliers', 'U') IS NOT NULL
BEGIN
    CREATE UNIQUE INDEX UQ_ItemSuppliers_DefaultSupplierPerItem
    ON dbo.ItemSuppliers(ItemId)
    WHERE IsDefault = 1;
END;