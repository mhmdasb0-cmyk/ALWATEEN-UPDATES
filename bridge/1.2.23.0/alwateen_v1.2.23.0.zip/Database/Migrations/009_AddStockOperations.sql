﻿/*
    M9 / STEP 2
    Add official warehouse operation documents.

    Purpose:
    - Stock operations must have an official header document.
    - StockMovements will later reference StockOperations.Id using ReferenceType = WarehouseOperation.
    - No direct quantity editing.
    - No hard delete.
*/

IF OBJECT_ID(N'dbo.StockOperations', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.StockOperations
    (
        Id INT IDENTITY(1,1) NOT NULL,

        OperationNumber NVARCHAR(30) NOT NULL,
        OperationDate DATETIME2 NOT NULL,
        OperationType NVARCHAR(30) NOT NULL,

        FromWarehouseId INT NULL,
        ToWarehouseId INT NULL,

        Reason NVARCHAR(255) NULL,
        Notes NVARCHAR(500) NULL,

        IsCancelled BIT NOT NULL
            CONSTRAINT DF_StockOperations_IsCancelled DEFAULT (0),

        CancelledAt DATETIME2 NULL,
        CancelReason NVARCHAR(500) NULL,

        CreatedAt DATETIME2 NOT NULL
            CONSTRAINT DF_StockOperations_CreatedAt DEFAULT (SYSDATETIME()),

        UpdatedAt DATETIME2 NULL,

        CONSTRAINT PK_StockOperations
            PRIMARY KEY (Id)
    );
END;
GO


IF OBJECT_ID(N'dbo.StockOperationItems', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.StockOperationItems
    (
        Id INT IDENTITY(1,1) NOT NULL,

        StockOperationId INT NOT NULL,
        ItemId INT NOT NULL,

        Qty DECIMAL(18,3) NOT NULL,
        UnitCost DECIMAL(18,4) NOT NULL,

        Notes NVARCHAR(500) NULL,

        CreatedAt DATETIME2 NOT NULL
            CONSTRAINT DF_StockOperationItems_CreatedAt DEFAULT (SYSDATETIME()),

        CONSTRAINT PK_StockOperationItems
            PRIMARY KEY (Id)
    );
END;
GO


/* =========================================================
   Foreign Keys
   ========================================================= */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE name = N'FK_StockOperations_FromWarehouse'
)
BEGIN
    ALTER TABLE dbo.StockOperations
    ADD CONSTRAINT FK_StockOperations_FromWarehouse
        FOREIGN KEY (FromWarehouseId)
        REFERENCES dbo.Warehouses(Id);
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE name = N'FK_StockOperations_ToWarehouse'
)
BEGIN
    ALTER TABLE dbo.StockOperations
    ADD CONSTRAINT FK_StockOperations_ToWarehouse
        FOREIGN KEY (ToWarehouseId)
        REFERENCES dbo.Warehouses(Id);
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE name = N'FK_StockOperationItems_Operation'
)
BEGIN
    ALTER TABLE dbo.StockOperationItems
    ADD CONSTRAINT FK_StockOperationItems_Operation
        FOREIGN KEY (StockOperationId)
        REFERENCES dbo.StockOperations(Id);
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE name = N'FK_StockOperationItems_Items'
)
BEGIN
    ALTER TABLE dbo.StockOperationItems
    ADD CONSTRAINT FK_StockOperationItems_Items
        FOREIGN KEY (ItemId)
        REFERENCES dbo.Items(Id);
END;
GO


/* =========================================================
   Unique / Check Constraints
   ========================================================= */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'UQ_StockOperations_OperationNumber'
      AND object_id = OBJECT_ID(N'dbo.StockOperations')
)
BEGIN
    CREATE UNIQUE INDEX UQ_StockOperations_OperationNumber
    ON dbo.StockOperations(OperationNumber);
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE name = N'CK_StockOperations_OperationType'
      AND parent_object_id = OBJECT_ID(N'dbo.StockOperations')
)
BEGIN
    ALTER TABLE dbo.StockOperations
    ADD CONSTRAINT CK_StockOperations_OperationType
    CHECK
    (
        OperationType IN
        (
            N'Transfer',
            N'AdjustmentIn',
            N'AdjustmentOut',
            N'Damage',
            N'ManualIn',
            N'ManualOut'
        )
    );
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE name = N'CK_StockOperations_WarehouseRules'
      AND parent_object_id = OBJECT_ID(N'dbo.StockOperations')
)
BEGIN
    ALTER TABLE dbo.StockOperations
    ADD CONSTRAINT CK_StockOperations_WarehouseRules
    CHECK
    (
        (
            OperationType = N'Transfer'
            AND FromWarehouseId IS NOT NULL
            AND ToWarehouseId IS NOT NULL
            AND FromWarehouseId <> ToWarehouseId
        )
        OR
        (
            OperationType IN (N'AdjustmentIn', N'ManualIn')
            AND FromWarehouseId IS NULL
            AND ToWarehouseId IS NOT NULL
        )
        OR
        (
            OperationType IN (N'AdjustmentOut', N'Damage', N'ManualOut')
            AND FromWarehouseId IS NOT NULL
            AND ToWarehouseId IS NULL
        )
    );
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE name = N'CK_StockOperations_CancelState'
      AND parent_object_id = OBJECT_ID(N'dbo.StockOperations')
)
BEGIN
    ALTER TABLE dbo.StockOperations
    ADD CONSTRAINT CK_StockOperations_CancelState
    CHECK
    (
        (
            IsCancelled = 0
            AND CancelledAt IS NULL
            AND CancelReason IS NULL
        )
        OR
        (
            IsCancelled = 1
            AND CancelledAt IS NOT NULL
            AND CancelReason IS NOT NULL
            AND LTRIM(RTRIM(CancelReason)) <> N''
        )
    );
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE name = N'CK_StockOperationItems_Qty'
      AND parent_object_id = OBJECT_ID(N'dbo.StockOperationItems')
)
BEGIN
    ALTER TABLE dbo.StockOperationItems
    ADD CONSTRAINT CK_StockOperationItems_Qty
    CHECK (Qty > 0);
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE name = N'CK_StockOperationItems_UnitCost'
      AND parent_object_id = OBJECT_ID(N'dbo.StockOperationItems')
)
BEGIN
    ALTER TABLE dbo.StockOperationItems
    ADD CONSTRAINT CK_StockOperationItems_UnitCost
    CHECK (UnitCost >= 0);
END;
GO


/* =========================================================
   Indexes
   ========================================================= */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'IX_StockOperations_OperationDate'
      AND object_id = OBJECT_ID(N'dbo.StockOperations')
)
BEGIN
    CREATE INDEX IX_StockOperations_OperationDate
    ON dbo.StockOperations(OperationDate);
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'IX_StockOperations_OperationType'
      AND object_id = OBJECT_ID(N'dbo.StockOperations')
)
BEGIN
    CREATE INDEX IX_StockOperations_OperationType
    ON dbo.StockOperations(OperationType);
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'IX_StockOperations_FromWarehouseId'
      AND object_id = OBJECT_ID(N'dbo.StockOperations')
)
BEGIN
    CREATE INDEX IX_StockOperations_FromWarehouseId
    ON dbo.StockOperations(FromWarehouseId);
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'IX_StockOperations_ToWarehouseId'
      AND object_id = OBJECT_ID(N'dbo.StockOperations')
)
BEGIN
    CREATE INDEX IX_StockOperations_ToWarehouseId
    ON dbo.StockOperations(ToWarehouseId);
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'IX_StockOperationItems_OperationId'
      AND object_id = OBJECT_ID(N'dbo.StockOperationItems')
)
BEGIN
    CREATE INDEX IX_StockOperationItems_OperationId
    ON dbo.StockOperationItems(StockOperationId);
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'IX_StockOperationItems_ItemId'
      AND object_id = OBJECT_ID(N'dbo.StockOperationItems')
)
BEGIN
    CREATE INDEX IX_StockOperationItems_ItemId
    ON dbo.StockOperationItems(ItemId);
END;
GO


/* =========================================================
   Verification
   ========================================================= */

SELECT
    'StockOperations' AS ObjectName,
    OBJECT_ID(N'dbo.StockOperations', N'U') AS ObjectId
UNION ALL
SELECT
    'StockOperationItems',
    OBJECT_ID(N'dbo.StockOperationItems', N'U');
GO