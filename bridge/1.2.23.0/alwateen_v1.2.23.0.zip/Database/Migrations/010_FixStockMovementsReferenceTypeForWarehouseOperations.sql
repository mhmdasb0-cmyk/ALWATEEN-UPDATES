﻿/*
    M9 / STEP 3-A
    Fix StockMovements.ReferenceType constraint for warehouse operations.

    Purpose:
    - StockOperationService writes StockMovements using ReferenceType = 'WarehouseOperation'.
    - The old CK_StockMovements_ReferenceType constraint did not allow this value.
    - This migration safely rebuilds the constraint and keeps all previously allowed values.
*/

IF OBJECT_ID(N'dbo.StockMovements', N'U') IS NOT NULL
BEGIN
    IF EXISTS
    (
        SELECT 1
        FROM sys.check_constraints
        WHERE name = N'CK_StockMovements_ReferenceType'
          AND parent_object_id = OBJECT_ID(N'dbo.StockMovements')
    )
    BEGIN
        ALTER TABLE dbo.StockMovements
        DROP CONSTRAINT CK_StockMovements_ReferenceType;
    END;

    ALTER TABLE dbo.StockMovements WITH CHECK
    ADD CONSTRAINT CK_StockMovements_ReferenceType
    CHECK
    (
        ReferenceType IN
        (
            N'Purchase',
            N'PurchaseEdit',
            N'PurchaseCancel',
            N'Sale',
            N'SaleEdit',
            N'SaleCancel',
            N'OpeningBalance',
            N'ManualAdjustment',
            N'WarehouseOperation'
        )
    );

    ALTER TABLE dbo.StockMovements
    CHECK CONSTRAINT CK_StockMovements_ReferenceType;
END;
GO