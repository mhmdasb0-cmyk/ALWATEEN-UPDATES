/*
    020_ExtendStockMovementReferenceTypes.sql

    Preserves published migration 018 as immutable and applies the later
    StockMovements reference-type constraint expansion independently.
*/

SET XACT_ABORT ON;

IF EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE name = N'CK_StockMovements_ReferenceType'
      AND parent_object_id = OBJECT_ID(N'dbo.StockMovements')
)
BEGIN
    ALTER TABLE dbo.StockMovements
    DROP CONSTRAINT CK_StockMovements_ReferenceType;
END;

ALTER TABLE dbo.StockMovements WITH CHECK
ADD CONSTRAINT CK_StockMovements_ReferenceType
CHECK
(
    ReferenceType IN
    (
        N'Purchase',
        N'PurchaseEdit',
        N'PurchaseCancel',
        N'Sale',
        N'SaleEdit',
        N'SaleCancel',
        N'OpeningBalance',
        N'OpeningBalanceReversal',
        N'ManualAdjustment',
        N'WarehouseOperation',
        N'WarehouseOperationReversal'
    )
);

ALTER TABLE dbo.StockMovements
CHECK CONSTRAINT CK_StockMovements_ReferenceType;
