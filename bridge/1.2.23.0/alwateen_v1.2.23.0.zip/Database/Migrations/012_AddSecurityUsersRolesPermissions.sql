/*
    012_AddSecurityUsersRolesPermissions.sql

    Security foundation schema:
    - Users, Roles, Permissions, UserRoles, RolePermissions
    - Seed system roles and permissions
    - ADMIN receives all permissions
    - No admin user or password seeded (deferred to SECURITY-02)
*/

/* =========================================================
   Users
   ========================================================= */

IF OBJECT_ID(N'dbo.Users', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Users
    (
        Id INT IDENTITY(1,1) NOT NULL,

        Username NVARCHAR(100) NOT NULL,
        DisplayName NVARCHAR(200) NOT NULL,

        PasswordHash VARBINARY(64) NULL,
        PasswordSalt VARBINARY(32) NULL,
        PasswordIterations INT NULL,
        PasswordAlgorithm NVARCHAR(50) NULL,

        IsActive BIT NOT NULL
            CONSTRAINT DF_Users_IsActive DEFAULT (1),

        IsLocked BIT NOT NULL
            CONSTRAINT DF_Users_IsLocked DEFAULT (0),

        FailedLoginAttempts INT NOT NULL
            CONSTRAINT DF_Users_FailedLoginAttempts DEFAULT (0),

        LastLoginAt DATETIME2 NULL,

        CreatedAt DATETIME2 NOT NULL
            CONSTRAINT DF_Users_CreatedAt DEFAULT (SYSDATETIME()),

        UpdatedAt DATETIME2 NULL,

        CONSTRAINT PK_Users
            PRIMARY KEY (Id),

        CONSTRAINT CK_Users_Username_NotEmpty
            CHECK (LEN(LTRIM(RTRIM(Username))) > 0),

        CONSTRAINT CK_Users_DisplayName_NotEmpty
            CHECK (LEN(LTRIM(RTRIM(DisplayName))) > 0)
    );
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'UQ_Users_Username'
      AND object_id = OBJECT_ID(N'dbo.Users')
)
BEGIN
    CREATE UNIQUE INDEX UQ_Users_Username
    ON dbo.Users(Username);
END;
GO

/* =========================================================
   Roles
   ========================================================= */

IF OBJECT_ID(N'dbo.Roles', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Roles
    (
        Id INT IDENTITY(1,1) NOT NULL,

        RoleCode NVARCHAR(100) NOT NULL,
        RoleName NVARCHAR(200) NOT NULL,
        Description NVARCHAR(500) NULL,

        IsSystemRole BIT NOT NULL
            CONSTRAINT DF_Roles_IsSystemRole DEFAULT (0),

        IsActive BIT NOT NULL
            CONSTRAINT DF_Roles_IsActive DEFAULT (1),

        CreatedAt DATETIME2 NOT NULL
            CONSTRAINT DF_Roles_CreatedAt DEFAULT (SYSDATETIME()),

        CONSTRAINT PK_Roles
            PRIMARY KEY (Id),

        CONSTRAINT CK_Roles_RoleCode_NotEmpty
            CHECK (LEN(LTRIM(RTRIM(RoleCode))) > 0),

        CONSTRAINT CK_Roles_RoleName_NotEmpty
            CHECK (LEN(LTRIM(RTRIM(RoleName))) > 0)
    );
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'UQ_Roles_RoleCode'
      AND object_id = OBJECT_ID(N'dbo.Roles')
)
BEGIN
    CREATE UNIQUE INDEX UQ_Roles_RoleCode
    ON dbo.Roles(RoleCode);
END;
GO

/* =========================================================
   Permissions
   ========================================================= */

IF OBJECT_ID(N'dbo.Permissions', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Permissions
    (
        Id INT IDENTITY(1,1) NOT NULL,

        PermissionCode NVARCHAR(150) NOT NULL,
        PermissionName NVARCHAR(200) NOT NULL,
        ModuleName NVARCHAR(100) NOT NULL,
        Description NVARCHAR(500) NULL,

        IsActive BIT NOT NULL
            CONSTRAINT DF_Permissions_IsActive DEFAULT (1),

        CreatedAt DATETIME2 NOT NULL
            CONSTRAINT DF_Permissions_CreatedAt DEFAULT (SYSDATETIME()),

        CONSTRAINT PK_Permissions
            PRIMARY KEY (Id),

        CONSTRAINT CK_Permissions_PermissionCode_NotEmpty
            CHECK (LEN(LTRIM(RTRIM(PermissionCode))) > 0),

        CONSTRAINT CK_Permissions_PermissionName_NotEmpty
            CHECK (LEN(LTRIM(RTRIM(PermissionName))) > 0),

        CONSTRAINT CK_Permissions_ModuleName_NotEmpty
            CHECK (LEN(LTRIM(RTRIM(ModuleName))) > 0)
    );
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'UQ_Permissions_PermissionCode'
      AND object_id = OBJECT_ID(N'dbo.Permissions')
)
BEGIN
    CREATE UNIQUE INDEX UQ_Permissions_PermissionCode
    ON dbo.Permissions(PermissionCode);
END;
GO

/* =========================================================
   UserRoles
   ========================================================= */

IF OBJECT_ID(N'dbo.UserRoles', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.UserRoles
    (
        UserId INT NOT NULL,
        RoleId INT NOT NULL,

        CreatedAt DATETIME2 NOT NULL
            CONSTRAINT DF_UserRoles_CreatedAt DEFAULT (SYSDATETIME()),

        CONSTRAINT PK_UserRoles
            PRIMARY KEY (UserId, RoleId)
    );
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE name = N'FK_UserRoles_Users'
)
BEGIN
    ALTER TABLE dbo.UserRoles
    ADD CONSTRAINT FK_UserRoles_Users
        FOREIGN KEY (UserId)
        REFERENCES dbo.Users(Id);
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE name = N'FK_UserRoles_Roles'
)
BEGIN
    ALTER TABLE dbo.UserRoles
    ADD CONSTRAINT FK_UserRoles_Roles
        FOREIGN KEY (RoleId)
        REFERENCES dbo.Roles(Id);
END;
GO

/* =========================================================
   RolePermissions
   ========================================================= */

IF OBJECT_ID(N'dbo.RolePermissions', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.RolePermissions
    (
        RoleId INT NOT NULL,
        PermissionId INT NOT NULL,

        CreatedAt DATETIME2 NOT NULL
            CONSTRAINT DF_RolePermissions_CreatedAt DEFAULT (SYSDATETIME()),

        CONSTRAINT PK_RolePermissions
            PRIMARY KEY (RoleId, PermissionId)
    );
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE name = N'FK_RolePermissions_Roles'
)
BEGIN
    ALTER TABLE dbo.RolePermissions
    ADD CONSTRAINT FK_RolePermissions_Roles
        FOREIGN KEY (RoleId)
        REFERENCES dbo.Roles(Id);
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.foreign_keys
    WHERE name = N'FK_RolePermissions_Permissions'
)
BEGIN
    ALTER TABLE dbo.RolePermissions
    ADD CONSTRAINT FK_RolePermissions_Permissions
        FOREIGN KEY (PermissionId)
        REFERENCES dbo.Permissions(Id);
END;
GO

/* =========================================================
   Seed Roles
   ========================================================= */

IF NOT EXISTS (SELECT 1 FROM dbo.Roles WHERE RoleCode = N'ADMIN')
BEGIN
    INSERT INTO dbo.Roles
    (
        RoleCode,
        RoleName,
        Description,
        IsSystemRole,
        IsActive
    )
    VALUES
    (
        N'ADMIN',
        N'Administrator',
        N'Full system access',
        1,
        1
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Roles WHERE RoleCode = N'MANAGER')
BEGIN
    INSERT INTO dbo.Roles
    (
        RoleCode,
        RoleName,
        Description,
        IsSystemRole,
        IsActive
    )
    VALUES
    (
        N'MANAGER',
        N'Manager',
        N'Operational management without security administration',
        1,
        1
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Roles WHERE RoleCode = N'CASHIER')
BEGIN
    INSERT INTO dbo.Roles
    (
        RoleCode,
        RoleName,
        Description,
        IsSystemRole,
        IsActive
    )
    VALUES
    (
        N'CASHIER',
        N'Cashier',
        N'Sales and receipt operations',
        1,
        1
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Roles WHERE RoleCode = N'VIEWER')
BEGIN
    INSERT INTO dbo.Roles
    (
        RoleCode,
        RoleName,
        Description,
        IsSystemRole,
        IsActive
    )
    VALUES
    (
        N'VIEWER',
        N'Viewer',
        N'Read-only access',
        1,
        1
    );
END;
GO

/* =========================================================
   Seed Permissions
   ========================================================= */

DECLARE @PermissionSeed TABLE
(
    PermissionCode NVARCHAR(150) NOT NULL,
    PermissionName NVARCHAR(200) NOT NULL,
    ModuleName NVARCHAR(100) NOT NULL,
    Description NVARCHAR(500) NULL
);

INSERT INTO @PermissionSeed
(
    PermissionCode,
    PermissionName,
    ModuleName,
    Description
)
VALUES
    (N'Dashboard.View', N'View Dashboard', N'Dashboard', N'View dashboard'),
    (N'Items.View', N'View Items', N'Items', N'View items'),
    (N'Items.Create', N'Create Items', N'Items', N'Create items'),
    (N'Items.Edit', N'Edit Items', N'Items', N'Edit items'),
    (N'Customers.View', N'View Customers', N'Customers', N'View customers'),
    (N'Customers.Create', N'Create Customers', N'Customers', N'Create customers'),
    (N'Customers.Edit', N'Edit Customers', N'Customers', N'Edit customers'),
    (N'Suppliers.View', N'View Suppliers', N'Suppliers', N'View suppliers'),
    (N'Suppliers.Create', N'Create Suppliers', N'Suppliers', N'Create suppliers'),
    (N'Suppliers.Edit', N'Edit Suppliers', N'Suppliers', N'Edit suppliers'),
    (N'Purchases.View', N'View Purchases', N'Purchases', N'View purchases'),
    (N'Purchases.Create', N'Create Purchases', N'Purchases', N'Create purchases'),
    (N'Purchases.Edit', N'Edit Purchases', N'Purchases', N'Edit purchases'),
    (N'Purchases.Cancel', N'Cancel Purchases', N'Purchases', N'Cancel purchases'),
    (N'Sales.View', N'View Sales', N'Sales', N'View sales'),
    (N'Sales.Create', N'Create Sales', N'Sales', N'Create sales'),
    (N'Sales.Edit', N'Edit Sales', N'Sales', N'Edit sales'),
    (N'Sales.Cancel', N'Cancel Sales', N'Sales', N'Cancel sales'),
    (N'Sales.AllowBelowCost', N'Allow Below Cost Sales', N'Sales', N'Allow below cost sales'),
    (N'Receipts.View', N'View Receipts', N'Payments', N'View receipt vouchers'),
    (N'Receipts.Create', N'Create Receipts', N'Payments', N'Create receipt vouchers'),
    (N'Receipts.Cancel', N'Cancel Receipts', N'Payments', N'Cancel receipt vouchers'),
    (N'Payments.View', N'View Payments', N'Payments', N'View payment vouchers'),
    (N'Payments.Create', N'Create Payments', N'Payments', N'Create payment vouchers'),
    (N'Payments.Cancel', N'Cancel Payments', N'Payments', N'Cancel payment vouchers'),
    (N'Stock.View', N'View Stock', N'Stock', N'View stock'),
    (N'StockOperations.View', N'View Stock Operations', N'Stock', N'View stock operations'),
    (N'StockOperations.Create', N'Create Stock Operations', N'Stock', N'Create stock operations'),
    (N'StockOperations.Cancel', N'Cancel Stock Operations', N'Stock', N'Cancel stock operations'),
    (N'Accounting.View', N'View Accounting', N'Accounting', N'View accounting'),
    (N'Journal.View', N'View Journal', N'Accounting', N'View journal entries'),
    (N'ChartOfAccounts.View', N'View Chart Of Accounts', N'Accounting', N'View chart of accounts'),
    (N'FiscalPeriods.View', N'View Fiscal Periods', N'Accounting', N'View fiscal periods'),
    (N'Reports.View', N'View Reports', N'Reports', N'View reports'),
    (N'Security.Users.View', N'View Users', N'Security', N'View users'),
    (N'Security.Users.Manage', N'Manage Users', N'Security', N'Manage users'),
    (N'Security.Roles.View', N'View Roles', N'Security', N'View roles'),
    (N'Security.Roles.Manage', N'Manage Roles', N'Security', N'Manage roles');

INSERT INTO dbo.Permissions
(
    PermissionCode,
    PermissionName,
    ModuleName,
    Description,
    IsActive
)
SELECT
    s.PermissionCode,
    s.PermissionName,
    s.ModuleName,
    s.Description,
    1
FROM @PermissionSeed s
WHERE NOT EXISTS
(
    SELECT 1
    FROM dbo.Permissions p
    WHERE p.PermissionCode = s.PermissionCode
);
GO

/* =========================================================
   Seed RolePermissions - ADMIN (all permissions)
   ========================================================= */

INSERT INTO dbo.RolePermissions
(
    RoleId,
    PermissionId
)
SELECT
    r.Id,
    p.Id
FROM dbo.Roles r
CROSS JOIN dbo.Permissions p
WHERE r.RoleCode = N'ADMIN'
  AND NOT EXISTS
  (
      SELECT 1
      FROM dbo.RolePermissions rp
      WHERE rp.RoleId = r.Id
        AND rp.PermissionId = p.Id
  );
GO

/* =========================================================
   Seed RolePermissions - MANAGER
   ========================================================= */

DECLARE @ManagerPermissionCodes TABLE
(
    PermissionCode NVARCHAR(150) NOT NULL PRIMARY KEY
);

INSERT INTO @ManagerPermissionCodes (PermissionCode)
VALUES
    (N'Dashboard.View'),
    (N'Items.View'),
    (N'Items.Create'),
    (N'Items.Edit'),
    (N'Customers.View'),
    (N'Customers.Create'),
    (N'Customers.Edit'),
    (N'Suppliers.View'),
    (N'Suppliers.Create'),
    (N'Suppliers.Edit'),
    (N'Purchases.View'),
    (N'Purchases.Create'),
    (N'Purchases.Edit'),
    (N'Purchases.Cancel'),
    (N'Sales.View'),
    (N'Sales.Create'),
    (N'Sales.Edit'),
    (N'Sales.Cancel'),
    (N'Sales.AllowBelowCost'),
    (N'Receipts.View'),
    (N'Receipts.Create'),
    (N'Receipts.Cancel'),
    (N'Payments.View'),
    (N'Payments.Create'),
    (N'Payments.Cancel'),
    (N'Stock.View'),
    (N'StockOperations.View'),
    (N'StockOperations.Create'),
    (N'StockOperations.Cancel'),
    (N'Accounting.View'),
    (N'Journal.View'),
    (N'ChartOfAccounts.View'),
    (N'FiscalPeriods.View'),
    (N'Reports.View'),
    (N'Security.Users.View'),
    (N'Security.Roles.View');

INSERT INTO dbo.RolePermissions
(
    RoleId,
    PermissionId
)
SELECT
    r.Id,
    p.Id
FROM dbo.Roles r
INNER JOIN dbo.Permissions p
    ON p.PermissionCode IN
    (
        SELECT mpc.PermissionCode
        FROM @ManagerPermissionCodes mpc
    )
WHERE r.RoleCode = N'MANAGER'
  AND NOT EXISTS
  (
      SELECT 1
      FROM dbo.RolePermissions rp
      WHERE rp.RoleId = r.Id
        AND rp.PermissionId = p.Id
  );
GO

/* =========================================================
   Seed RolePermissions - CASHIER
   ========================================================= */

DECLARE @CashierPermissionCodes TABLE
(
    PermissionCode NVARCHAR(150) NOT NULL PRIMARY KEY
);

INSERT INTO @CashierPermissionCodes (PermissionCode)
VALUES
    (N'Dashboard.View'),
    (N'Items.View'),
    (N'Customers.View'),
    (N'Stock.View'),
    (N'Sales.View'),
    (N'Sales.Create'),
    (N'Receipts.View'),
    (N'Receipts.Create');

INSERT INTO dbo.RolePermissions
(
    RoleId,
    PermissionId
)
SELECT
    r.Id,
    p.Id
FROM dbo.Roles r
INNER JOIN dbo.Permissions p
    ON p.PermissionCode IN
    (
        SELECT cpc.PermissionCode
        FROM @CashierPermissionCodes cpc
    )
WHERE r.RoleCode = N'CASHIER'
  AND NOT EXISTS
  (
      SELECT 1
      FROM dbo.RolePermissions rp
      WHERE rp.RoleId = r.Id
        AND rp.PermissionId = p.Id
  );
GO

/* =========================================================
   Seed RolePermissions - VIEWER (view-only)
   ========================================================= */

INSERT INTO dbo.RolePermissions
(
    RoleId,
    PermissionId
)
SELECT
    r.Id,
    p.Id
FROM dbo.Roles r
INNER JOIN dbo.Permissions p
    ON p.PermissionCode LIKE N'%.View'
WHERE r.RoleCode = N'VIEWER'
  AND NOT EXISTS
  (
      SELECT 1
      FROM dbo.RolePermissions rp
      WHERE rp.RoleId = r.Id
        AND rp.PermissionId = p.Id
  );
GO
