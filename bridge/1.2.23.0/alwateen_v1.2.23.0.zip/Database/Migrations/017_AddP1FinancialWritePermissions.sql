/*
    017_AddP1FinancialWritePermissions.sql

    Permission-only migration for granular chart-of-accounts and
    fiscal-state write authorization. No business schema changes.
*/

SET XACT_ABORT ON;

BEGIN TRANSACTION;

DECLARE @Permissions TABLE
(
    PermissionCode NVARCHAR(150) NOT NULL PRIMARY KEY,
    PermissionName NVARCHAR(200) NOT NULL,
    ModuleName NVARCHAR(100) NOT NULL,
    Description NVARCHAR(500) NULL
);

INSERT INTO @Permissions
(
    PermissionCode,
    PermissionName,
    ModuleName,
    Description
)
VALUES
    (N'ChartOfAccounts.Create', N'Create chart of accounts entries', N'Accounting', N'Create an account in the chart of accounts'),
    (N'ChartOfAccounts.Edit', N'Edit chart of accounts entries', N'Accounting', N'Edit account properties other than active state'),
    (N'ChartOfAccounts.EnableDisable', N'Enable or disable chart of accounts entries', N'Accounting', N'Change the active state of an account'),
    (N'ChartOfAccounts.Delete', N'Delete chart of accounts entries', N'Accounting', N'Delete an account when deletion is allowed'),
    (N'FiscalPeriods.CreateFiscalYear', N'Create fiscal year', N'Accounting', N'Create a fiscal year and its periods'),
    (N'FiscalPeriods.ClosePeriod', N'Close accounting period', N'Accounting', N'Close an accounting period'),
    (N'FiscalPeriods.CloseFiscalYear', N'Close fiscal year', N'Accounting', N'Close a fiscal year');

INSERT INTO dbo.Permissions
(
    PermissionCode,
    PermissionName,
    ModuleName,
    Description
)
SELECT
    source.PermissionCode,
    source.PermissionName,
    source.ModuleName,
    source.Description
FROM @Permissions source
WHERE NOT EXISTS
(
    SELECT 1
    FROM dbo.Permissions existing
    WHERE existing.PermissionCode = source.PermissionCode
);

UPDATE existing
SET
    existing.PermissionName = source.PermissionName,
    existing.ModuleName = source.ModuleName,
    existing.Description = source.Description,
    existing.IsActive = 1
FROM dbo.Permissions existing
INNER JOIN @Permissions source
    ON source.PermissionCode = existing.PermissionCode;

INSERT INTO dbo.RolePermissions
(
    RoleId,
    PermissionId
)
SELECT
    role.Id,
    permission.Id
FROM dbo.Roles role
INNER JOIN dbo.Permissions permission
    ON permission.PermissionCode IN
    (
        SELECT source.PermissionCode
        FROM @Permissions source
    )
WHERE role.RoleCode = N'ADMIN'
  AND NOT EXISTS
  (
      SELECT 1
      FROM dbo.RolePermissions existing
      WHERE existing.RoleId = role.Id
        AND existing.PermissionId = permission.Id
  );

COMMIT TRANSACTION;
