﻿/*
    007_CompleteLegacyCoreTables
    Purpose:
    Complete missing core tables for legacy non-empty databases.
    Safe:
    - No DROP
    - No DELETE
    - Idempotent
*/

IF OBJECT_ID(N'dbo.ItemWarehouseCosts', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ItemWarehouseCosts
    (
        Id INT IDENTITY(1,1) NOT NULL,
        ItemId INT NOT NULL,
        WarehouseId INT NOT NULL,
        AverageCost DECIMAL(18,4) NOT NULL
            CONSTRAINT DF_ItemWarehouseCosts_AverageCost DEFAULT (0),
        LastPurchaseCost DECIMAL(18,4) NOT NULL
            CONSTRAINT DF_ItemWarehouseCosts_LastPurchaseCost DEFAULT (0),
        LastUpdatedAt DATETIME2 NOT NULL
            CONSTRAINT DF_ItemWarehouseCosts_LastUpdatedAt DEFAULT (SYSDATETIME()),

        CONSTRAINT PK_ItemWarehouseCosts
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT FK_ItemWarehouseCosts_Items
            FOREIGN KEY (ItemId)
            REFERENCES dbo.Items(Id),

        CONSTRAINT FK_ItemWarehouseCosts_Warehouses
            FOREIGN KEY (WarehouseId)
            REFERENCES dbo.Warehouses(Id),

        CONSTRAINT UQ_ItemWarehouseCosts_Item_Warehouse
            UNIQUE (ItemId, WarehouseId),

        CONSTRAINT CK_ItemWarehouseCosts_AverageCost
            CHECK (AverageCost >= 0),

        CONSTRAINT CK_ItemWarehouseCosts_LastPurchaseCost
            CHECK (LastPurchaseCost >= 0)
    );
END;

IF OBJECT_ID(N'dbo.OpeningBalanceItems', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.OpeningBalanceItems
    (
        Id INT IDENTITY(1,1) NOT NULL,
        OpeningBalanceBatchId INT NOT NULL,
        ItemId INT NOT NULL,
        WarehouseId INT NOT NULL,
        Qty DECIMAL(18,3) NOT NULL,
        UnitCost DECIMAL(18,4) NOT NULL,
        TotalCost DECIMAL(18,4) NOT NULL,
        CreatedAt DATETIME2 NOT NULL
            CONSTRAINT DF_OpeningBalanceItems_CreatedAt DEFAULT (SYSDATETIME()),

        CONSTRAINT PK_OpeningBalanceItems
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT FK_OpeningBalanceItems_Batch
            FOREIGN KEY (OpeningBalanceBatchId)
            REFERENCES dbo.OpeningBalanceBatches(Id),

        CONSTRAINT FK_OpeningBalanceItems_Items
            FOREIGN KEY (ItemId)
            REFERENCES dbo.Items(Id),

        CONSTRAINT FK_OpeningBalanceItems_Warehouses
            FOREIGN KEY (WarehouseId)
            REFERENCES dbo.Warehouses(Id),

        CONSTRAINT UQ_OpeningBalanceItems_Batch_Item_Warehouse
            UNIQUE (OpeningBalanceBatchId, ItemId, WarehouseId),

        CONSTRAINT CK_OpeningBalanceItems_Qty
            CHECK (Qty > 0),

        CONSTRAINT CK_OpeningBalanceItems_UnitCost
            CHECK (UnitCost >= 0),

        CONSTRAINT CK_OpeningBalanceItems_TotalCost
            CHECK (TotalCost >= 0)
    );
END;

IF OBJECT_ID(N'dbo.ItemWarehouseCosts', N'U') IS NOT NULL
BEGIN
    IF NOT EXISTS
    (
        SELECT 1
        FROM sys.indexes
        WHERE name = N'IX_ItemWarehouseCosts_ItemId'
          AND object_id = OBJECT_ID(N'dbo.ItemWarehouseCosts')
    )
    BEGIN
        CREATE INDEX IX_ItemWarehouseCosts_ItemId
        ON dbo.ItemWarehouseCosts(ItemId);
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM sys.indexes
        WHERE name = N'IX_ItemWarehouseCosts_WarehouseId'
          AND object_id = OBJECT_ID(N'dbo.ItemWarehouseCosts')
    )
    BEGIN
        CREATE INDEX IX_ItemWarehouseCosts_WarehouseId
        ON dbo.ItemWarehouseCosts(WarehouseId);
    END;
END;

IF OBJECT_ID(N'dbo.OpeningBalanceItems', N'U') IS NOT NULL
BEGIN
    IF NOT EXISTS
    (
        SELECT 1
        FROM sys.indexes
        WHERE name = N'IX_OpeningBalanceItems_BatchId'
          AND object_id = OBJECT_ID(N'dbo.OpeningBalanceItems')
    )
    BEGIN
        CREATE INDEX IX_OpeningBalanceItems_BatchId
        ON dbo.OpeningBalanceItems(OpeningBalanceBatchId);
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM sys.indexes
        WHERE name = N'IX_OpeningBalanceItems_ItemId'
          AND object_id = OBJECT_ID(N'dbo.OpeningBalanceItems')
    )
    BEGIN
        CREATE INDEX IX_OpeningBalanceItems_ItemId
        ON dbo.OpeningBalanceItems(ItemId);
    END;

    IF NOT EXISTS
    (
        SELECT 1
        FROM sys.indexes
        WHERE name = N'IX_OpeningBalanceItems_WarehouseId'
          AND object_id = OBJECT_ID(N'dbo.OpeningBalanceItems')
    )
    BEGIN
        CREATE INDEX IX_OpeningBalanceItems_WarehouseId
        ON dbo.OpeningBalanceItems(WarehouseId);
    END;
END;