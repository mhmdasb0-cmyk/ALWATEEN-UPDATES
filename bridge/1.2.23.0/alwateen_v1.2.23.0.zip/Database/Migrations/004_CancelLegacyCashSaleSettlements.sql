﻿/* =========================================================
   004_CancelLegacyCashSaleSettlements.sql

   Purpose:
   - Cancel legacy active settlements linked to Cash sales invoices
   - Cancel the receipt payments that were created only for those legacy settlements
   - Reverse related payment journal entries

   Handles:
   - DB-009 Cash invoices must not use InvoiceSettlements

   Rules:
   - No hard delete
   - Idempotent
   - Stops if any candidate payment has mixed/non-legacy settlements
   ========================================================= */

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @StartedTransaction bit = 0;
DECLARE @Reason nvarchar(400) =
    N'Cancelled by 004_CancelLegacyCashSaleSettlements: Cash sales must not use InvoiceSettlements.';

IF @@TRANCOUNT = 0
BEGIN
    BEGIN TRANSACTION;
    SET @StartedTransaction = 1;
END;

BEGIN TRY

    ------------------------------------------------------------
    -- 01 - Validate required tables
    ------------------------------------------------------------

    IF OBJECT_ID(N'dbo.InvoiceSettlements', N'U') IS NULL
        THROW 70401, 'Table dbo.InvoiceSettlements does not exist.', 1;

    IF OBJECT_ID(N'dbo.SalesInvoices', N'U') IS NULL
        THROW 70402, 'Table dbo.SalesInvoices does not exist.', 1;

    IF OBJECT_ID(N'dbo.Payments', N'U') IS NULL
        THROW 70403, 'Table dbo.Payments does not exist.', 1;

    IF OBJECT_ID(N'dbo.JournalEntries', N'U') IS NULL
        THROW 70404, 'Table dbo.JournalEntries does not exist.', 1;

    IF OBJECT_ID(N'dbo.JournalEntryLines', N'U') IS NULL
        THROW 70405, 'Table dbo.JournalEntryLines does not exist.', 1;

    ------------------------------------------------------------
    -- 02 - Capture legacy settlements
    ------------------------------------------------------------

    DECLARE @LegacySettlements TABLE
    (
        SettlementId int NOT NULL PRIMARY KEY,
        PaymentId int NOT NULL,
        SalesInvoiceId int NOT NULL,
        SettledAmount decimal(18,4) NOT NULL
    );

    INSERT INTO @LegacySettlements
    (
        SettlementId,
        PaymentId,
        SalesInvoiceId,
        SettledAmount
    )
    SELECT
        st.Id,
        st.PaymentId,
        st.InvoiceId,
        st.SettledAmount
    FROM dbo.InvoiceSettlements st
    INNER JOIN dbo.SalesInvoices s
        ON s.Id = st.InvoiceId
    INNER JOIN dbo.Payments p
        ON p.Id = st.PaymentId
    WHERE
        st.InvoiceType = 'Sale'
        AND ISNULL(st.IsCancelled, 0) = 0
        AND ISNULL(s.IsCancelled, 0) = 0
        AND s.PaymentType = 'Cash'
        AND ISNULL(p.IsCancelled, 0) = 0;

    ------------------------------------------------------------
    -- 03 - Nothing to do
    ------------------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1
        FROM @LegacySettlements
    )
    BEGIN
        IF @StartedTransaction = 1
            COMMIT TRANSACTION;

        RETURN;
    END;

    ------------------------------------------------------------
    -- 04 - Capture candidate payments
    --      Only payments whose active settlements are ALL legacy cash-sale settlements
    ------------------------------------------------------------

    DECLARE @CandidatePayments TABLE
    (
        PaymentId int NOT NULL PRIMARY KEY,
        PaymentAmount decimal(18,4) NOT NULL,
        LegacySettledAmount decimal(18,4) NOT NULL
    );

    INSERT INTO @CandidatePayments
    (
        PaymentId,
        PaymentAmount,
        LegacySettledAmount
    )
    SELECT
        p.Id,
        p.Amount,
        SUM(ls.SettledAmount) AS LegacySettledAmount
    FROM dbo.Payments p
    INNER JOIN @LegacySettlements ls
        ON ls.PaymentId = p.Id
    GROUP BY
        p.Id,
        p.Amount;

    ------------------------------------------------------------
    -- 05 - Stop if payment has other active settlements too
    ------------------------------------------------------------

    IF EXISTS
    (
        SELECT 1
        FROM @CandidatePayments cp
        INNER JOIN dbo.InvoiceSettlements st
            ON st.PaymentId = cp.PaymentId
           AND ISNULL(st.IsCancelled, 0) = 0
        LEFT JOIN @LegacySettlements ls
            ON ls.SettlementId = st.Id
        WHERE ls.SettlementId IS NULL
    )
    BEGIN
        SELECT
            cp.PaymentId,
            st.Id AS SettlementId,
            st.InvoiceType,
            st.InvoiceId,
            st.SettledAmount
        FROM @CandidatePayments cp
        INNER JOIN dbo.InvoiceSettlements st
            ON st.PaymentId = cp.PaymentId
           AND ISNULL(st.IsCancelled, 0) = 0
        LEFT JOIN @LegacySettlements ls
            ON ls.SettlementId = st.Id
        WHERE ls.SettlementId IS NULL;

        THROW 70406, 'Cannot cleanup legacy cash-sale settlements because a payment has mixed active settlements.', 1;
    END;

    ------------------------------------------------------------
    -- 06 - Stop if payment amount does not equal legacy settled amount
    ------------------------------------------------------------

    IF EXISTS
    (
        SELECT 1
        FROM @CandidatePayments
        WHERE PaymentAmount <> LegacySettledAmount
    )
    BEGIN
        SELECT
            PaymentId,
            PaymentAmount,
            LegacySettledAmount
        FROM @CandidatePayments
        WHERE PaymentAmount <> LegacySettledAmount;

        THROW 70407, 'Cannot cleanup legacy cash-sale settlements because payment amount differs from legacy settled amount.', 1;
    END;

    ------------------------------------------------------------
    -- 07 - Stop if related payment journal entry is missing
    ------------------------------------------------------------

    IF EXISTS
    (
        SELECT 1
        FROM @CandidatePayments cp
        WHERE NOT EXISTS
        (
            SELECT 1
            FROM dbo.JournalEntries je
            WHERE je.ReferenceId = cp.PaymentId
              AND je.ReferenceType IN ('PaymentReceipt', 'PaymentPayment')
              AND ISNULL(je.IsReversal, 0) = 0
              AND je.Status = 'Posted'
        )
    )
    BEGIN
        SELECT
            cp.PaymentId
        FROM @CandidatePayments cp
        WHERE NOT EXISTS
        (
            SELECT 1
            FROM dbo.JournalEntries je
            WHERE je.ReferenceId = cp.PaymentId
              AND je.ReferenceType IN ('PaymentReceipt', 'PaymentPayment')
              AND ISNULL(je.IsReversal, 0) = 0
              AND je.Status = 'Posted'
        );

        THROW 70408, 'Cannot cleanup legacy cash-sale settlements because a payment journal entry is missing.', 1;
    END;

    ------------------------------------------------------------
    -- 08 - Reverse related payment journal entries
    ------------------------------------------------------------

    DECLARE
        @OriginalJournalEntryId int,
        @OriginalReferenceType nvarchar(100),
        @OriginalReferenceId int,
        @OriginalTotalDebit decimal(18,4),
        @OriginalTotalCredit decimal(18,4),
        @NewJournalEntryId int;

    DECLARE journal_cursor CURSOR LOCAL FAST_FORWARD FOR
        SELECT
            je.Id,
            je.ReferenceType,
            je.ReferenceId,
            je.TotalDebit,
            je.TotalCredit
        FROM dbo.JournalEntries je
        INNER JOIN @CandidatePayments cp
            ON cp.PaymentId = je.ReferenceId
        WHERE
            je.ReferenceType IN ('PaymentReceipt', 'PaymentPayment')
            AND ISNULL(je.IsReversal, 0) = 0
            AND je.Status = 'Posted'
            AND NOT EXISTS
            (
                SELECT 1
                FROM dbo.JournalEntries r
                WHERE r.ReversedEntryId = je.Id
                  AND ISNULL(r.IsReversal, 0) = 1
            );

    OPEN journal_cursor;

    FETCH NEXT FROM journal_cursor
    INTO
        @OriginalJournalEntryId,
        @OriginalReferenceType,
        @OriginalReferenceId,
        @OriginalTotalDebit,
        @OriginalTotalCredit;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        INSERT INTO dbo.JournalEntries
        (
            EntryDate,
            Description,
            ReferenceType,
            ReferenceId,
            TotalDebit,
            TotalCredit,
            IsPosted,
            ReversedEntryId,
            IsReversal,
            OriginalReferenceType,
            OriginalReferenceId,
            ReversalReason,
            Status
        )
        VALUES
        (
            SYSDATETIME(),
            CONCAT(N'Reverse legacy cash-sale settlement payment entry - ', @OriginalJournalEntryId),
            'Reverse',
            @OriginalReferenceId,
            @OriginalTotalCredit,
            @OriginalTotalDebit,
            1,
            @OriginalJournalEntryId,
            1,
            @OriginalReferenceType,
            @OriginalReferenceId,
            @Reason,
            'Posted'
        );

        SET @NewJournalEntryId =
            CONVERT(int, SCOPE_IDENTITY());

        INSERT INTO dbo.JournalEntryLines
        (
            JournalEntryId,
            AccountId,
            Debit,
            Credit,
            Description
        )
        SELECT
            @NewJournalEntryId,
            AccountId,
            Credit,
            Debit,
            CONCAT(N'Reverse legacy cash-sale settlement line - ', ISNULL(Description, N''))
        FROM dbo.JournalEntryLines
        WHERE JournalEntryId = @OriginalJournalEntryId;

        UPDATE dbo.JournalEntries
        SET
            Status = 'Reversed',
            UpdatedAt = SYSDATETIME()
        WHERE Id = @OriginalJournalEntryId;

        FETCH NEXT FROM journal_cursor
        INTO
            @OriginalJournalEntryId,
            @OriginalReferenceType,
            @OriginalReferenceId,
            @OriginalTotalDebit,
            @OriginalTotalCredit;
    END;

    CLOSE journal_cursor;
    DEALLOCATE journal_cursor;

    ------------------------------------------------------------
    -- 09 - Cancel legacy settlements
    ------------------------------------------------------------

    UPDATE st
    SET
        IsCancelled = 1,
        CancelledAt = SYSDATETIME(),
        CancelReason = @Reason
    FROM dbo.InvoiceSettlements st
    INNER JOIN @LegacySettlements ls
        ON ls.SettlementId = st.Id
    WHERE ISNULL(st.IsCancelled, 0) = 0;

    ------------------------------------------------------------
    -- 10 - Cancel related legacy payments
    ------------------------------------------------------------

    UPDATE p
    SET
        IsCancelled = 1,
        CancelledAt = SYSDATETIME(),
        CancelReason = @Reason,
        UpdatedAt = SYSDATETIME()
    FROM dbo.Payments p
    INNER JOIN @CandidatePayments cp
        ON cp.PaymentId = p.Id
    WHERE ISNULL(p.IsCancelled, 0) = 0;

    ------------------------------------------------------------
    -- 11 - Final guard: no active settlements on Cash sales
    ------------------------------------------------------------

    IF EXISTS
    (
        SELECT 1
        FROM dbo.InvoiceSettlements st
        INNER JOIN dbo.SalesInvoices s
            ON s.Id = st.InvoiceId
        WHERE
            st.InvoiceType = 'Sale'
            AND ISNULL(st.IsCancelled, 0) = 0
            AND ISNULL(s.IsCancelled, 0) = 0
            AND s.PaymentType = 'Cash'
    )
    BEGIN
        THROW 70409, 'Legacy cash-sale active settlements still exist after cleanup.', 1;
    END;

    IF @StartedTransaction = 1
        COMMIT TRANSACTION;

END TRY
BEGIN CATCH

    IF @StartedTransaction = 1
       AND XACT_STATE() <> 0
    BEGIN
        ROLLBACK TRANSACTION;
    END;

    THROW;

END CATCH;