/*
    013_AddSystemToolPermissions.sql

    Adds explicit permissions for backup, update, and database reset tools.
    ADMIN receives all new permissions via cross join reconciliation.
*/

DECLARE @PermissionSeed TABLE
(
    PermissionCode NVARCHAR(150) NOT NULL,
    PermissionName NVARCHAR(200) NOT NULL,
    ModuleName NVARCHAR(100) NOT NULL,
    Description NVARCHAR(500) NULL
);

INSERT INTO @PermissionSeed
(
    PermissionCode,
    PermissionName,
    ModuleName,
    Description
)
VALUES
    (N'System.Backup.View', N'View Backup Center', N'System', N'View backup center'),
    (N'System.Backup.Create', N'Create Backups', N'System', N'Create manual database backups'),
    (N'System.Update.View', N'View Update Center', N'System', N'View update center and license status'),
    (N'System.Update.Run', N'Run Updates', N'System', N'Download and install application updates'),
    (N'System.DatabaseReset.Run', N'Run Database Reset', N'System', N'Run destructive database reset operations');

INSERT INTO dbo.Permissions
(
    PermissionCode,
    PermissionName,
    ModuleName,
    Description,
    IsActive
)
SELECT
    s.PermissionCode,
    s.PermissionName,
    s.ModuleName,
    s.Description,
    1
FROM @PermissionSeed s
WHERE NOT EXISTS
(
    SELECT 1
    FROM dbo.Permissions p
    WHERE p.PermissionCode = s.PermissionCode
);
GO

INSERT INTO dbo.RolePermissions
(
    RoleId,
    PermissionId
)
SELECT
    r.Id,
    p.Id
FROM dbo.Roles r
CROSS JOIN dbo.Permissions p
WHERE r.RoleCode = N'ADMIN'
  AND p.PermissionCode IN
  (
      N'System.Backup.View',
      N'System.Backup.Create',
      N'System.Update.View',
      N'System.Update.Run',
      N'System.DatabaseReset.Run'
  )
  AND NOT EXISTS
  (
      SELECT 1
      FROM dbo.RolePermissions rp
      WHERE rp.RoleId = r.Id
        AND rp.PermissionId = p.Id
  );
GO
