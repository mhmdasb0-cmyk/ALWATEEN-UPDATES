/*
    011_DropLegacyPartyBalanceColumns.sql

    Remove unused legacy party balance columns.
    Balance is computed from invoices/settlements; these columns are not used by application logic.
*/

IF COL_LENGTH(N'dbo.Customers', N'Balance') IS NOT NULL
BEGIN
    DECLARE @CustomersBalanceDefault sysname;

    SELECT @CustomersBalanceDefault = dc.name
    FROM sys.default_constraints dc
    INNER JOIN sys.columns c
        ON c.default_object_id = dc.object_id
    WHERE dc.parent_object_id = OBJECT_ID(N'dbo.Customers')
      AND c.name = N'Balance';

    IF @CustomersBalanceDefault IS NOT NULL
    BEGIN
        EXEC(N'ALTER TABLE dbo.Customers DROP CONSTRAINT [' + @CustomersBalanceDefault + N']');
    END;

    ALTER TABLE dbo.Customers
    DROP COLUMN Balance;
END;
GO

IF COL_LENGTH(N'dbo.Suppliers', N'Balance') IS NOT NULL
BEGIN
    DECLARE @SuppliersBalanceDefault sysname;

    SELECT @SuppliersBalanceDefault = dc.name
    FROM sys.default_constraints dc
    INNER JOIN sys.columns c
        ON c.default_object_id = dc.object_id
    WHERE dc.parent_object_id = OBJECT_ID(N'dbo.Suppliers')
      AND c.name = N'Balance';

    IF @SuppliersBalanceDefault IS NOT NULL
    BEGIN
        EXEC(N'ALTER TABLE dbo.Suppliers DROP CONSTRAINT [' + @SuppliersBalanceDefault + N']');
    END;

    ALTER TABLE dbo.Suppliers
    DROP COLUMN Balance;
END;
GO
