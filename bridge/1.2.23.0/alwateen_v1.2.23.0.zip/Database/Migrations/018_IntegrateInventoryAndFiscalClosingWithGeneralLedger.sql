/*
    018_IntegrateInventoryAndFiscalClosingWithGeneralLedger.sql

    Adds configurable posting-account mappings and durable source links for:
    - warehouse stock operations and their reversals;
    - opening-stock batches and their reversals;
    - fiscal-year closing journals.

    The migration deliberately does not seed account identifiers, create
    retrospective journals, or alter historical journal/stock values.
*/

SET XACT_ABORT ON;

BEGIN TRANSACTION;

IF OBJECT_ID(N'dbo.AccountingPostingConfigurations', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AccountingPostingConfigurations
    (
        PostingKey NVARCHAR(80) NOT NULL,
        AccountId INT NOT NULL,
        CreatedAt DATETIME2(7) NOT NULL
            CONSTRAINT DF_AccountingPostingConfigurations_CreatedAt
            DEFAULT (SYSDATETIME()),
        UpdatedAt DATETIME2(7) NULL,

        CONSTRAINT PK_AccountingPostingConfigurations
            PRIMARY KEY CLUSTERED (PostingKey)
    );
END;

IF COL_LENGTH(N'dbo.StockOperations', N'SubmissionKey') IS NULL
    ALTER TABLE dbo.StockOperations ADD SubmissionKey UNIQUEIDENTIFIER NULL;

IF COL_LENGTH(N'dbo.StockOperations', N'CounterAccountId') IS NULL
    ALTER TABLE dbo.StockOperations ADD CounterAccountId INT NULL;

IF COL_LENGTH(N'dbo.StockOperations', N'JournalEntryId') IS NULL
    ALTER TABLE dbo.StockOperations ADD JournalEntryId INT NULL;

IF COL_LENGTH(N'dbo.StockOperations', N'ReversalJournalEntryId') IS NULL
    ALTER TABLE dbo.StockOperations ADD ReversalJournalEntryId INT NULL;

IF COL_LENGTH(N'dbo.StockOperations', N'NeedsReconciliation') IS NULL
BEGIN
    ALTER TABLE dbo.StockOperations
    ADD NeedsReconciliation BIT NOT NULL
        CONSTRAINT DF_StockOperations_NeedsReconciliation DEFAULT (0);

END;

IF COL_LENGTH(N'dbo.OpeningBalanceBatches', N'JournalEntryId') IS NULL
    ALTER TABLE dbo.OpeningBalanceBatches ADD JournalEntryId INT NULL;

IF COL_LENGTH(N'dbo.OpeningBalanceBatches', N'ReversalJournalEntryId') IS NULL
    ALTER TABLE dbo.OpeningBalanceBatches ADD ReversalJournalEntryId INT NULL;

IF COL_LENGTH(N'dbo.OpeningBalanceBatches', N'IsReversed') IS NULL
    ALTER TABLE dbo.OpeningBalanceBatches ADD IsReversed BIT NOT NULL
        CONSTRAINT DF_OpeningBalanceBatches_IsReversed DEFAULT (0);

IF COL_LENGTH(N'dbo.OpeningBalanceBatches', N'ReversedAt') IS NULL
    ALTER TABLE dbo.OpeningBalanceBatches ADD ReversedAt DATETIME2(7) NULL;

IF COL_LENGTH(N'dbo.OpeningBalanceBatches', N'ReverseReason') IS NULL
    ALTER TABLE dbo.OpeningBalanceBatches ADD ReverseReason NVARCHAR(500) NULL;

IF COL_LENGTH(N'dbo.OpeningBalanceBatches', N'NeedsReconciliation') IS NULL
BEGIN
    ALTER TABLE dbo.OpeningBalanceBatches
    ADD NeedsReconciliation BIT NOT NULL
        CONSTRAINT DF_OpeningBalanceBatches_NeedsReconciliation DEFAULT (0);

END;

IF COL_LENGTH(N'dbo.FiscalYears', N'ClosingJournalEntryId') IS NULL
    ALTER TABLE dbo.FiscalYears ADD ClosingJournalEntryId INT NULL;

GO

UPDATE dbo.StockOperations
SET NeedsReconciliation = 1
WHERE OperationType <> N'Transfer'
  AND JournalEntryId IS NULL;

UPDATE dbo.OpeningBalanceBatches
SET NeedsReconciliation = 1
WHERE IsPosted = 1
  AND JournalEntryId IS NULL;

IF NOT EXISTS
(
    SELECT 1 FROM sys.foreign_keys
    WHERE name = N'FK_AccountingPostingConfigurations_Account'
)
    ALTER TABLE dbo.AccountingPostingConfigurations
    ADD CONSTRAINT FK_AccountingPostingConfigurations_Account
        FOREIGN KEY (AccountId) REFERENCES dbo.Accounts(Id);

IF NOT EXISTS
(
    SELECT 1 FROM sys.foreign_keys
    WHERE name = N'FK_StockOperations_CounterAccount'
)
    ALTER TABLE dbo.StockOperations
    ADD CONSTRAINT FK_StockOperations_CounterAccount
        FOREIGN KEY (CounterAccountId) REFERENCES dbo.Accounts(Id);

IF NOT EXISTS
(
    SELECT 1 FROM sys.foreign_keys
    WHERE name = N'FK_StockOperations_JournalEntry'
)
    ALTER TABLE dbo.StockOperations
    ADD CONSTRAINT FK_StockOperations_JournalEntry
        FOREIGN KEY (JournalEntryId) REFERENCES dbo.JournalEntries(Id);

IF NOT EXISTS
(
    SELECT 1 FROM sys.foreign_keys
    WHERE name = N'FK_StockOperations_ReversalJournalEntry'
)
    ALTER TABLE dbo.StockOperations
    ADD CONSTRAINT FK_StockOperations_ReversalJournalEntry
        FOREIGN KEY (ReversalJournalEntryId) REFERENCES dbo.JournalEntries(Id);

IF NOT EXISTS
(
    SELECT 1 FROM sys.foreign_keys
    WHERE name = N'FK_OpeningBalanceBatches_JournalEntry'
)
    ALTER TABLE dbo.OpeningBalanceBatches
    ADD CONSTRAINT FK_OpeningBalanceBatches_JournalEntry
        FOREIGN KEY (JournalEntryId) REFERENCES dbo.JournalEntries(Id);

IF NOT EXISTS
(
    SELECT 1 FROM sys.foreign_keys
    WHERE name = N'FK_OpeningBalanceBatches_ReversalJournalEntry'
)
    ALTER TABLE dbo.OpeningBalanceBatches
    ADD CONSTRAINT FK_OpeningBalanceBatches_ReversalJournalEntry
        FOREIGN KEY (ReversalJournalEntryId) REFERENCES dbo.JournalEntries(Id);

IF NOT EXISTS
(
    SELECT 1 FROM sys.foreign_keys
    WHERE name = N'FK_FiscalYears_ClosingJournalEntry'
)
    ALTER TABLE dbo.FiscalYears
    ADD CONSTRAINT FK_FiscalYears_ClosingJournalEntry
        FOREIGN KEY (ClosingJournalEntryId) REFERENCES dbo.JournalEntries(Id);

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE name = N'UQ_StockOperations_SubmissionKey'
      AND object_id = OBJECT_ID(N'dbo.StockOperations')
)
    CREATE UNIQUE INDEX UQ_StockOperations_SubmissionKey
        ON dbo.StockOperations(SubmissionKey)
        WHERE SubmissionKey IS NOT NULL;

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE name = N'UQ_StockOperations_JournalEntryId'
      AND object_id = OBJECT_ID(N'dbo.StockOperations')
)
    CREATE UNIQUE INDEX UQ_StockOperations_JournalEntryId
        ON dbo.StockOperations(JournalEntryId)
        WHERE JournalEntryId IS NOT NULL;

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE name = N'UQ_OpeningBalanceBatches_JournalEntryId'
      AND object_id = OBJECT_ID(N'dbo.OpeningBalanceBatches')
)
    CREATE UNIQUE INDEX UQ_OpeningBalanceBatches_JournalEntryId
        ON dbo.OpeningBalanceBatches(JournalEntryId)
        WHERE JournalEntryId IS NOT NULL;

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE name = N'UQ_FiscalYears_ClosingJournalEntryId'
      AND object_id = OBJECT_ID(N'dbo.FiscalYears')
)
    CREATE UNIQUE INDEX UQ_FiscalYears_ClosingJournalEntryId
        ON dbo.FiscalYears(ClosingJournalEntryId)
        WHERE ClosingJournalEntryId IS NOT NULL;

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE name = N'UQ_JournalEntries_WarehouseOperation_Source'
      AND object_id = OBJECT_ID(N'dbo.JournalEntries')
)
    CREATE UNIQUE INDEX UQ_JournalEntries_WarehouseOperation_Source
        ON dbo.JournalEntries(ReferenceId)
        WHERE ReferenceType = N'WarehouseOperation' AND IsReversal = 0;

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE name = N'UQ_JournalEntries_OpeningBalance_Source'
      AND object_id = OBJECT_ID(N'dbo.JournalEntries')
)
    CREATE UNIQUE INDEX UQ_JournalEntries_OpeningBalance_Source
        ON dbo.JournalEntries(ReferenceId)
        WHERE ReferenceType = N'OpeningBalance' AND IsReversal = 0;

IF NOT EXISTS
(
    SELECT 1 FROM sys.indexes
    WHERE name = N'UQ_JournalEntries_FiscalYearClose_Source'
      AND object_id = OBJECT_ID(N'dbo.JournalEntries')
)
    CREATE UNIQUE INDEX UQ_JournalEntries_FiscalYearClose_Source
        ON dbo.JournalEntries(ReferenceId)
        WHERE ReferenceType = N'FiscalYearClose' AND IsReversal = 0;

COMMIT TRANSACTION;
