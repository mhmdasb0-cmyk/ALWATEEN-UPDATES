/*
    014_EnforceUserDisplayNameUniqueness.sql

    Enforces unique active-user DisplayName at the database layer.
    Does not modify or rename existing rows.
*/

IF OBJECT_ID(N'dbo.Users', N'U') IS NULL
BEGIN
    THROW 51400, N'Users table does not exist.', 1;
END;
GO

IF EXISTS
(
    SELECT
        u.DisplayName
    FROM dbo.Users u
    WHERE u.IsActive = 1
    GROUP BY
        u.DisplayName COLLATE SQL_Latin1_General_CP1_CI_AS
    HAVING COUNT(*) > 1
)
BEGIN
    THROW 51401, N'Duplicate active DisplayName values exist in Users. Resolve duplicates before applying unique DisplayName index.', 1;
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'UQ_Users_DisplayName_Active'
      AND object_id = OBJECT_ID(N'dbo.Users')
)
BEGIN
    CREATE UNIQUE INDEX UQ_Users_DisplayName_Active
    ON dbo.Users(DisplayName)
    WHERE IsActive = 1;
END;
GO
