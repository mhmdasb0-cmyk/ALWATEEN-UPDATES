/*
    016_AddCompanyProfile.sql

    Adds the single-row company profile table.
    The table intentionally starts empty; the first application save inserts Id = 1.
*/

IF OBJECT_ID(N'dbo.CompanyProfile', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.CompanyProfile
    (
        Id INT NOT NULL,
        CompanyName NVARCHAR(200) NOT NULL,
        DisplayName NVARCHAR(200) NULL,
        LogoImage VARBINARY(MAX) NULL,
        LogoContentType NVARCHAR(100) NULL,
        Address NVARCHAR(300) NULL,
        Phone NVARCHAR(50) NULL,
        Mobile NVARCHAR(50) NULL,
        Email NVARCHAR(254) NULL,
        Website NVARCHAR(200) NULL,
        TaxNumber NVARCHAR(100) NULL,
        RegistrationNumber NVARCHAR(100) NULL,
        InvoiceNote NVARCHAR(500) NULL,
        CreatedAtUtc DATETIME2(0) NOT NULL
            CONSTRAINT DF_CompanyProfile_CreatedAtUtc DEFAULT (SYSUTCDATETIME()),
        UpdatedAtUtc DATETIME2(0) NULL,
        RowVersion ROWVERSION NOT NULL,

        CONSTRAINT PK_CompanyProfile
            PRIMARY KEY CLUSTERED (Id),

        CONSTRAINT CK_CompanyProfile_Id
            CHECK (Id = 1)
    );
END;
GO
