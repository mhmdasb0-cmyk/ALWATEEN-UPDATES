﻿/*
    M4 / STEP 2
    Harden ItemBarcodes rules.
    Rules:
    - One barcode cannot belong to more than one item.
    - One item can have only one primary barcode.
    - No empty barcode.
    - No data deletion.
*/

IF OBJECT_ID(N'dbo.ItemBarcodes', N'U') IS NULL
BEGIN
    THROW 51000, N'ItemBarcodes table does not exist.', 1;
END;
GO

/* 1) Block empty barcodes before adding constraints */

IF EXISTS
(
    SELECT 1
    FROM dbo.ItemBarcodes
    WHERE Barcode IS NULL
       OR LTRIM(RTRIM(Barcode)) = N''
)
BEGIN
    THROW 51001, N'ItemBarcodes contains empty barcode values. Fix data before applying constraints.', 1;
END;
GO

/* 2) Block duplicate barcodes before unique index */

IF EXISTS
(
    SELECT Barcode
    FROM dbo.ItemBarcodes
    GROUP BY Barcode
    HAVING COUNT(*) > 1
)
BEGIN
    THROW 51002, N'Duplicate barcode values exist in ItemBarcodes. Fix data before applying unique barcode constraint.', 1;
END;
GO

/* 3) Block multiple primary barcodes per item before unique filtered index */

IF EXISTS
(
    SELECT ItemId
    FROM dbo.ItemBarcodes
    WHERE IsPrimary = 1
    GROUP BY ItemId
    HAVING COUNT(*) > 1
)
BEGIN
    THROW 51003, N'Some items have more than one primary barcode. Fix data before applying primary barcode constraint.', 1;
END;
GO

/* 4) Make Barcode required */

IF EXISTS
(
    SELECT 1
    FROM sys.columns
    WHERE object_id = OBJECT_ID(N'dbo.ItemBarcodes')
      AND name = N'Barcode'
      AND is_nullable = 1
)
BEGIN
    ALTER TABLE dbo.ItemBarcodes
    ALTER COLUMN Barcode NVARCHAR(100) NOT NULL;
END;
GO

/* 5) Check non-empty barcode */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.check_constraints
    WHERE name = N'CK_ItemBarcodes_Barcode_NotEmpty'
      AND parent_object_id = OBJECT_ID(N'dbo.ItemBarcodes')
)
BEGIN
    ALTER TABLE dbo.ItemBarcodes
    ADD CONSTRAINT CK_ItemBarcodes_Barcode_NotEmpty
    CHECK (LTRIM(RTRIM(Barcode)) <> N'');
END;
GO

/* 6) Unique barcode globally */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'UQ_ItemBarcodes_Barcode'
      AND object_id = OBJECT_ID(N'dbo.ItemBarcodes')
)
BEGIN
    CREATE UNIQUE INDEX UQ_ItemBarcodes_Barcode
    ON dbo.ItemBarcodes(Barcode);
END;
GO

/* 7) Only one primary barcode per item */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'UQ_ItemBarcodes_PrimaryPerItem'
      AND object_id = OBJECT_ID(N'dbo.ItemBarcodes')
)
BEGIN
    CREATE UNIQUE INDEX UQ_ItemBarcodes_PrimaryPerItem
    ON dbo.ItemBarcodes(ItemId)
    WHERE IsPrimary = 1;
END;
GO

/* 8) Helpful search index */

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE name = N'IX_ItemBarcodes_ItemId'
      AND object_id = OBJECT_ID(N'dbo.ItemBarcodes')
)
BEGIN
    CREATE INDEX IX_ItemBarcodes_ItemId
    ON dbo.ItemBarcodes(ItemId);
END;
GO

SELECT
    name AS IndexName
FROM sys.indexes
WHERE object_id = OBJECT_ID(N'dbo.ItemBarcodes')
ORDER BY name;
GO