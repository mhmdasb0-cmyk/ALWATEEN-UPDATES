﻿
/* =========================================================
   T1 - Register Clean Baseline
   Purpose:
   Register the already-applied clean baseline inside SchemaMigrations.
   This script does NOT change schema.
   It only inserts one migration record after validating baseline tables.
   ========================================================= */

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @StartedAt DATETIME2 = SYSDATETIME();

DECLARE @ScriptName NVARCHAR(255) =
    N'000_RegisterCleanBaseline.sql';

DECLARE @BaselineName NVARCHAR(255) =
    N'001_CleanBaseline_Final_v2.sql';

DECLARE @BaselineFingerprint NVARCHAR(MAX) =
    N'ALWATEEN_CLEAN_BASELINE_FINAL_V2_APPLIED_MANUALLY_SCHEMA_MAP_BASE_001_TO_BASE_015_25_TABLES';

DECLARE @ScriptHash NVARCHAR(128) =
    CONVERT(
        NVARCHAR(128),
        HASHBYTES('SHA2_256', @BaselineFingerprint),
        2
    );

BEGIN TRY
    BEGIN TRANSACTION;

    ------------------------------------------------------------
    -- 01 - Ensure SchemaMigrations exists
    ------------------------------------------------------------

    IF OBJECT_ID('dbo.SchemaMigrations', 'U') IS NULL
    BEGIN
        THROW 70001, 'SchemaMigrations table does not exist.', 1;
    END;

    ------------------------------------------------------------
    -- 02 - Ensure required columns exist
    ------------------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1
        FROM sys.columns
        WHERE object_id = OBJECT_ID('dbo.SchemaMigrations')
          AND name = 'ScriptName'
    )
    OR NOT EXISTS
    (
        SELECT 1
        FROM sys.columns
        WHERE object_id = OBJECT_ID('dbo.SchemaMigrations')
          AND name = 'ScriptHash'
    )
    OR NOT EXISTS
    (
        SELECT 1
        FROM sys.columns
        WHERE object_id = OBJECT_ID('dbo.SchemaMigrations')
          AND name = 'ExecutedAt'
    )
    OR NOT EXISTS
    (
        SELECT 1
        FROM sys.columns
        WHERE object_id = OBJECT_ID('dbo.SchemaMigrations')
          AND name = 'DurationMs'
    )
    OR NOT EXISTS
    (
        SELECT 1
        FROM sys.columns
        WHERE object_id = OBJECT_ID('dbo.SchemaMigrations')
          AND name = 'Status'
    )
    OR NOT EXISTS
    (
        SELECT 1
        FROM sys.columns
        WHERE object_id = OBJECT_ID('dbo.SchemaMigrations')
          AND name = 'ErrorMessage'
    )
    BEGIN
        THROW 70002, 'SchemaMigrations structure is incomplete.', 1;
    END;

    ------------------------------------------------------------
    -- 03 - Validate clean baseline required tables
    ------------------------------------------------------------

    DECLARE @RequiredTables TABLE
    (
        TableName SYSNAME NOT NULL
    );

    INSERT INTO @RequiredTables (TableName)
    VALUES
    ('SchemaMigrations'),
    ('Accounts'),
    ('FiscalYears'),
    ('AccountingPeriods'),
    ('Warehouses'),
    ('Units'),
    ('Categories'),
    ('ItemAttributes'),
    ('Employees'),
    ('Items'),
    ('ItemBarcodes'),
    ('ItemWarehouseCosts'),
    ('Customers'),
    ('Suppliers'),
    ('PurchaseInvoices'),
    ('PurchaseItems'),
    ('SalesInvoices'),
    ('SalesInvoiceDetails'),
    ('StockMovements'),
    ('Payments'),
    ('InvoiceSettlements'),
    ('JournalEntries'),
    ('JournalEntryLines'),
    ('OpeningBalanceBatches'),
    ('OpeningBalanceItems');

    IF EXISTS
    (
        SELECT 1
        FROM @RequiredTables rt
        LEFT JOIN sys.tables t
            ON t.name = rt.TableName
        WHERE t.object_id IS NULL
    )
    BEGIN
        SELECT
            rt.TableName AS MissingTable
        FROM @RequiredTables rt
        LEFT JOIN sys.tables t
            ON t.name = rt.TableName
        WHERE t.object_id IS NULL;

        THROW 70003, 'Clean baseline validation failed. Missing required tables.', 1;
    END;

    ------------------------------------------------------------
    -- 04 - Prevent conflicting baseline registration
    ------------------------------------------------------------

    IF EXISTS
    (
        SELECT 1
        FROM dbo.SchemaMigrations
        WHERE ScriptName = @ScriptName
          AND ScriptHash <> @ScriptHash
    )
    BEGIN
        THROW 70004, 'Baseline registration exists with a different hash.', 1;
    END;

    ------------------------------------------------------------
    -- 05 - Insert baseline registration if missing
    ------------------------------------------------------------

    IF NOT EXISTS
    (
        SELECT 1
        FROM dbo.SchemaMigrations
        WHERE ScriptName = @ScriptName
    )
    BEGIN
        INSERT INTO dbo.SchemaMigrations
        (
            ScriptName,
            ScriptHash,
            ExecutedAt,
            DurationMs,
            Status,
            ErrorMessage
        )
        VALUES
        (
            @ScriptName,
            @ScriptHash,
            SYSDATETIME(),
            DATEDIFF(MILLISECOND, @StartedAt, SYSDATETIME()),
            N'Success',
            NULL
        );
    END;

    COMMIT TRANSACTION;

    PRINT 'T1 Register Clean Baseline completed successfully.';

END TRY
BEGIN CATCH
    IF @@TRANCOUNT > 0
        ROLLBACK TRANSACTION;

    DECLARE @ErrorMessage NVARCHAR(MAX) =
        ERROR_MESSAGE();

    THROW 70099, @ErrorMessage, 1;
END CATCH;
GO

------------------------------------------------------------
-- Verification
------------------------------------------------------------

SELECT
    Id,
    ScriptName,
    ScriptHash,
    ExecutedAt,
    DurationMs,
    Status,
    ErrorMessage
FROM dbo.SchemaMigrations
ORDER BY Id;
GO
